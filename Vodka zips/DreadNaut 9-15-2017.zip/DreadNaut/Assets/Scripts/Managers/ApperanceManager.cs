﻿using UnityEngine;
using System.Collections;

public class ApperanceManager : MonoBehaviour {

    public static ApperanceManager instance { get; private set; }
    Sprite[] ingredentApperance = new Sprite[4];
    public Sprite RED;
    public Sprite YELLOW;
    public Sprite GREEN;
    public Sprite BLUE;

    public Sprite[] allJobApperances = new Sprite[4];
    public Sprite WARRIOR;
    public Sprite ROGUE;
    public Sprite WIZARD;
    public Sprite BARD;

   

    public Sprite[] allCurrenciesApperances = new Sprite[5];
    public Sprite Gold;
    public Sprite AApts;
    public Sprite EvilOrderPts;
    public Sprite CollegePts;
    public Sprite CorporealPts;

    public Sprite[] PatronArtInGame = new Sprite[200];

   // public Sprite[] allEquipmentApperances = new Sprite[1]; // more comming soon!




    private void Awake()
    {
        instance = this;
        ingredentApperance[0] = RED;
        ingredentApperance[1] = YELLOW;
        ingredentApperance[2] = GREEN;
        ingredentApperance[3] = BLUE;

        allJobApperances[0] = WARRIOR;
        allJobApperances[1] = ROGUE;
        allJobApperances[2] = WIZARD;
        allJobApperances[3] = BARD;

        allCurrenciesApperances[0] = Gold;
        allCurrenciesApperances[1] = AApts;
        allCurrenciesApperances[2] = EvilOrderPts;
        allCurrenciesApperances[3] = CollegePts;
        allCurrenciesApperances[4] = CorporealPts;

    }

    public Sprite whatDoesTheIngredentLookLike(Ingredent.ingredentColor theColorOfTheIngredent)
    {
        return ingredentApperance[(int)theColorOfTheIngredent];
    }

    public Sprite HowThisPatronLooks(byte patronsId)
    {
        return PatronArtInGame[patronsId];
    }

   // public Sprite HowPatronLooks(Patron.job jobIn)
    //{
    //    return allJobApperances[(int)jobIn];
    //}

    public Sprite whatCurrencyLooksLike(Currency.whosCurrencyIsThis currencyIn)
    {
        return allCurrenciesApperances[(int)currencyIn];
    }
    //public Sprite whatDoesTheEquipmentLookLike(Equipment.howIsThisGoingToLook howDoesThisEquipemntLook)
    //{
    //    return allEquipmentApperances[(int)howDoesThisEquipemntLook];
    //}


}
