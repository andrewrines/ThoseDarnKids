﻿using UnityEngine;
using System.Collections;

public class CameraManager : MonoBehaviour{

   public Camera mainCamera;
   // public Transform cameraStart;
   // public Transform cameraDestination;
    public float speedOfZoom;
    public float zoomTime;
    public float howFarToZoomIn;
    public float howFarToZoomOut;
    public float howLongIsPan;
    public float distanceToPan;
    public float distanceToGoDown;
    public float leftMostBound;
    public float rightMostBound;
    private float desiredZoom;
    private Vector3 defaultCameraLocation;
    private Vector3 desiredLocation;
    private Vector3 velocity;



    void Start()
    {
        defaultCameraLocation = this.transform.position;
        desiredLocation = defaultCameraLocation;
        desiredZoom = howFarToZoomOut;
    }
    private void Update()
    {
        mainCamera.transform.position = Vector3.SmoothDamp(this.transform.position, desiredLocation,ref velocity , howLongIsPan);
        mainCamera.orthographicSize = Mathf.SmoothDamp(mainCamera.orthographicSize, desiredZoom, ref speedOfZoom, zoomTime);
        
    }

    public void ZoomIn(Vector3 targetPatronLocation)
    {

        //mainCamera.orthographicSize = Mathf.SmoothDamp(mainCamera.orthographicSize, howFarToZoomIn, ref speedOfZoom, zoomTime);
        desiredLocation = new Vector3(targetPatronLocation.x, targetPatronLocation.y, this.transform.position.z);
        desiredZoom = howFarToZoomIn;
        
        //Debug.Log(mainCamera.orthographicSize);
    }

    //public void ZoomOut()
    //{
    //    // mainCamera.orthographicSize = Mathf.SmoothDamp(mainCamera.orthographicSize, howFarToZoomOut, ref speedOfZoom, zoomTime);
    //    desiredLocation = this.transform.position;
    //    desiredZoom = howFarToZoomOut;
    //}

    public void panLeft()
    {
        if(checkCanPan(desiredLocation.x- distanceToPan))
        desiredLocation = new Vector3(desiredLocation.x - distanceToPan , this.transform.position.y, this.transform.position.z);
    }

    public void panRight()
    {
        if(checkCanPan(desiredLocation.x + distanceToPan))
        desiredLocation = new Vector3(desiredLocation.x + distanceToPan , this.transform.position.y, this.transform.position.z);
    }

    public void stopPan()
    {
        desiredLocation = this.transform.position;
    }

    public void panDown()
    {
        desiredLocation = new Vector3(this.transform.position.x , this.transform.position.y + distanceToGoDown, this.transform.position.z);
    }

    public void ZoomOut()  // originally called reset to normal, I feel this works better as a zoom out in our game.
    {
        desiredLocation = defaultCameraLocation;
        mainCamera.orthographicSize = Mathf.SmoothDamp(mainCamera.orthographicSize, howFarToZoomOut, ref speedOfZoom, zoomTime);
        desiredZoom = howFarToZoomOut;

    }

    private bool checkCanPan(float xValueToCheck)
    {
        if (xValueToCheck <= leftMostBound || xValueToCheck >= rightMostBound)
            return false;

        else
            return true;
    }
}
