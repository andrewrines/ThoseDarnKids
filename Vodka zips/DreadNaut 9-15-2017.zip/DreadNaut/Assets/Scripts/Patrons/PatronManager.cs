﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PatronManager {

    private patronLoader pLoader = new patronLoader(); 
    public const byte chanceOfQuesterInMorning = 8; // must roll lower than this for the thing to happen 
    public const byte chanceOfRumorInMorning = 17;
    public const byte chanceOfQuesterInNoon = 10;
    public const byte chanceOfRumorInNoon = 15;
    public const byte chanceOfQuesterInNight = 2;
    public const byte chanceOfRumorInNight = 8;

    private TimeOfDayManager.TimeOfDay timeOfDayForPatronManager;
    public TimeOfDayManager.TimeOfDay TimeOfDayForPatronManager { get { return timeOfDayForPatronManager; } set { timeOfDayForPatronManager = value; } }

    private byte[] chancesOfQuestersThroughoutDay = new byte[4];
    private byte[] chancesOfRumorsThroughtDay = new byte[4];
   
    public List<Patron> Regulars = new List<Patron>();
    public List<Patron> AllKnownPatrons = new List<Patron>();

    public void init()
    {
        chancesOfQuestersThroughoutDay[0] = chanceOfQuesterInMorning;
        chancesOfQuestersThroughoutDay[1] = chanceOfQuesterInNoon;
        chancesOfQuestersThroughoutDay[2] = chanceOfQuesterInNight;
        chancesOfQuestersThroughoutDay[3] = chanceOfQuesterInMorning; // keeps probablity the same even if their is a time spawn fall through

        chancesOfRumorsThroughtDay[0] = chanceOfRumorInMorning;
        chancesOfRumorsThroughtDay[1] = chanceOfRumorInNoon;
        chancesOfRumorsThroughtDay[2] = chanceOfRumorInNight;
        chancesOfRumorsThroughtDay[3] = chanceOfQuesterInMorning;
        pLoader.loadTools();
        loadRegulars();
    }

    private void loadRegulars()
    {
        for (int i = 0; i < 8; i++)
        {
            Patron patronToLoad = pLoader.spawnRandomPatron();
            Regulars.Add(patronToLoad);
            AllKnownPatrons.Add(patronToLoad);
        }
    } 

    public Patron DrawAPatron()
    {
        if (Regulars.Count != 0)
        {
            int patronIndexer = Random.Range(0, Regulars.Count);
            Patron patronToReturn = Regulars[patronIndexer];
            Regulars.RemoveAt(patronIndexer);
            //resetDefaults(patronToReturn);
            patronToReturn.Patience = assignTimetoWaitInBar(patronToReturn.thisPatronsPatienceLevel);
            patronToReturn.decideOnWhatTheyWantToDrink();
            if (patronToReturn.currentActivity != Patron.whatDoTheyWantToDo.TURNIN)
            {
                patronToReturn.currentActivity = chooseCurrentActivity();
            }
            return patronToReturn;
        }
        else
        {
            Debug.Log("No More Patrons In Line");
            return null;
        }
    }

    private void resetDefaults(Patron patronToReset)
    {
        if (patronToReset.currentActivity != Patron.whatDoTheyWantToDo.TURNIN)
        {
            patronToReset.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
        }
        patronToReset.IsOnQuest = false;
        //drinks had
        // drunkeness;
    }

    public void putAPatronBack(Patron returningPatron)
    {
        resetDefaults(returningPatron);
        Regulars.Add(returningPatron);
    }

    private float assignTimetoWaitInBar(Patron.patienceLevels PatronPatience)
    {
        if(PatronPatience == Patron.patienceLevels.LOW)
        {
            return Random.Range(8, 10); // 8 - 10
        }

       else if (PatronPatience == Patron.patienceLevels.MID)
        {
            return Random.Range(10, 15); // 10 - 15
        }

       else if (PatronPatience == Patron.patienceLevels.HIGH)
        {
            return Random.Range(15, 20); // 15 - 20
        }
        else
        {
            Debug.Log("Patience fall Through");
            return Random.Range(8, 12);
        }

    }

    public Patron.whatDoTheyWantToDo chooseCurrentActivity()
    {
        
        byte RollForActivity = (byte)Random.Range(1, 21);
        string DEBUGSTRING = "RollForActivity " + RollForActivity + " TIME OF DAY for patorn manager " + timeOfDayForPatronManager;


        if (RollForActivity <= (chancesOfQuestersThroughoutDay[(int)timeOfDayForPatronManager] ))
        {
            Debug.Log(DEBUGSTRING + " Adventure");
            return Patron.whatDoTheyWantToDo.ADVENTURE;
        }

        else if (RollForActivity <= chancesOfRumorsThroughtDay[(int)timeOfDayForPatronManager])
        {
            Debug.Log(DEBUGSTRING + " Rumor");
            return Patron.whatDoTheyWantToDo.RUMOR;
        }

        else
        {
            Debug.Log(DEBUGSTRING + " Drink");
            return Patron.whatDoTheyWantToDo.DRINK;
        }

    }

    public void unlockNewPatronAndAdd(string name)
    {
        Patron p;
        p = pLoader.unlockSpecificPatron(name);
        Regulars.Add(p);
        AllKnownPatrons.Add(p);
    }

   
}
