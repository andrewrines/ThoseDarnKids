﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RumorManager
{
    List<Rumor> activeRumors = new List<Rumor>();

    RumorWarehouse rumorWarehouse;
    RumorLoader rLoader = new RumorLoader();

    public void initRumorWarehouse()
    {
        rLoader.JsonRumorInit();
        rumorWarehouse = rLoader.populateWarehouse();
        rumorWarehouse.initRumorWarehouse();
    }

    public Rumor getRandomRumorFromWarehouseByLevel(byte levelOfRumorToFind)
    {
        Rumor rumorToReturn = rumorWarehouse.giveRandomRumorBasedOnLevel(levelOfRumorToFind);
        if (rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.REPEATABLE || rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.STORY)
        {
            activeRumors.Add(rumorToReturn);
        }
        return rumorToReturn;
    }

    public void unlockRumor(string questToUnlock)
    {
        rumorWarehouse.unlockSpecificRumorBasedOnName(questToUnlock);
    }

    public void storeRumor(string rumorID, bool storeAgain)
    {
        Debug.Log("HIT ON" + rumorID);
        for (int i = 0; i < activeRumors.Count; i++)
        {
            if (activeRumors[i].RumorName == rumorID)
            {
                Debug.Log("We Found a match!");
                Debug.Log(storeAgain);
                if (storeAgain)
                {
                    rumorWarehouse.storeRumor(activeRumors[i].RumorLevel, activeRumors[i]);
                    Debug.Log("Sending quest Back!");
                }
                activeRumors.RemoveAt(i);
                break;
            }
        }

    }
}

