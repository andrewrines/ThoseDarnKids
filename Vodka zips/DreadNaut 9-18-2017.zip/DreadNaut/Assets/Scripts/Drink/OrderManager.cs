﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class OrderManager : MonoBehaviour {

    public List<Drink> drinkCollection = new List<Drink>();
    private DrinkLoader dLoader = new DrinkLoader();

    private void Start()
    {
        dLoader.loadTools();
        drinkCollection = dLoader.populateDrinkCollection();
    }


    private Drink chooseRandomDrink()
    {
       int orderNumber = Random.Range(0, drinkCollection.Count);

        return drinkCollection[orderNumber];
    }

    public int determineDrinkPrice (IOrder PatronOrder, Drink drinkMade)
    {
        Debug.Log(PatronOrder.describeOrder());
        bool isDrinkFound;


        foreach (Drink d in drinkCollection)
        {
            isDrinkFound = true;
            if (d.NumberOfIngredentsInDrink != drinkMade.NumberOfIngredentsInDrink)
            {
                continue;
            }

            else
            {
                for (int i = 0; i < d.DrinkIngredents.Length; i++)
                {
                    Debug.Log("Checking" + d.DrinkName);
                    if (d.DrinkIngredents[i] != drinkMade.DrinkIngredents[i])
                    {
                        isDrinkFound = false;
                        break;
                    }
                }
                if (isDrinkFound)
                {
                    Debug.Log("Our Winner is" + d.DrinkName);
                    break;
                }
            }
        }

        return 0;

    }

    public IOrder makeAnOrder()
    {
        int randomNumber = Random.Range(0, 5);

        switch (randomNumber)
        {
            case 1:
                {
                    return new OrderByName(chooseRandomDrink());
                  
                }
            case 2:
                {
                    return new OrderByFlavor(chooseRandomDrink().ThisDrinksFlavor);
                   
                }
            case 3:
                {
                    return new OrderByIngredent();
                 
                }

            case 4:
                {
                    return new OrderByLackOfIngredent();
                   
                }

            default:
                {
                    return new OrderByName(chooseRandomDrink());
                 
                }
        }
    }
}
