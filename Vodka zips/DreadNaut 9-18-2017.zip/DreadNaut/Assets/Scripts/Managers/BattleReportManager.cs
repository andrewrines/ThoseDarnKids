﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Text;

public class BattleReportManager : MonoBehaviour {

    //public ApperanceManager apperanceManager;
    Quest questToReportOn; 
    [SerializeField]
    GameObject BattleReportPannel;
    [SerializeField]
    Text QuestTitleText;
    [SerializeField]
    Text WinOrLose; // to be replaced with art
    [SerializeField]
    Text RecapText;
    [SerializeField]
    Button RedeemRewardsButton;
    public Image[] rewardImage = new Image[5];
    public Text[] howMuchOfRewardText = new Text[5];
    private List<StoreableItem> rewardsToRedeem = new List<StoreableItem>();
    public List<StoreableItem> RewardsToRedeem { get { return rewardsToRedeem; } }
    private List<Unlocker> unlockersToRedeem = new List<Unlocker>();
    public List<Unlocker> UnlockersToRedeem { get { return unlockersToRedeem; } }
    public enum ReportPages {OPEN, OUTCOME,REWARDS,LEVEL, CLOSED};
    public ReportPages currentPageOfReport;
    private string questTitle;

    private bool doesQuestRepeat;
    public bool DoesQuestRepeat { get { return doesQuestRepeat; } set { doesQuestRepeat = value; } }

    private string rumorID;
    public string RumorID { get { return rumorID; } }

    // Use this for initialization
    void Start () {
      
	}
	
     public void ReadBattleReport(Patron patronCarryingPaystub)
    {
        currentPageOfReport = ReportPages.OPEN;
        BattleReportPannel.SetActive(true);
        questToReportOn = patronCarryingPaystub.QuestStub;
        rumorID = questToReportOn.RumorID;
        questTitle = questToReportOn.QuestName;
        QuestTitleText.text = questTitle + ": Results";

        if (patronCarryingPaystub.WasQuestSucessful)
        {
            WinOrLose.text = "WIN!";
            foreach (StoreableItem s in patronCarryingPaystub.QuestStub.RewardsFromQuest)
            {
                rewardsToRedeem.Add(s);
            }
            RedeemRewardsButton.GetComponentInChildren<Text>().text = "Redeem Rewards!";
        }
        else if (!patronCarryingPaystub.WasQuestSucessful)
        {
            WinOrLose.text = "LOSE...";
            RedeemRewardsButton.GetComponentInChildren<Text>().text = "Continue";
        }

        checkIfRumorRepeats(patronCarryingPaystub.WasQuestSucessful);
        checkForUnlockables(patronCarryingPaystub.WasQuestSucessful);

    }

    public void flipPageInBattleReport()
    {
        currentPageOfReport++;
        clearAllText(); // here
        switch (currentPageOfReport)
        {
            case ReportPages.OUTCOME:
                {
                    flipToOutcomePage();
                    break;
                }
            case ReportPages.REWARDS:
                {
                    FlipToRewardsPage();
                    break;   
                }


            case ReportPages.LEVEL:
                {
                    clearAllText();
                    FlipToLevelUpPage();
                    break;
                }

            case ReportPages.CLOSED:
                {
                    clearAllText();
                    closeBattleReport();
                    break;
                }
        }
    }

    private void flipToOutcomePage()
    {
        QuestTitleText.text = questTitle + ": Outcome";
        foreach (QuestLoader.Trial t in questToReportOn.TrialsOfTheQuest)
        {
            if (t.isTrialPassed)
            {
                int i = questToReportOn.WhoToReward.Dequeue();
                WinOrLose.text += formatText(t.winText.Replace("{NAME}", questToReportOn.PatronsOnQuest[i].Name) + "\n");

                questToReportOn.PatronsOnQuest[i].ExperiencePointsGainedOnThisQuest += t.challengeRaiting * 5; // so we can tally how much exp was gained on a quest and show that to the player

            }
            else
            {
                WinOrLose.text += formatText(t.loseText);
                break;
            }
           
        }
    }

    private void FlipToRewardsPage()
    {
        QuestTitleText.text = questTitle + ": Rewards";
        byte numberOfRewards = 0;
        foreach (StoreableItem s in rewardsToRedeem) 
        {
            rewardImage[numberOfRewards].gameObject.SetActive(true);
            rewardImage[numberOfRewards].sprite = s.displayArt();
            howMuchOfRewardText[numberOfRewards].text = s.NumberLeft.ToString();
            numberOfRewards++;
        }
    }

    private void FlipToLevelUpPage()
    {
        if (questToReportOn.SuccessesOnQuest == questToReportOn.TrialsOfTheQuest.Count)
        {
            grantQuestFinishedEXP();
        }
        foreach (Patron p in questToReportOn.PatronsOnQuest)
        {
            WinOrLose.text += p.Name + "+" + p.ExperiencePointsGainedOnThisQuest + "\n";
            p.gainEXP(); // converts over ExperiencePointsGainedOnThisQuest to real exp!
        }
        QuestTitleText.text = questTitle + ": EXP";
    }

    private void grantQuestFinishedEXP()
    {
        foreach(Patron p in questToReportOn.PatronsOnQuest)
        {
            p.ExperiencePointsGainedOnThisQuest += questToReportOn.ExpToAward;
        }
    }

    public void closeBattleReport() 
    {
        rewardsToRedeem.Clear();
        unlockersToRedeem.Clear();
        BattleReportPannel.SetActive(false);
    }

    private void clearAllText()// really need to decide what I want to do with the rewards page. 
    {

     WinOrLose.text = "";
    // RecapText.text = "";

       foreach(Image i in rewardImage)
        {
            i.gameObject.SetActive(false);
        }
    }

    private string formatText(string textToFormat)  // TODO give public accessTo designer to change how many characters before cut off. 
    {
        StringBuilder strBuilder = new StringBuilder(textToFormat);
        int i = 0;
        for (int j = 0; j < textToFormat.Length; j++)
        {
            if (i >= 50 && strBuilder[j] == ' ')
            {
                strBuilder[j] = '\n';
                i = 0;
            }
            i++;
        }
        textToFormat = strBuilder.ToString();
        return textToFormat;
    }

    private void checkForUnlockables(bool isWin)
    {
        Unlocker.WhenToUnlock unlockState = Unlocker.WhenToUnlock.LOSE;

        if (isWin)
        {
            unlockState = Unlocker.WhenToUnlock.WIN;
        }

        foreach (Unlocker u in questToReportOn.ThingsToUnlock)
        {
            if (u.WhenIsThisUnlocked == unlockState || u.WhenIsThisUnlocked == Unlocker.WhenToUnlock.WINORLOSE)
            {
                unlockersToRedeem.Add(u);
            }
        }
    }

    private void checkIfRumorRepeats(bool isWin)
    {
        doesQuestRepeat = false; 

        if (!isWin && questToReportOn.RumorRepeat == RumorLoader.RepeatableTypes.STORY || questToReportOn.RumorRepeat == RumorLoader.RepeatableTypes.REPEATABLE)
        {
            doesQuestRepeat = true;
        }
    }


}
