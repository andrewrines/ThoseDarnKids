﻿using UnityEngine;
using System.Collections;
using System;

public interface ISeatStates 
{

    void EmptySeat();
    void FillSeat(Patron patronToSit);
    void TalkWithPatron();
    void ConsumeBeverage(Drink DrinkToConsume);
    void NowDrunk();
    void PatronWantsToGoOnAdventure(); 
    void PatronSharesARumor();
    void PatronReturnsFromQuest();
   
}

public class NoOneSeated: ISeatStates
{ 
Seat seatToKeepTrackOf;

public NoOneSeated(Seat SeatToKeepTrackOf)
{
    seatToKeepTrackOf = SeatToKeepTrackOf;
}

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        // cant consume a beverage when no one is there
    }

    public void EmptySeat()
    {
       // can't empty what is already gone;
    }

    public void FillSeat(Patron patronToSit)
    {
        seatToKeepTrackOf.patron = patronToSit;
        seatToKeepTrackOf.IsReadyForRespawn = false;
        seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = ApperanceManager.instance.HowThisPatronLooks(patronToSit.ID);
        seatToKeepTrackOf.PatronsHeight = seatToKeepTrackOf.GetComponent<SpriteRenderer>().bounds.size.x * .33f;
        seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = true;
        seatToKeepTrackOf.WaitTimer = seatToKeepTrackOf.patron.Patience;
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.SeatIsFilled());
    }

    public void TalkWithPatron()
    {
        // Ghosts can't order... yet!
    }

    public void NowDrunk()
    {
        // Ghosts most certantly cannot get drunk; 
    }

    public void PatronSharesARumor()
    {
        // Napstablook isn't feeling up to gossip. 
    }

    public void PatronWantsToGoOnAdventure()
    {
        throw new NotImplementedException();
    }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}


public class PatronSeated : ISeatStates
{
    Seat seatToKeepTrackOf;

    public PatronSeated(Seat SeatToKeepTrackOf)
    {
        seatToKeepTrackOf = SeatToKeepTrackOf;
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        // cannot drink unless they have ordered
        Debug.Log("Cannot drink unless they have ordered");
        TalkWithPatron(); // HACK if the patron hasent ordered, and the player insists on giving them as drink, they will order instead.
    }

    public void EmptySeat()
    {
        seatToKeepTrackOf.IsNeedClear = false;
        seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = null;
        seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = false;

        seatToKeepTrackOf.orderBubble.bubbleGoesAway();

        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.ClearSeat());
    }

    public void FillSeat(Patron patronToSit)
    {
        // can't sit if already seated;
    }

    public void TalkWithPatron()
    {
        seatToKeepTrackOf.IsHasOrdered = true;
       // seatToKeepTrackOf.orderBubble.displayDrinkRequest(seatToKeepTrackOf.transform.position, seatToKeepTrackOf.patron.DrinkThePatronWants.listIngredentsInDrink());
        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.ORDER, seatToKeepTrackOf.patron.thisPatronsDisposition) + seatToKeepTrackOf.patron.OrderThePatronWants.describeOrder());
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.orderHasBeenTaken());
    }

    public void NowDrunk()
    {
        // Can't get Drunk unless they drank something; 
    }

    public void PatronSharesARumor()
    {
        throw new NotImplementedException();
    }

    public void PatronWantsToGoOnAdventure()
    {
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.patronWouldLikeToGoOnAdventure());
    }

    public void PatronReturnsFromQuest()
    {
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.patronIsReturningFromAdventure());
    }
}

public class PatronOrdered : ISeatStates
{
    Seat seatToKeepTrackOf;

    public PatronOrdered(Seat SeatToKeepTrackOf)
    {
        seatToKeepTrackOf = SeatToKeepTrackOf;
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        // this is a bit of a lenghy function, but I don't know where to put everything. 
        drinkToConsume.gameObject.SetActive(false);
        seatToKeepTrackOf.IsHasOrdered = false;
        seatToKeepTrackOf.patronsMug.showMug(drinkToConsume.countIngredentsInDrink() * 2f); // hardcoded 2, somehow need to find way to give power to designer to tweak
        seatToKeepTrackOf.DrinkTimer = drinkToConsume.countIngredentsInDrink() * 2f;
        seatToKeepTrackOf.orderBubble.bubbleGoesAway();
        //seatToKeepTrackOf.patron.decideOnWhatTheyWantToDrink();

        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.DRINK, seatToKeepTrackOf.patron.thisPatronsDisposition));
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.patronIsdrinking()); // forces it to a plane of existance that it can't return from untill it's timer runs out. 
    }

    public void EmptySeat()
    {
        seatToKeepTrackOf.IsNeedClear = false;
        seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = null;
        seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = false;

        seatToKeepTrackOf.orderBubble.bubbleGoesAway();

        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.ClearSeat());
    }

    public void FillSeat(Patron patronToSit)
    {
        // can't sit if already seated;
    }

    public void TalkWithPatron()
    {
        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.ORDER, seatToKeepTrackOf.patron.thisPatronsDisposition) + seatToKeepTrackOf.patron.OrderThePatronWants.describeOrder());
    }

    public void NowDrunk()
    {
        // patron cannot be drunk unless they drank some beers;
    }

    public void PatronSharesARumor()
    {
        // we wanna put some sort of drinking mechanic to rumor sharing
    }

    public void PatronWantsToGoOnAdventure()
    {
        throw new NotImplementedException();
    }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}

public class PatronIsDrinking : ISeatStates
{
    Seat seatToKeepTrackOf;

    public PatronIsDrinking(Seat SeatToKeepTrackOf)
    {
        seatToKeepTrackOf = SeatToKeepTrackOf;
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        // patron is already drinking
    }

    public void EmptySeat()
    {
        // patron can't leave while drinking, this is for debug only
        seatToKeepTrackOf.IsNeedClear = false;
        seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = null;
        seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = false;

        seatToKeepTrackOf.orderBubble.bubbleGoesAway();

        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.ClearSeat());
    }

    public void FillSeat(Patron patronToSit)
    {
        // no one can take this patrons spot yet
    }

    public void TalkWithPatron()
    {
        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.TALK, seatToKeepTrackOf.patron.thisPatronsDisposition));
    }

    public void NowDrunk()
    {
        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.patronIsNowDrunk());
    }

    public void PatronSharesARumor()
    {
        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.RUMOR, seatToKeepTrackOf.patron.thisPatronsDisposition));
    }

    public void PatronWantsToGoOnAdventure()
    {
       
    }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}

public class PatronIsDrunk : ISeatStates    // IGNORE THIS FOR NOW
{
    Seat seatToKeepTrackOf;

    public PatronIsDrunk (Seat SeatToKeepTrackOf)
    {
        seatToKeepTrackOf = SeatToKeepTrackOf;
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        // patron is already drinking
    }

    public void EmptySeat()
    {
        // patron can't leave while drinking
    }

    public void FillSeat(Patron patronToSit)
    {
        // no one can take this patrons spot yet
    }

    public void TalkWithPatron()
    {
        // May change to talk 
    }

    public void NowDrunk()
    {
        // not here yet
    }

    public void PatronSharesARumor()
    {
        throw new NotImplementedException();
    }

    public void PatronWantsToGoOnAdventure()
    {
        throw new NotImplementedException();
    }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}

public class PatronWantsAdventure : ISeatStates
{

    Seat seatToKeepTrackOf;

    public PatronWantsAdventure(Seat SeatToKeepTrackOf)
    {
        seatToKeepTrackOf = SeatToKeepTrackOf;
        // this seat, display icon. 
    }

    public void ConsumeBeverage(Drink DrinkToConsume)
    {
        // may introduce a lower price of quest???
    }

    public void EmptySeat()
    {
        seatToKeepTrackOf.IsNeedClear = false;  // all of this should probably be a function at some point. 
        seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = null;
        seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = false;

        seatToKeepTrackOf.orderBubble.bubbleGoesAway();

        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.ClearSeat());
    }

    public void FillSeat(Patron patronToSit)
    {
        // cannot fill seat if patron is already sitting here
    }

    public void TalkWithPatron()
    {
        seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.ADVENTURE, seatToKeepTrackOf.patron.thisPatronsDisposition));
    }

    public void NowDrunk()
    {
        throw new NotImplementedException();
    }

    public void PatronSharesARumor()
    {
        throw new NotImplementedException();
    }

    public void PatronWantsToGoOnAdventure()
    {
        throw new NotImplementedException();
    }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}


   public class PatronReturningFromAdventure : ISeatStates
    {
        Seat seatToKeepTrackOf;

        public PatronReturningFromAdventure(Seat SeatToKeepTrackOf)
        {
            seatToKeepTrackOf = SeatToKeepTrackOf;
        }

        public void ConsumeBeverage(Drink DrinkToConsume)
        {
            // may introduce a lower price of quest???
        }

        public void EmptySeat()
        {
            seatToKeepTrackOf.IsNeedClear = false;  // all of this should probably be a function at some point. 
            seatToKeepTrackOf.GetComponent<SpriteRenderer>().sprite = null;
            seatToKeepTrackOf.GetComponent<BoxCollider2D>().enabled = false;

            seatToKeepTrackOf.orderBubble.bubbleGoesAway();

            seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.ClearSeat());
        }

        public void FillSeat(Patron patronToSit)
        {
            // cannot fill seat if patron is already sitting here
        }

        public void TalkWithPatron()
        {
            if (seatToKeepTrackOf.patron.WasQuestSucessful)
            seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.TRIUMPH, seatToKeepTrackOf.patron.thisPatronsDisposition));
            else
                seatToKeepTrackOf.patronSays(JsonDialogueLoader.Instance.dioOut(JsonDialogueLoader.responceType.FAIL, seatToKeepTrackOf.patron.thisPatronsDisposition));

        seatToKeepTrackOf.setSeatState(seatToKeepTrackOf.SeatIsFilled()); // here 
        seatToKeepTrackOf.patronWantsIcons.clearNeedsIcons();
        }

        public void NowDrunk()
        {
            throw new NotImplementedException();
        }

        public void PatronSharesARumor()
        {
            throw new NotImplementedException();
        }

        public void PatronWantsToGoOnAdventure()
        {
            throw new NotImplementedException();
        }

    public void PatronReturnsFromQuest()
    {
        throw new NotImplementedException();
    }
}





