﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Mug : ABSTFadableObject
{
    private SpriteRenderer patronsMug;
    //private Color fullMugValue;
    private bool isPaused;
    public bool IsPaused { get { return isPaused; } set { isPaused = value; } }


    public void initMug()
    {
        patronsMug = GetComponent<SpriteRenderer>();
        assignObjectToFade(patronsMug);
        hideMug();
    }

    public void showMug(float drinksDesity)
    {
        showFullAlphaValueArt();
        this.gameObject.SetActive(true);
        fadeMug(drinksDesity);
    }

    public void fadeMug(float timeToFade)
    {
        setFadeTime(timeToFade);
        startExitAnimation();
    }


    public void hideMug()
    {
        if (patronsMug != null)
        {
            patronsMug.gameObject.SetActive(false);
        }
    }

   
}
