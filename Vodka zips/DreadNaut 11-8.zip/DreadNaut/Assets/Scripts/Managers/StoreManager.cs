﻿using UnityEngine;
using System.Collections;

public class StoreManager : MonoBehaviour {

    public Dispencer[] dispencersToBuy = new Dispencer[3];


    public int getPrice(byte dispencersIndexNumber)
    {
        return dispencersToBuy[dispencersIndexNumber].getPrice();
    }

    public void purchaseItem(byte dispencersIndexNumber)
    {
        dispencersToBuy[dispencersIndexNumber].purchaseItem();
    }
}
