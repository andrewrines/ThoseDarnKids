﻿using UnityEngine;
using System.Collections;

public class PurchaseItemFromShop : CommandWithUndo
{

    byte indexOfItemToBuy;

    public PurchaseItemFromShop(byte indexIn) : base()
    {
        indexOfItemToBuy = indexIn;
    }

    public override void Execute(BarManager Bar)
    {
        Bar.purchaseItemFromShop(indexOfItemToBuy);
    }
}

