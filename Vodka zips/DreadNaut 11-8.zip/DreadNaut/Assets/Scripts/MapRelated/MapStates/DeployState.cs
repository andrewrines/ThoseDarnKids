﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class DeployState : MonoBehaviour, IMapStates
{

    enum MapState { INACTIVE, CONVERTING_RUMOR_TO_QUEST, SETTING_ADVENTURE_LOCATION, CHOOSING_QUEST }
    MapState currentMapState = MapState.INACTIVE;

    [SerializeField]
    Location startingLocation; //the location of the bar (every patron will start off here)

    [SerializeField]
    Color colorWhenSelectedForAdventure;
    [SerializeField]
    Color colorWhenNotSelectedForAdventure;

    [SerializeField]
    PatronCheatSheet patronCheatSheet;

    [SerializeField]
    RectTransform DependentUI;  //Condensed all the buttons and stuff into one parent object

    [SerializeField]            //NOTE: is this an okay spot to stick this?
    Text AdventureCostDisplay;
    [SerializeField]
    Text AdventureCostDisplayShadow;



    MapManager mapManager;
    Location currentLocation = null;
    Adventure AdventureUnderConstruction;
    public int getAdventureCost { get { return AdventureUnderConstruction.Cost; } }

    public DeployState(MapManager mapsly)
    {
        mapManager = mapsly;
    }

    public void closeMapProps()
    {
        patronCheatSheet.deactivatePatronCheatSheet();
        HideQuestInfoPanel();
        DependentUI.gameObject.SetActive(false);
        AdventureUnderConstruction.ClearAdventure();
        mapManager.MapVisualEffectScript.ZoomMapOutOfLocation(currentLocation); // just incase, I encounted a strange zoom in bug.
        UpdateAdventureCostDisplayText();
    }

    public void nodeClicked(Location clickedLocation)
    {
        if (currentLocation.IsAdjacentToLocation(clickedLocation) && !AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation) && clickedLocation != startingLocation && currentMapState != MapState.CHOOSING_QUEST) // && clickedLocation != startingLocation added 
        {
            Road r = currentLocation.FindRoadConnectedBetweenLocations(clickedLocation);

            currentLocation = clickedLocation;

            AdventureUnderConstruction.SetNodeLocation(clickedLocation, r);
            mapManager.MapVisualEffectScript.ZoomMapInToLocation(clickedLocation); // Bowdish Code added 10/8
            currentMapState = MapState.CHOOSING_QUEST;
            ShowQuestInfoPanel();
        }
        else if (AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation))
        {
            AdventureUnderConstruction.RemoveAllNodesPastGivenNodeLocation(clickedLocation);
            currentLocation = clickedLocation;
        }
        UpdateAdventureCostDisplayText();
    }

    public void openMapProps()
    {
        currentLocation = startingLocation;
        if (AdventureUnderConstruction != null) { AdventureUnderConstruction.ClearAdventure(); } //wipe the temporary adventure, just to be safe
        AdventureUnderConstruction = new Adventure(mapManager.PatronToGoOnAdventure, startingLocation, colorWhenSelectedForAdventure, colorWhenNotSelectedForAdventure);
        patronCheatSheet.activatePatronCheatSheet();
        patronCheatSheet.displayStats(mapManager.PatronToGoOnAdventure);
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        DependentUI.gameObject.SetActive(true);
        UpdateAdventureCostDisplayText();
    }

    public void AddQuestToAdventure() //Called when the player clicks the "Choose quest" add quest button (while creating an adventure) This is called from a bit of a hacky place (the button calls from this exact class), Ill incoporate it into the command pattern in a while. 
    {
        AdventureUnderConstruction.SetNodeQuest(mapManager.getQuestInfoPanel.GetQuestFromLocation());
        AdventureUnderConstruction.ConfirmNewNode();
        mapManager.MapVisualEffectScript.ZoomMapOutOfLocation(currentLocation); // Bowdish code 10/8
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        HideQuestInfoPanel();
        UpdateAdventureCostDisplayText();
    }


    public void ShowQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(true);
        mapManager.getQuestInfoPanel.InitializeQuestInfoPanel(currentLocation);
    }

    public void HideQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(false);
    }

    public void FinishTaskOnMap()
    {
        AdventureUnderConstruction.assignAllQuestsToPatron();
        mapManager.addAdventureToAllAdventures(AdventureUnderConstruction);
    }

    public void GetRefrenceOfMapManager(MapManager constructMapManager)
    {
        mapManager = constructMapManager;
    }

    void UpdateAdventureCostDisplayText()
    {
        AdventureCostDisplay.text = "Cost: " + AdventureUnderConstruction.Cost;
        AdventureCostDisplayShadow.text = "Cost: " + AdventureUnderConstruction.Cost;
    }

    //public void FinishBuildingAdventure()   //Called when the player clicks the "Confirm Adventure" button (while creating an adventure)  Same as above.
    //{

    //}
}

