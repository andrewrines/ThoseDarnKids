﻿
public interface IPurchaseable  {

    void purchaseItem();
    void setPrice(int newPrice);
    int getPrice();
    
}
