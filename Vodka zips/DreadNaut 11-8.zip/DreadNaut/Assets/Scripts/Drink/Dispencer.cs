﻿using UnityEngine;
using System.Collections;
using System;

public class Dispencer : MonoBehaviour, IPurchaseable
{
    public int priceForNewDispencer;
    //public enum NozzelIngredient { RED, YELLOW, GREEN, BLUE } //Enum in this order to match command inputs
    public Ingredent.ingredentColor ingredientToDispence;

    [SerializeField] DispencerSlot slot;
    [SerializeField] InputManager inputManager; //HAAAACCCKKKKK

    public void ClickDispenserButton()
    {
        if(slot.mugInSlot)
        {
            inputManager.DispencerButtonPressed((byte)ingredientToDispence, slot.mugInSlot.DrinkInMug);
        }
    }

    public void purchaseItem()
    {
        this.gameObject.SetActive(true);
    }


    public void setPrice(int newPrice)
    {
        throw new NotImplementedException();
    }

    public int getPrice()
    {
       return priceForNewDispencer;
    }

    public Ingredent.ingredentColor getThisDispencersColor()
    {
        return ingredientToDispence;
    }



    #region Unneeded Code?
    //[SerializeField] float dispenseSpeed = 1;
    //public enum DispenserState { START_DISPENSING, DISPENSING, STOP_DISPENSING} //I (Nathan B) may not need "Dispencing".  It's only for potential animations
    //public DispenserState currentDispenserState { get; private set; }

    //void Start()
    //{
    //    currentDispenserState = DispenserState.STOP_DISPENSING;
    //}

    //public void StartDispensing()   //Called when the player is holding the button
    //{
    //    if (slot.mugInSlot != null)
    //    {
    //        currentDispenserState = DispenserState.START_DISPENSING;
    //    }
    //}

    //public void StopDispensing() //Called when the player releases the button
    //{
    //    currentDispenserState = DispenserState.STOP_DISPENSING;
    //}

    //Possibly for animations, but no functionality is needed in update
    //void Update()
    //{
    //    switch(currentDispenserState)
    //    {
    //        case (DispenserState.START_DISPENSING):
    //            //start pouring animation
    //            //initial burst animation
    //            currentDispenserState = DispenserState.DISPENSING;
    //            break;
    //        case (DispenserState.DISPENSING):
    //            inputManager.DispencerButtonHold((byte)ingredientToDispence, dispenseSpeed * Time.deltaTime, slot.mugInSlot.DrinkInMug);
    //            break;
    //        case (DispenserState.STOP_DISPENSING):
    //            //end animations
    //            //stop dispensing
    //            break;
    //    }
    //}
    #endregion
}
