﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class ShopState : MonoBehaviour, IEndOfDayStates
{

    public Button[] purchaseButtons = new Button[3];
    public Image[] IconsOfThingsYouCanBuy = new Image[3];

    public EndOfDayManager endOfDayManager;

    public void AddQuestToMap()
    {
        throw new NotImplementedException();
    }

    public void BackOutOfQuestRumor()
    {
        throw new NotImplementedException();
    }

    public void HidePresetAssets()
    {
        deactivateShop();
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from store");
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openRumorScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from store");
    }

    public void StoreMenuOpen()
    {

    }

    public void ScrollDown()
    {
        throw new NotImplementedException();
    }

    public void ScrollUp()
    {
        throw new NotImplementedException();
    }

    public void ShowPresetAssets()
    {
        activateShop();
    }

    public void ShowQuestOnPage(Quest quest)
    {
        throw new NotImplementedException();
    }

    public void ShowStatsOnPage(byte index)
    {
        throw new NotImplementedException();
    }

    public void turnPageLeftInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void turnPageRightInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void formatButtonsForThisPage()
    {

    }

    public void purchaseThisDispencer(byte indexOfDispencerToBuy)
    {
       // This will now lock the player out of using the button again and will display a sold out sign of sorts
    }

    private void activateShop()
    {
        for (int i = 0; i < purchaseButtons.Length; i++)
        {
            purchaseButtons[i].gameObject.SetActive(true);
            IconsOfThingsYouCanBuy[i].gameObject.SetActive(true);
        }
    }

    private void deactivateShop()
    {
        for (int i = 0; i < purchaseButtons.Length; i++)
        {
            purchaseButtons[i].gameObject.SetActive(false);
            IconsOfThingsYouCanBuy[i].gameObject.SetActive(false);
        }
    }

    public void markButtonWithSoldOut(byte itemNumberToPurchase)
    {
        purchaseButtons[itemNumberToPurchase].enabled = false;
        purchaseButtons[itemNumberToPurchase].GetComponentInChildren<Text>().text = "SOLD OUT!";
       // purchaseButtons[itemNumberToPurchase].GetComponentInChildren<Text>().text = "Sold out!"; 

        // some way of perminatly keeping this item sold out each time you visit the store. 
    }

  
}
