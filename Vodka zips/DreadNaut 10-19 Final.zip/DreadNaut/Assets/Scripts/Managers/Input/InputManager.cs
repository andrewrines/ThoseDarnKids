﻿using UnityEngine;
using System.Collections;

public class InputManager : MonoBehaviour {

    CommandWithUndo command;

    public BarManager barManager;

    bool isMouseHeldDown = false; 

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePosition = Input.mousePosition;
        command = null;
        ScanForPatron(mousePosition);        // sees if we mouse over a patron
        scanForMouseDown();
        scanForMouseUp();
    }


    private void ScanForPatron(Vector3 mousePosition) // not too sure about this. 
    {
        Vector2 v = Camera.main.ScreenToWorldPoint(mousePosition);

        Collider2D[] col = Physics2D.OverlapPointAll(v);


        if (col.Length > 0)
        {
            foreach (Collider2D c in col)
            {
                if (c.GetComponent<Seat>() != null)
                {
                    command = new ScanForPatron(c.GetComponent<Seat>());
                    scanForPatronClick();
                    ActivateCommand(command);
                }

            }
        }
        else
        {
            command = new NoOneHighlighted();
            ActivateCommand(command);
        }

      

    }

    private void scanForPan(Vector3 mousePosition)
    {
        if (mousePosition.x < (Screen.width * .1f))
        {
            command = new PanLeft();
            ActivateCommand(command);
        }

        else if (mousePosition.x > (Screen.width * .9f))
        {
            command = new PanRight();
            ActivateCommand(command);
        }

        else
        {
            command = new StopPan();
            ActivateCommand(command);
        }

    }

    private void scanForPatronClick()
    {
        if (Input.GetMouseButtonDown(0))
        {
            command = new ScanForPatronClick();
            isMouseHeldDown = true;
        }
    }

    private void scanForMouseUp()
    {
        if (Input.GetMouseButtonUp(0) && isMouseHeldDown)
        {
            command = new MouseHasBeenReleased();
            isMouseHeldDown = false;
            ActivateCommand(command);
        }
    }

    private void scanForMouseDown()
    {
        isMouseHeldDown = true;
    }

    //private void scanForDrinkSell()
    //{
    //    if (FillableMug.currentMugBeingDragged != null && Input.GetMouseButtonUp(0)) 
    //    {
    //        command = new SellDrink();
    //    }
    //}

    #region IngredentButtonsCommands

    public void DispencerButtonPressed(byte inventoryIndex, Drink targetDrink)
    {
        command = new AddIngredentFromInvintory(inventoryIndex, targetDrink);
        ActivateCommand(command);
    }

    //public void InvButton0()
    //{
    //    command = new AddIngredentFromInvintory(0);
    //    ActivateCommand(command);
    //}

    //public void InvButton1()
    //{
    //    command = new AddIngredentFromInvintory(1);
    //    ActivateCommand(command);
    //}

    //public void InvButton2()
    //{
    //    command = new AddIngredentFromInvintory(2);
    //    ActivateCommand(command);
    //}

    //public void InvButton3()
    //{
    //    command = new AddIngredentFromInvintory(3);
    //    ActivateCommand(command);
    //}

    //public void InvButton4()
    //{
    //    command = new AddIngredentFromInvintory(4);
    //    ActivateCommand(command);
    //}

    //public void InvButton5()
    //{
    //    command = new AddIngredentFromInvintory(5);
    //    ActivateCommand(command);
    //}
    #endregion


    #region EndOfDayManagementIndexerButtons
    public void endOfDayButton0()
    {
        command = new GetInfoFromEndOfDayButton(0);
        ActivateCommand(command);
    }

    public void endOfDayButton1()
    {
        command = new GetInfoFromEndOfDayButton(1);
        ActivateCommand(command);
    }

    public void endOfDayButton2()
    {
        command = new GetInfoFromEndOfDayButton(2);
        ActivateCommand(command);
    }

    public void endOfDayButton3()
    {
        command = new GetInfoFromEndOfDayButton(3);
        ActivateCommand(command);
    }

    public void endOfDayButton4()
    {
        command = new GetInfoFromEndOfDayButton(4);
        ActivateCommand(command);
    }

    public void endOfDayButton5()
    {
        command = new GetInfoFromEndOfDayButton(5);
        ActivateCommand(command);
    }

    #endregion

    #region questBookHooks
   

    public void decrementQuestBookPage()
    {
        command = new DecrementQuestBookPage();
        ActivateCommand(command);
    }

    public void IncrementQuestBookPage()
    {
        command = new IncrementQuestBookPage();
        ActivateCommand(command);
    }
    #endregion

    public void acceptAdventure()
    {
        command = new AcceptAdventure();
        ActivateCommand(command);
    }


    public void closeAdventureMap()
    {
        command = new CloseAdventureMap();
        ActivateCommand(command);
    }

    

    public void changeStanding()
    {
        command = new ChangeStance();
        ActivateCommand(command);
    }

    public void recycleDrinkButtonClicked()
    {
        command = new RecycleDrink();
        ActivateCommand(command);
    }

    public void startNextDay()
    {
        command = new StartNextDay();
        ActivateCommand(command);
    }

    #region EndOfDayManagementCommands

    public void switchToPatronScreen()
    {
        command = new SwitchToPatronScreen();
        ActivateCommand(command);
    }

    public void switchToRumorScreen()
    {
        command = new SwitchToRumorScreen();
        ActivateCommand(command);
    }

    public void scrollUpInEndOfDay()
    {
        command = new ScrollBarUp();
        ActivateCommand(command);
    }

    public void scrollDownInEndOfDay()
    {
        command = new ScrollBarDown();
        ActivateCommand(command);
    }
    #endregion

    #region rumorPageQuestButtons
   

    public void addQuestToBook()
    {
        command = new AddQuestToBook();
        ActivateCommand(command);
    }

    public void doNoAddQuestToBook()
    {
        command = new DoNotAddQuestToBook();
        ActivateCommand(command);
    }
    #endregion

    public void scrollLeftInQuestsAtLocation()
    {
        command = new ScrollLeftInQuestsAtLocation();
        ActivateCommand(command);
    }

    public void scrollRightInQuestAtLocation()
    {
        command = new ScrollRightInQuestsAtLocation();
        ActivateCommand(command);
    }
    public void closeBattleReport()
    {
        command = new CloseBattleReport();
        ActivateCommand(command);
    }

    public void DebugEndDayEarly()
    {
        command = new DebugEndDayEarly();
        ActivateCommand(command);
    }

    private void ActivateCommand(Command command)
    {
        command.Execute(barManager);
    }

}
