﻿using UnityEngine;
using System.Collections;

public class DebugEndDayEarly : CommandWithUndo
{

    public DebugEndDayEarly() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            //target. send guy out, close book, mark quest in book for trash. 
            target.endDayEarly();
        }
        base.Execute(Bar);
    }
}

