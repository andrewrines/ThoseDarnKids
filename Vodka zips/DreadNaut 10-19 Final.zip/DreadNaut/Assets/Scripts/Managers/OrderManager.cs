﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class OrderManager : MonoBehaviour {

    public List<Drink> drinkCollection = new List<Drink>();
    private DrinkLoader dLoader = new DrinkLoader();

    private void Start()
    {
        dLoader.loadTools();
        drinkCollection = dLoader.populateDrinkCollection();
    }


    private Drink chooseRandomDrink()
    {
       int orderNumber = Random.Range(0, drinkCollection.Count);

        return drinkCollection[orderNumber];
    }

    public int determineDrinkPrice(IOrder PatronOrder, Drink drinkMade)
    {
        Drink drinkFromDatabase = findDrinkInDataBase(drinkMade);

        if (drinkFromDatabase == null)
        {
            Debug.Log("This drink dosen't even exist");
            SoundManager.Instance.AddCommand("No");
            return 0;
        }

        if (PatronOrder.checkAccuracy(drinkFromDatabase))
        {
            Debug.Log("Correct Drink");
            SoundManager.Instance.AddCommand("Pay");
            return drinkFromDatabase.CorrectPrice;
        }
        else
        {
            Debug.Log("Mix up");
            SoundManager.Instance.AddCommand("Mix Up");
            return drinkFromDatabase.MixUpPrice;
        }

    }

    private Drink findDrinkInDataBase (Drink drinkToFind)
    {
        
        bool canDrinkBeReturned;


        foreach (Drink d in drinkCollection)
        {
           canDrinkBeReturned = true;
            if (d.NumberOfIngredentsInDrink != drinkToFind.NumberOfIngredentsInDrink)
            {
                continue;
            }

            else
            {
                for (int i = 0; i < d.DrinkIngredents.Length; i++)
                {
                    if (d.DrinkIngredents[i] != drinkToFind.DrinkIngredents[i])
                    {
                        canDrinkBeReturned = false;
                        break;
                    }
                }
                if (canDrinkBeReturned)
                {
                     return d;

                }
            }
        }

        return null;

    }

    public IOrder makeAnOrder()
    {
        int randomNumber = Random.Range(0, 5);

        switch (randomNumber)
        {
            case 1:
                {
                    return new OrderByName(chooseRandomDrink());
                  
                }
            case 2:
                {
                    return new OrderByFlavor(chooseRandomDrink().ThisDrinksFlavor);
                   
                }
            case 3:
                {
                    return new OrderByIngredent();
                 
                }

            case 4:
                {
                    return new OrderByLackOfIngredent();
                   
                }

            default:
                {
                    return new OrderByName(chooseRandomDrink());
                 
                }
        }
    }
}
