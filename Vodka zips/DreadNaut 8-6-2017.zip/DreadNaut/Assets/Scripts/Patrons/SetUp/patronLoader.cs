﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class patronLoader
{

    private static patronLoader instance = null;
    private static readonly object padloc = new object();
      
    private enum jsonHelper {NAME,JOB,GENDER,TIES,TOLERANCE,STATS,BS1,BS2,BS3, PATIENCE,  DISPOSITION };
    private string path;
    private string jsonString;
   private JSONObject patronToParse;
   private List<byte> indexingNumbers;

    
    //private Patron patronGuy;

    public static patronLoader Instance
    {
        get
        {
            lock (padloc)
            {

                if (instance == null)
                {
                    instance = new patronLoader();
                   instance.loadTools();

                }
                return instance;
            }
        }
    }

    public void loadTools()
    {
        indexingNumbers = new List<byte>();

        path = Application.dataPath + "/JsonFiles/CharactersInGame.json";
        jsonString = File.ReadAllText(path);
       // patronGuy = JsonUtility.FromJson<Patron>(jsonString);
        patronToParse = new JSONObject(jsonString);
        loadIndexer((byte)patronToParse.Count);
        
    }

    private void loadIndexer(byte indexerSize)
    {
        for (byte i = 0; i < indexerSize; i++)
        {
            indexingNumbers.Add(i);
        }
    }

    private byte drawFromIndexer()
    {
        int indexNumberToShareAndRemove = Random.Range(0, indexingNumbers.Count);
        byte numberToindex = indexingNumbers[indexNumberToShareAndRemove];
        indexingNumbers.RemoveAt(indexNumberToShareAndRemove);
        return numberToindex;
        
    }

    public Patron spawnNewPatron() // I dont know about this... parsing stuff. Not sure if its a pain or if its good. 
    {
        JSONObject randomlyCraftedPatron = patronToParse[drawFromIndexer()];
        string craftedName = randomlyCraftedPatron[(int)jsonHelper.NAME].str;
        packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]);
        Patron.job CraftedType = jobParser(randomlyCraftedPatron[(int)jsonHelper.JOB].str);
        Patron.disposition craftedDisposition = dispositionParser(randomlyCraftedPatron[(int)jsonHelper.DISPOSITION].str);
        Patron.Aligence CraftedAligence = aligenceParser(randomlyCraftedPatron[(int)jsonHelper.TIES].str);
        Patron.drinkLevel CraftedDrinkLevel = ToleranceParser(randomlyCraftedPatron[(int)jsonHelper.TOLERANCE].str);
        Patron.patienceLevels craftedPatience = PatienceParser(randomlyCraftedPatron[(int)jsonHelper.PATIENCE].str);
        Patron patronToReturn = new Patron(craftedName, 0,  CraftedAligence, CraftedType, CraftedDrinkLevel, packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]), craftedPatience , craftedDisposition);
        return patronToReturn;

    }

    private Patron.job jobParser(string jobToParse)
    {
        if (jobToParse == "Warrior")
        {
            return Patron.job.WARRIOR;
        }

        if (jobToParse == "Wizard")
        {
            return Patron.job.WIZARD;
        }
        if (jobToParse == "Rogue")
        {
            return Patron.job.ROUGE;
        }
        if (jobToParse == "Bard")
        {
            return Patron.job.BARD;
        }

        else
        {
            Debug.Log("Warning, job fall through");
            return Patron.job.WARRIOR;
        }
        
    }

    private Patron.disposition dispositionParser(string dispositionToParse)// { TOUGH, CALM, NOBLE, BOOKSMART, EVIL, SILENT }
    {
        switch (dispositionToParse)
        {

            case "TOUGH":
                {
                    return Patron.disposition.TOUGH;
                }
            case "CALM":
                {
                    return Patron.disposition.CALM;
                }
            case "NOBLE":
                {
                    return Patron.disposition.NOBLE;
                }
            case "BOOKSMART":
                {
                    return Patron.disposition.BOOKSMART;
                }
            case "EVIL":
                {
                    return Patron.disposition.EVIL;
                }
            case "SILENT":
                {
                    return Patron.disposition.SILENT;
                }

            default:
                {
                    Debug.Log("Disposition Fall through");
                    return Patron.disposition.CALM;
                }

        }

        
    }

    private Patron.Aligence aligenceParser(string DndToParse)
    {
        if (DndToParse == "College")
        {
            return Patron.Aligence.COLLEGE;
        }

        if (DndToParse == "Corporeal")
        {
            return Patron.Aligence.CORPOREAL;
        }
        if (DndToParse == "AA")
        {
            return Patron.Aligence.AA;
        }

        if (DndToParse == "Evil")
        {
            return Patron.Aligence.EVIL;
        }

        if (DndToParse == "Mafia")
        {
            return Patron.Aligence.MAFIA;
        }

        if (DndToParse == "Daredevil")
        {
            return Patron.Aligence.DAREDEVIL;
        }

        if (DndToParse == "Archaeological")
        {
            return Patron.Aligence.ARCHAEOLOGICAL;
        }

        if (DndToParse == "Nature")
        {
            return Patron.Aligence.NATURE;
        }

        if (DndToParse == "Neighborhood")
        {
            return Patron.Aligence.NEIGHBORHOOD;
        }

        if (DndToParse == "Brewmaster")
        {
            return Patron.Aligence.BREWMASTER;
        }

        if (DndToParse == "None")
        {
            return Patron.Aligence.NONE;
        }

        else
        {
            Debug.Log("Warning, tie fall through");
            return Patron.Aligence.NONE;
        }
        
    }

    private Patron.drinkLevel ToleranceParser(string levelToParse)
    {
        if (levelToParse == "LOW")
        {
            return Patron.drinkLevel.LOW;
        }

        if (levelToParse == "MID")
        {
            return Patron.drinkLevel.MID;
        }
        if (levelToParse == "HIGH")
        {
            return Patron.drinkLevel.HIGH;
        }
        if(levelToParse == "NONE")
        {
            return Patron.drinkLevel.NONE;
        }

        else
        {
            Debug.Log("Warning, Drink Level fall through");
            return Patron.drinkLevel.MID;
        }

    }

    private Patron.patienceLevels PatienceParser(string patienceToParse)
    {
        if (patienceToParse == "LOW")
        {
            return Patron.patienceLevels.LOW;
        }

        if (patienceToParse == "MID")
        {
            return Patron.patienceLevels.MID;
        }
        if (patienceToParse == "HIGH")
        {
            return Patron.patienceLevels.HIGH;
        }
       

        else
        {
            Debug.Log("Warning, Drink Level fall through");
            return Patron.patienceLevels.MID;
        }
    }

    private byte[] packageStats(JSONObject statsToPackage)  // don't know if this is confusing, basicly I just wanted to pass all of the stats as an array and not by themselves. 
    {
        byte[] craftedStates = new byte[4];// Tell me if it is and ill fix it. 
        for (int j= 0; j < statsToPackage.Count; j++)
        {
            craftedStates[j] = (byte)statsToPackage[j].i;
        }
        return craftedStates;
    }
}
