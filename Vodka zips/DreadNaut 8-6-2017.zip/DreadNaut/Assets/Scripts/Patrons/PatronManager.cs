﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PatronManager {

   
    public List<Patron> Regulars = new List<Patron>();

    public void loadRegulars()
    {
        for (int i = 0; i < 8; i++)
        {
           Patron patronToLoad = patronLoader.Instance.spawnNewPatron();
            Regulars.Add(patronToLoad);
        }
    } 

    public Patron DrawAPatron()
    {
        if (Regulars.Count != 0)
        {
            int patronIndexer = Random.Range(0, Regulars.Count);
            Patron patronToReturn = Regulars[patronIndexer];
            Regulars.RemoveAt(patronIndexer);
            resetDefaults(patronToReturn);
            patronToReturn.Patience = assignTimetoWaitInBar(patronToReturn.thisPatronsPatienceLevel);
            patronToReturn.decideOnWhatTheyWantToDrink();
            patronToReturn.WantsToGoOnAdventure =  DoTheyWantToAdventure();
            if (!patronToReturn.WantsToGoOnAdventure)
            {
                patronToReturn.HasRumorToShare = DoTheyHaveRumor();
            }
            Debug.Log("FromPatronManager" + patronToReturn.DrinkThePatronWants.listIngredentsInDrink());
            return patronToReturn;
        }
        else
        {
            Debug.Log("No More Patrons In Line");
            return null;
        }
    }

    public void resetDefaults(Patron patronToReset)
    {
        patronToReset.HasRumorToShare = false;
        patronToReset.WantsToGoOnAdventure = false;
        //drinks had
        // drunkeness;
    }

    public void putAPatronBack(Patron returningPatron)
    {
        Regulars.Add(returningPatron);
    }

    private float assignTimetoWaitInBar(Patron.patienceLevels PatronPatience)
    {
        if(PatronPatience == Patron.patienceLevels.LOW)
        {
            return Random.Range(8, 10);
        }

       else if (PatronPatience == Patron.patienceLevels.MID)
        {
            return Random.Range(10, 15);
        }

       else if (PatronPatience == Patron.patienceLevels.HIGH)
        {
            return Random.Range(15, 20);
        }
        else
        {
            Debug.Log("Patience fall Through");
            return Random.Range(8, 12);
        }

    }

    public bool DoTheyWantToAdventure()
    {
       byte yesNo = (byte)Random.Range(0, 3); // a very rough indicator if a guy wants to go on an adventure; 
        if (yesNo == 2)
            return true;

        else
            return false; 
    }

    public bool DoTheyHaveRumor()
    {
        
        byte yesNo = (byte)Random.Range(0, 3); // a very rough indicator if a has aRumor , I separated these two because I feel we will have two diffrent algorithums on determing rumors and Adventures but for now THEY ARE THE EXACT SAME THING. 
        if (yesNo == 2)
            return true;

        else
            return false;
    }
}
