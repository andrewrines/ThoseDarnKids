﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Patron {


    Quest questStub = new Quest();
    public Quest QuestStub { get { return questStub; } set { questStub = value; } }

    private bool wasQuestSucessful;
    public bool WasQuestSucessful { get { return wasQuestSucessful; } set { wasQuestSucessful = value; } }

    public enum OpinionOnDrink {AWFUL, BAD, SOSO, GOOD, GREAT, PERFECT}
    private OpinionOnDrink thisPatronsOpinion;


    public enum disposition { TOUGH, CALM, NOBLE, BOOKSMART, EVIL, SILENT };
    public disposition thisPatronsDisposition;

     public enum job { WARRIOR = 0, ROUGE, WIZARD, BARD }; // TO REMOVE once I leanr what we plan to do with apperances ( how our guys look and how I find how they look);
     public job thisPatronsJob; 

    public enum Aligence { COLLEGE, CORPOREAL, AA, EVIL, MAFIA, DAREDEVIL, ARCHAEOLOGICAL, NATURE, NEIGHBORHOOD, BREWMASTER, NONE };
    public Aligence thisPatronsAligence;

    public enum drinkLevel { NONE, LOW, MID, HIGH };
    public drinkLevel thisPatronsTolerance;

    public enum StatTypes { STRONG, SMART, SNEAK, SWAY }

    public enum patienceLevels {LOW,MID,HIGH};
    public patienceLevels thisPatronsPatienceLevel;

    private bool wantsToGoOnAdventure;
    public bool WantsToGoOnAdventure { get { return wantsToGoOnAdventure; } set { wantsToGoOnAdventure = value; } }

    private bool hasRumorToShare;
    public bool HasRumorToShare { get { return hasRumorToShare; } set { hasRumorToShare = value; } }

    private bool returningFromAQuest;
    public bool ReturningFromAQuest { get { return returningFromAQuest; } set { returningFromAQuest = value; } }

    private string name;
    public string Name { get { return name; } set { name = value; } }

    private byte level;
    public byte Level { get { return level; } set { level = value; } }

    private float patience;
    public float Patience { get { return patience; } set { patience = value; } }

    private Drink drinkThePatronWants = new Drink();
    public Drink DrinkThePatronWants { get { return drinkThePatronWants; } set { drinkThePatronWants = value; } }

    private byte[] patronsStats;
    public byte[] PatronsStats { get { return patronsStats; } }


    public Patron(string newName, byte newLevel, Aligence newPatronsAligence, job newJob , drinkLevel newDrinkLevel, byte[] newStats, patienceLevels PatronsPatience, disposition newDisposition)
    {
        name = newName;
        level = newLevel;
        thisPatronsJob = newJob;
        thisPatronsDisposition = newDisposition;
        thisPatronsAligence = newPatronsAligence;
        thisPatronsTolerance = newDrinkLevel;
        patronsStats = newStats;
        thisPatronsPatienceLevel = PatronsPatience;
    }


    public OpinionOnDrink compareDrinks(Drink barMadeDrink) // kinda a chunky methoid, may want to throw a bit of it in a helper function. 
    {   
        // TODO A methoid to sort drink components, in a drink ingredents are not order sensitive. 
        thisPatronsOpinion = OpinionOnDrink.PERFECT;
        int ammountInSmallerDrink = 0;
        if (barMadeDrink.countIngredentsInDrink() >= drinkThePatronWants.countIngredentsInDrink())
        {
            ammountInSmallerDrink = drinkThePatronWants.countIngredentsInDrink();
            thisPatronsOpinion -= (barMadeDrink.countIngredentsInDrink() - drinkThePatronWants.countIngredentsInDrink());
        }
        else
        {
            ammountInSmallerDrink = barMadeDrink.countIngredentsInDrink();
            thisPatronsOpinion -=  drinkThePatronWants.countIngredentsInDrink() - (barMadeDrink.countIngredentsInDrink());
        }

        for(int i = 0; i < ammountInSmallerDrink; i++) // barMadeDrink.countIngredentsInDrink()
        {
            if (barMadeDrink.scanIngredent(i) != drinkThePatronWants.scanIngredent(i))
            {
                thisPatronsOpinion--;
            }
        }
        return thisPatronsOpinion;
    }

    public void decideOnWhatTheyWantToDrink()
    {
        drinkThePatronWants.requestADrink();
    }


   //public void attemptStatCheck()
   // {
       
   //         QuestLoader.Trial trialToAttempt = questGoneOn.attemptNextTrial();
   //         if (trialToAttempt.challengeRaiting <= patronsStats[(int)trialToAttempt.challengeType] + RollFor(1, 6)) // Gets patron stat and rolls a D6 no plan for catstrophic failure yet. 
   //         {
   //             questGoneOn.compleeteTrial();
   //             checkIfQuestIsOver();
   //         }
      
   // }

    
}


