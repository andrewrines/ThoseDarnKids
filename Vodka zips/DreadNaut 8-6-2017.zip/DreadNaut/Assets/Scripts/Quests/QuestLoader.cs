﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class QuestLoader {
    string path;
    string jsonString;
    JSONObject questJSONObject;
    ItemParser itemParser; // I don't super like linking two loaders together like this, but I don't know a better way. YET
    enum questParserHelper { NAME, DESCRIPTION, ALLEGIANCE, RIVAL, LENGHT, CHECKS , REWARDS}; // a more visual way to see the construction of the quest
    

    public void JsonQuestInit()
    {
        path = Application.dataPath + "/JsonFiles/QuestsInGame.json";
        jsonString = File.ReadAllText(path);
        questJSONObject = new JSONObject(jsonString);
        itemParser = new ItemParser();


    }

    public Quest questCreator(string nameOfQuestToFind)
    {
        var QuestToFind = questJSONObject[nameOfQuestToFind];
        Quest questToBuild = new Quest(); 
        questToBuild.QuestName = QuestToFind[(byte)questParserHelper.NAME].str;
        questToBuild.QuestDescription = QuestToFind[(byte)questParserHelper.DESCRIPTION].str;
        questToBuild.TimeOnQuest = (int)QuestToFind[(byte)questParserHelper.LENGHT].i;
        questToBuild.TrialsOfTheQuest = questTrialCreator(QuestToFind[(byte)questParserHelper.CHECKS]);
        questToBuild.RewardsFromQuest = questRewardFinder(QuestToFind[(byte)questParserHelper.REWARDS]); // this
        // needs alience as well as rival
        return questToBuild;
    }

    private int rollFor(int min , int max)
    {
        return Random.Range(min, max);
    }

    public struct Trial
    {
       public Patron.StatTypes challengeType;
       public byte challengeRaiting;
        // Effectors Any fun things we can add to a trial to give it more spice. 
        public Trial(Patron.StatTypes ChallengeType, byte ChallengeRaiting)
        {
            challengeType = ChallengeType;
            challengeRaiting = ChallengeRaiting;
        }
       
    }

    private Queue<Trial> questTrialCreator(JSONObject allTrials)
    {
        Queue<Trial> trialsToReturn = new Queue<Trial>();

        for (int i = 0; i < allTrials.Count; i++)
        {
            Patron.StatTypes statToCheck = determineStatType(allTrials[i][0].str);
            byte difficulty = (byte)allTrials[i][1].i;
            Trial trialToQueue = new Trial(statToCheck, difficulty);
            trialsToReturn.Enqueue(trialToQueue);
        }
        return trialsToReturn;
    }

  

    private Patron.StatTypes determineStatType(string statToDetermine)
    {
        if (statToDetermine == "Strong")
        {
            return Patron.StatTypes.STRONG;
        }

        if (statToDetermine == "Smart")
        {
            return Patron.StatTypes.SMART;
        }

        if (statToDetermine == "Sneak")
        {
            return Patron.StatTypes.SNEAK;
        }

        if (statToDetermine == "Sway")
        {
            return Patron.StatTypes.SWAY;
        }

        else
        {
            Debug.Log("Trial Stat FallThrough");
            return Patron.StatTypes.STRONG;
        }

        
    }

    private List<StoreableItem> questRewardFinder(JSONObject allRewards)
    {
        
        List<StoreableItem> itemsToReturn = new List<StoreableItem>();
        for (int i = 0; i < allRewards.Count; i++)
        {
            itemsToReturn.Add(itemParser.itemFactory(findOutWhatKindOfItemItIs(allRewards[i][0].str), allRewards[i][1].str, (int)allRewards[i][2].i));
        }
        return itemsToReturn;

    }

    private ItemParser.KindOfItem findOutWhatKindOfItemItIs(string whatKindOfItem)
    {
        switch(whatKindOfItem)
        {
            case "EQU":
                {
                    return ItemParser.KindOfItem.EQU;
                }

            case "GOLD":
                {
                    return ItemParser.KindOfItem.GOLD;
                }

            case "ING":
                {
                    return ItemParser.KindOfItem.ING;
                }

            default:
                {
                    Debug.Log("Fall through on search of reward type, im in quest loader");
                    return ItemParser.KindOfItem.GOLD;
                }

        }
    }
}
