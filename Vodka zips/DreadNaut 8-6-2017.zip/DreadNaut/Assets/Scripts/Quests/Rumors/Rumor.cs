﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Rumor
{
    private string rumorName;
    public string RumorName { get { return rumorName; } set { rumorName = value; } }

    private string rumorDescription;
    public string RumorDescription { get { return rumorDescription; } set { rumorDescription = value; } }

    private string patronWhoGaveRumor;
    public string PatronWhoGaveRumor { get { return patronWhoGaveRumor; } set { patronWhoGaveRumor = value; } }

    private List<string> questsToFind = new List<string>();
    public List<string> QuestsToFind { get { return questsToFind; } }

    public void addElementToQuestsToFind(string questNameToFind)
    {
        questsToFind.Add(questNameToFind);
    }


    private List<Quest> questsForThisRumor = new List<Quest>();
    public List<Quest> QuestForThisRumor { get { return questsForThisRumor; }  }

    public void addElementToQuests(Quest questToAdd)
    {
        questsForThisRumor.Add(questToAdd);
    }
}
