﻿using UnityEngine;
using System.Collections;

public class Ingredent : StoreableItem {

    public enum ingredentColor {RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE }
    private ingredentColor thisIngredentsColor;
    public ingredentColor ThisIngredentsColor { get { return thisIngredentsColor; } }

	public Ingredent(ingredentColor ThisIngredentsColor)
    {
        thisIngredentsColor = ThisIngredentsColor;
    }

    
}
