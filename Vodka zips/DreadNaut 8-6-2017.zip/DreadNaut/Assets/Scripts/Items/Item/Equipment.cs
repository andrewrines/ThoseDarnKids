﻿using UnityEngine;
using System.Collections;

public class Equipment : StoreableItem
{
    private string equipmentName;
    public string EquipmentName { get { return equipmentName; } set { equipmentName = value; } }

    public enum howIsThisGoingToLook {GOLD, SWORD, KNIFE, STAFF, POTION, BOOTS, ARMOR, SHEILD };
    private howIsThisGoingToLook howDoesThisItemLook;
    public howIsThisGoingToLook HowDoesThisItemLook { get { return howDoesThisItemLook; } set { howDoesThisItemLook = value; } }

    // enum of effects, 
}
