﻿using UnityEngine;
using System.Collections;
using System.IO;

public class ItemParser  {   //IDEA and TODO, merge all loaders into some sort of parent loader class. 
    
        string path;
        string jsonString;
        JSONObject itemToReturn;
        public enum KindOfItem{ING,EQU,GOLD};


    public ItemParser()
    {
        path = Application.dataPath + "/JsonFiles/ItemsInGame.json";
        jsonString = File.ReadAllText(path);
        itemToReturn = new JSONObject(jsonString);
    }

    public StoreableItem itemFactory(KindOfItem whatItemToFind, string nameOfItemToFind, int ammountOfItem)
    {

        switch(whatItemToFind)
        {
            case KindOfItem.ING:
                {
                    Ingredent ingredentToReturn = new Ingredent(ingredentLookup(nameOfItemToFind));
                    ingredentToReturn.NumberLeft = ammountOfItem;
                    return ingredentToReturn;
                }

            case KindOfItem.GOLD:
                {
                    Equipment GoldToReturn = new Equipment();
                    GoldToReturn.HowDoesThisItemLook = Equipment.howIsThisGoingToLook.GOLD;
                    GoldToReturn.NumberLeft = ammountOfItem;
                    return GoldToReturn;
                }
            //case KindOfItem.EQU:
            //    {
            //        // later when I figgure out items... sorry
            //    }



            default:
                {
                    Debug.Log("Fall through on  prize");
                    Equipment GoldToReturn = new Equipment();
                    GoldToReturn.HowDoesThisItemLook = Equipment.howIsThisGoingToLook.GOLD;
                    GoldToReturn.NumberLeft = ammountOfItem;
                    return GoldToReturn;
                }
        }
    }


    private Ingredent.ingredentColor ingredentLookup(string ingredentColorToFind)
    {
        switch(ingredentColorToFind)
        {
            case "RED":
                return Ingredent.ingredentColor.RED;

            case "ORANGE":
                return Ingredent.ingredentColor.ORANGE;

            case "YELLOW":
                return Ingredent.ingredentColor.YELLOW;

            case "GREEN":
                return Ingredent.ingredentColor.GREEN;

            case "BLUE":
                return Ingredent.ingredentColor.BLUE;

            case "PURPLE":
                return Ingredent.ingredentColor.PURPLE;

            default:
                Debug.Log("Fall through on ingredent color prize");
                    return Ingredent.ingredentColor.RED;
        }
    }


    
       
     
    }
