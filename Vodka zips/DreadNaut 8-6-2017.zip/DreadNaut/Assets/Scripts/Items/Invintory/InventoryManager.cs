﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class InventoryManager : MonoBehaviour { // decided to let objects handle their own ui elements. 

    public InvintorySlot[] invintorySlots;
    public Text goldOnScreen;
    private List<StoreableItem> thePlayersInvintory = new List<StoreableItem>();
    private int gold;
    public int Gold { get { return gold; } set { gold = value; } }
    private ItemParser itemParser;  // when we add other items into the game; 



    public void Start()
    {
       loadStarterPack();
       initInvintory();
        displayGold();
    }
        
    
    public void loadStarterPack()
    {
        gold = 500;
        for (Ingredent.ingredentColor i = 0;  i <= Ingredent.ingredentColor.PURPLE; i++) // gives the player 50 of each ingredent to start;
        {
            addIngredentToInvintory(i, 5);
        }
    }

   

    public void initInvintory()
    {
        int j = 0;
       foreach (Ingredent i in thePlayersInvintory)
        {
            invintorySlots[j].setItemToDisplay(i);
            invintorySlots[j].ShowNumberRemaining();
            invintorySlots[j].ShowWhatThisIngredentLooksLike();
            j++;
        }

        for (int k = j; k < invintorySlots.Length; k++)  // Is this bad? 
        {
            invintorySlots[k].gameObject.SetActive(false);
        }

    }

    public void addIngredentToInvintory(Ingredent.ingredentColor colorOfIngredentToAdd, int numberOfIngredentToAdd)
    {
         
        bool isItemFound = false;
        foreach (Ingredent i in thePlayersInvintory)
        {
            if (i.ThisIngredentsColor == colorOfIngredentToAdd)
            {
                i.NumberLeft += numberOfIngredentToAdd;
                isItemFound = true;
            }
        }
        if (!isItemFound)
        {
            Ingredent ingredentToAdd = new Ingredent(colorOfIngredentToAdd);
            ingredentToAdd.NumberLeft += numberOfIngredentToAdd;
            thePlayersInvintory.Add(ingredentToAdd);
           
        }
    }

    public Ingredent useIngredentFromInvintory(byte slotToUse)
    {
        Ingredent ingredentToReturn = new Ingredent(invintorySlots[slotToUse].getItemToDisplay().ThisIngredentsColor); // if everything goes wrong, this wasn't here
            invintorySlots[slotToUse].getItemToDisplay().NumberLeft--;
            invintorySlots[slotToUse].ShowNumberRemaining();
      
       if  (invintorySlots[slotToUse].getItemToDisplay().NumberLeft == 0)
            {
            Debug.Log("None left of ingredent");
            thePlayersInvintory.Remove(invintorySlots[slotToUse].getItemToDisplay());
            initInvintory();
            }
        return ingredentToReturn;//invintorySlots[slotToUse].getItemToDisplay();
    }


    public void addGold(int itemIsSoldFor)
    {
        gold += itemIsSoldFor;
        displayGold();
    }

    public void displayGold()
    {
        goldOnScreen.text = "Gold:" + gold;
    }
}

   


