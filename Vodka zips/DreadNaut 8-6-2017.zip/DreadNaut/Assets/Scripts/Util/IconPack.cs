﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class IconPack : MonoBehaviour {

    public Sprite patronWantsAdventureSprite;
    public Sprite patronWantsDrinkSprite;
    public Sprite patronHasRumorSprite;

    SpriteRenderer spriteToDisplay;

    public void Start()
    {
        spriteToDisplay = this.GetComponent<SpriteRenderer>();
       
    }

    public void PatronWantsToGoOnAnAdventure()
    {
        this.gameObject.SetActive(true);
        spriteToDisplay.sprite = patronWantsAdventureSprite;
    }

    public void patronWantsToDrink()
    {
        this.gameObject.SetActive(true);
        spriteToDisplay.sprite = patronWantsDrinkSprite;
        
    }

    public void patronWantsToTellYouSomething()
    {
        this.gameObject.SetActive(true);
        spriteToDisplay.sprite = patronHasRumorSprite;
    }

    public void clearNeedsIcons()
    {
        this.gameObject.SetActive(false);
    }

    
}
