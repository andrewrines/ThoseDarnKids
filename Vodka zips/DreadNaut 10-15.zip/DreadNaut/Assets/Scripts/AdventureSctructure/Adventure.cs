﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class Adventure
{
    Color colorWhenSelected;
    Color colorWhenNotSelected;

    public bool isAdventureOver = false; // NC added 9/24 not sure if this is the best way to go about this, want to inform map manager that the quest is over without passing adventure nodes, swaps in advance location method I added

    List<AdventureNode> AdventureNodes = new List<AdventureNode>(); //A list of all the nodes the patron will travel to throughout the adventure .. nc made public for debug purpose
    AdventureNode NodeUnderConstruction;                                //As a player clicks on locations and quests, this temporary node will hold the info
                                                                        //Will eventually to be added to AdventureNodes

    Patron patronOnAdventure;   //The patron that will be on this adventure
    public Patron PatronOnAdventure{get { return patronOnAdventure; }}//pardon my reach

    public Adventure(Patron desiredPatron, Location startingNode, Color _colorWhenSelected, Color _colorWhenNotSelected)
    {
        patronOnAdventure = desiredPatron;
        colorWhenSelected = _colorWhenSelected;
        colorWhenNotSelected = _colorWhenNotSelected;

        //make the first node the bar
        NodeUnderConstruction = new AdventureNode();

        SetNodeUnderConstructionToDefault();
        SetNodeLocation(startingNode, null);
        ConfirmNewNode();
    }

    struct AdventureNode  // made public for debug purposes NC Privitized this
    {
        public Location location;
        public Quest targetQuest;
        public Road roadHighlighted;
    }

    public void SetNodeLocation(Location desiredLocation, Road connectingRoad)
    {
        if (desiredLocation != null)
        {
            desiredLocation.GetComponent<Image>().color = colorWhenSelected;
            NodeUnderConstruction.location = desiredLocation;
        }

        if (connectingRoad != null)
        {
            connectingRoad.GetComponent<Image>().color = colorWhenSelected;
            NodeUnderConstruction.roadHighlighted = connectingRoad;
        }

    }

    public void SetNodeQuest(Quest desiredQuestName) 
    {
        NodeUnderConstruction.targetQuest = desiredQuestName;  
    }

    void SetNodeRoadToHighlight(Road desiredRoad)
    {
        NodeUnderConstruction.roadHighlighted = desiredRoad;
    }

    public void ConfirmNewNode()
    {
        AdventureNodes.Add(NodeUnderConstruction);
        SetNodeUnderConstructionToDefault();
    }

    public void SetNodeUnderConstructionToDefault()
    {
        NodeUnderConstruction.location = null;
        NodeUnderConstruction.targetQuest = null;
        NodeUnderConstruction.roadHighlighted = null;
    }

    public bool IsLocationAlreadyInAdventure(Location locationToCheck)
    {
        for (int i = 0; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].location == locationToCheck)
                return true;
        }

        return false;
    }

    public void RemoveAllNodesPastGivenNodeLocation(Location desiredLastLocation)
    {
        int foundIndex = -1;

        for (int i = 0; i < AdventureNodes.Count; i++) 
        {
            if(foundIndex != -1 && i > foundIndex)
            {
                AdventureNodes[i].location.GetComponent<Image>().color = colorWhenNotSelected;
                AdventureNodes[i].roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected;
            }
            else if(AdventureNodes[i].location == desiredLastLocation)
            {
                foundIndex = i;
            }
        }

        if(foundIndex != -1)
            AdventureNodes.RemoveRange(foundIndex + 1, AdventureNodes.Count-(foundIndex+1));

    }

    void RemoveAllNodesPastGivenNodeLocation(int locationIndex)
    {
        for (int i = locationIndex; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].location != null) { AdventureNodes[i].location.GetComponent<Image>().color = colorWhenNotSelected; }
            if (AdventureNodes[i].roadHighlighted != null) { AdventureNodes[i].roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected; }
        }
        if (NodeUnderConstruction.roadHighlighted != null) { NodeUnderConstruction.roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected; }
        if (NodeUnderConstruction.location != null) { NodeUnderConstruction.location.GetComponent<Image>().color = colorWhenNotSelected; }

    }

    public void ClearAdventure()
    {
        RemoveAllNodesPastGivenNodeLocation(0);
    }

    public void advanceToNextLocation() // NC added 9/24
    {
        AdventureNodes.RemoveAt(0);

        if (AdventureNodes.Count == 0)
        {
            Debug.Log(patronOnAdventure.Name + "Is done with their adventure");
            isAdventureOver = true;
        }
        else
        {
            resolveLocationEvents();
        }

    }

    public void resolveLocationEvents()
    {
       
        if (AdventureNodes[0].targetQuest != null && PatronOnAdventure.QuestsToCompleete[0] == AdventureNodes[0].targetQuest && AdventureNodes[0].targetQuest.getQuestStatus() == Quest.questStatus.PENDING) // Three &&, I need to find a better way
        {
            rollForQuest();
        }


    }

    private void rollForQuest()
    {
        Debug.Log(PatronOnAdventure.Name + " Is attempting " + AdventureNodes[0].targetQuest.QuestName);

        for (int i = 0; i < AdventureNodes[0].targetQuest.TrialsOfTheQuest.Count; i++ ) //PatronOnAdventure.QuestsToCompleete[0]
        {
            // QuestLoader.Trial trialToTest = PatronOnAdventure.QuestsToCompleete[0].TrialsOfTheQuest[i];
            QuestLoader.Trial trialToTest = AdventureNodes[0].targetQuest.TrialsOfTheQuest[i];
            byte patronsRoll = PatronOnAdventure.rollPatronStat(trialToTest.challengeType);
            Debug.Log(PatronOnAdventure.Name + " : " + patronsRoll + " VS " + trialToTest.challengeType+ " : " + trialToTest.challengeRaiting +" Trial number:" + i);

            trialToTest.challengeRaiting = (sbyte)(trialToTest.challengeRaiting - patronsRoll);
            Debug.Log("Our new raiting is " + trialToTest.challengeRaiting);

            if (trialToTest.challengeRaiting <= 0)
            {
                trialToTest.challengeRaiting = 0; // sets the guy to zero, so we don't have players gaining any stats from passing a quest.
                // PENDING This guy is causing a lot more problems then it is fixing: PatronOnAdventure.QuestsToCompleete[0].TrialsOfTheQuest.Remove(trialToTest); // This removes the trial to lessen the count in damage step later, if we need to describe trials, I suggest removing this. 
            }

                AdventureNodes[0].targetQuest.TrialsOfTheQuest[i] = trialToTest;
            
            //if (patronsRoll < trialToTest.challengeRaiting)
            //{
            //    PatronOnAdventure.fatiguePatron(trialToTest.challengeType, (byte)(trialToTest.challengeRaiting -patronsRoll));
            //    Debug.Log("AHHHH a nasty gash for " + (trialToTest.challengeRaiting - patronsRoll) + " Fatigue");

            //    if (patronOnAdventure.IsExhausted)
            //    {
            //        Debug.Log(patronOnAdventure.Name + " is exhaused, they are returning to base");
            //        PatronOnAdventure.QuestsToCompleete[0].IsQuestSucessful = false;
            //        isAdventureOver = true; // i don't know if this is ok, clears all adventures and tells the map manager that the quest is in fact over.
            //        break; // breaks, we don't test anymore if someone fails outright
            //    }
            //}


        }

        //if (!isAdventureOver)
        //{
        //    Debug.Log("They did the quest");
        //    PatronOnAdventure.QuestsToCompleete[0].IsQuestSucessful = true;
        //}

        //PatronOnAdventure.reSortQuests();

    }

    public void assignAllQuestsToPatron() // This ensures that the list of quests the patron wants to go on is finalized, I ran into an error with selecting and unslecting locations and logging the quest multiple times. 
    {
        foreach (AdventureNode a in AdventureNodes)
        {
            if (a.targetQuest != null)
            {
                PatronOnAdventure.QuestsToCompleete.Add(a.targetQuest);
                a.targetQuest.incrementNumberOfPatronsOnQuest();

                if (a.targetQuest.IsMaxOccupancy)
                {
                    a.location.removeQuestFromLocation(a.targetQuest);
                }
            }
        }
    }

    public void cleanUpPhase() //applyExhaustion() // I don't super love this, it repeats code again, only its needed at a diffrent time, specifically after each patron has had their go at the quest. 
    {
        if (AdventureNodes[0].targetQuest != null)
        {
            applyExhaustion();
            checkWinCondition();
            // check location for quest and remove
            PatronOnAdventure.reSortQuests();
        }
    }

    private void applyExhaustion()
    {
            for (int i = 0; i < AdventureNodes[0].targetQuest.TrialsOfTheQuest.Count; i++)
            {
                QuestLoader.Trial trialToTest = PatronOnAdventure.QuestsToCompleete[0].TrialsOfTheQuest[i];
                PatronOnAdventure.fatiguePatron(trialToTest.challengeType, (byte)(trialToTest.challengeRaiting));
                Debug.Log(PatronOnAdventure.Name + " Took " + (trialToTest.challengeRaiting) + " Fatigue");
            }
    }

    private void checkWinCondition()
    {
        if (!PatronOnAdventure.IsExhausted) // I check this twice, need to find a place to only check this once. 
        {
            AdventureNodes[0].targetQuest.setToPass();
            AdventureNodes[0].location.removeQuestFromLocation(AdventureNodes[0].targetQuest);
        }
        else
        {
            AdventureNodes[0].targetQuest.incrementAttemptsOnQuest();
            checkIfThisIsFinalTry();
            isAdventureOver = true; // ends our patrons adventure, sending them back to base. 
            Debug.Log(patronOnAdventure.Name + " Was simply to tired to continue");
        }
    }

    private void checkIfThisIsFinalTry()
    {
        if (AdventureNodes[0].targetQuest.AttemptsOnQuest == AdventureNodes[0].targetQuest.MaxNumberOfPatronsOnQuest)
        {
            AdventureNodes[0].targetQuest.setToFail();
        }
    }

    public string About() //For debugging purposes
    {
        string aboutMessage =
            patronOnAdventure.Name + " is completing...\n";

        for (int i = 0; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].targetQuest != null)
                aboutMessage += AdventureNodes[i].targetQuest.QuestName + " at ";
            else
                aboutMessage += "no quest at ";

            if (AdventureNodes[i].location != null)
                aboutMessage += AdventureNodes[i].location.Name + "\n";
            else
                aboutMessage += "some unknown location\n";
        }

        Debug.Log("THERE are " + AdventureNodes.Count + " Quests left");

        return aboutMessage;
    }

   
}
