﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PatronCheatSheet : MonoBehaviour {

    [SerializeField]
    Text patronName;

    [SerializeField]
    Image patronPortrait; // to add

    [SerializeField]
    Image patronFactionPortrait; // to add

    [SerializeField]
    Text patronFaction;

    [SerializeField]
    Text patronLevel;

    [SerializeField]
    Text patronExp;

    [SerializeField]
    Text patronStrong;

    [SerializeField]
    Text patronSmart;

    [SerializeField]
    Text patronSneak;

    [SerializeField]
    Text patronSway;

    [SerializeField]
     Color PoorStat;

    [SerializeField]
    Color CommonStat;

    [SerializeField]
     Color GoodStat;

    [SerializeField]
     Color GreatStat;

    [SerializeField]
     Color BestStat;

    private Color[] colorsOfStat;
    private Text[] statsToList;

    public void activatePatronCheatSheet()
    {
        if (statsToList == null)
        {
            initStatsToList();
        }

        if (colorsOfStat == null)
        {
            initColorOfStat();
        }

        this.gameObject.SetActive(true);
    }

    public void deactivatePatronCheatSheet()
    {
        this.gameObject.SetActive(false);
    }

    public void displayStats(Patron patronToDisplay)
    {
        patronName.text = patronToDisplay.Name;
        patronFaction.text = patronToDisplay.thisPatronsAligence.ToString();
        patronLevel.text = "Level: " + patronToDisplay.Level.ToString();
        patronExp.text = "XP: " + patronToDisplay.ExperiencePoints.ToString() + " / " + patronToDisplay.ExperienceThresholdToNextLevel.ToString();

        patronPortrait.sprite = ApperanceManager.instance.HowThisPatronLooks(patronToDisplay.ID);

        for (Patron.StatTypes j = 0; j < Patron.StatTypes.LENGTH ; j++)
        {
            // patronStatsText.text += j + ": " + endOfDayManager.PatronsInRegulars[i].PatronsStats[(byte)j] + "\n";
            statsToList[(byte)j].text =  StatDescriptorLoader.Instance.statOut(j, patronToDisplay.PatronsBaseStats[(byte)j]) + " : " + patronToDisplay.PatronsFatigueStats[(byte)j] + "\n"; // gonna throw this one through the ole string builder later on. 
            statsToList[(byte)j].color = colorsOfStat[StatDescriptorLoader.Instance.numberModifyer((byte)j, patronToDisplay.PatronsBaseStats[(byte)j])]; 
        }
    }

    private void initStatsToList()
    {
        statsToList = new Text[4];
        statsToList[0] = patronStrong;
        statsToList[1] = patronSmart;
        statsToList[2] = patronSneak;
        statsToList[3] = patronSway;
    }

    private void initColorOfStat()
    {
        colorsOfStat = new Color[5];
        colorsOfStat[0] = new Color(PoorStat.r, PoorStat.g, PoorStat.b);
        colorsOfStat[1] = new Color(CommonStat.r, CommonStat.g, CommonStat.b);
        colorsOfStat[2] = new Color(GoodStat.r, GoodStat.g, GoodStat.b);
        colorsOfStat[3] = new Color(GreatStat.r, GreatStat.g, GreatStat.b);
        colorsOfStat[4] = new Color(BestStat.r, BestStat.g, BestStat.b);
    }



}
