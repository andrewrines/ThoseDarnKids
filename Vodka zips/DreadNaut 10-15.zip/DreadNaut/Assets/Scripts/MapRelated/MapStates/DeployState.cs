﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class DeployState : MonoBehaviour, IMapStates
{

    enum MapState { INACTIVE, CONVERTING_RUMOR_TO_QUEST, SETTING_ADVENTURE_LOCATION, CHOOSING_QUEST }
    MapState currentMapState = MapState.INACTIVE;

    [SerializeField]
    Location startingLocation; //the location of the bar (every patron will start off here)

    [SerializeField]
    Color colorWhenSelectedForAdventure;
   [SerializeField]
    Color colorWhenNotSelectedForAdventure;

    [SerializeField]
   PatronCheatSheet patronCheatSheet;

    [SerializeField]
    Button acceptAdventure;

    [SerializeField]
    Button cancleAdventure;




    MapManager mapManager;
    Location currentLocation = null;
    Adventure AdventureUnderConstruction;

    public DeployState (MapManager mapsly)
    {
        mapManager = mapsly;
    }

    public void closeMapProps()
    {
       patronCheatSheet.deactivatePatronCheatSheet();
       HideQuestInfoPanel();
       acceptAdventure.gameObject.SetActive(false);
       cancleAdventure.gameObject.SetActive(false);
       AdventureUnderConstruction.ClearAdventure();
    }

    public void nodeClicked(Location clickedLocation)
    {
        if (currentLocation.IsAdjacentToLocation(clickedLocation) && !AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation) && currentMapState != MapState.CHOOSING_QUEST)
        {
            Road r = currentLocation.FindRoadConnectedBetweenLocations(clickedLocation);

            currentLocation = clickedLocation;

            AdventureUnderConstruction.SetNodeLocation(clickedLocation, r);
            mapManager.MapVisualEffectScript.ZoomMapInToLocation(clickedLocation); // Bowdish Code added 10/8
            currentMapState = MapState.CHOOSING_QUEST;
            ShowQuestInfoPanel();
        }
        else if (AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation))
        {
            AdventureUnderConstruction.RemoveAllNodesPastGivenNodeLocation(clickedLocation);
            currentLocation = clickedLocation;
        }
    }

    public void openMapProps()  
    {
        currentLocation = startingLocation;
        if (AdventureUnderConstruction != null) { AdventureUnderConstruction.ClearAdventure(); } //wipe the temporary adventure, just to be safe
        AdventureUnderConstruction = new Adventure(mapManager.PatronToGoOnAdventure, startingLocation, colorWhenSelectedForAdventure, colorWhenNotSelectedForAdventure);
        patronCheatSheet.activatePatronCheatSheet();
        patronCheatSheet.displayStats(mapManager.PatronToGoOnAdventure);
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        acceptAdventure.gameObject.SetActive(true);
        cancleAdventure.gameObject.SetActive(true);
        
    }

    public void AddQuestToAdventure() //Called when the player clicks the "Choose quest" add quest button (while creating an adventure) This is called from a bit of a hacky place (the button calls from this exact class), Ill incoporate it into the command pattern in a while. 
    {
        AdventureUnderConstruction.SetNodeQuest(mapManager.getQuestInfoPanel.GetQuestFromLocation());
        AdventureUnderConstruction.ConfirmNewNode();
        mapManager.MapVisualEffectScript.ZoomMapOutOfLocation(currentLocation); // Bowdish code 10/8
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        HideQuestInfoPanel();
    }


    public void ShowQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(true);
        mapManager.getQuestInfoPanel.InitializeQuestInfoPanel(currentLocation);
    }

    public void HideQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(false);
    }

    public void FinishTaskOnMap()
    {
        AdventureUnderConstruction.assignAllQuestsToPatron();
        mapManager.addAdventureToAllAdventures(AdventureUnderConstruction);
    }

    public void GetRefrenceOfMapManager(MapManager constructMapManager)
    {
        mapManager = constructMapManager;
    }

    //public void FinishBuildingAdventure()   //Called when the player clicks the "Confirm Adventure" button (while creating an adventure)  Same as above.
    //{

    //}
}
