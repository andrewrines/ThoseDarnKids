﻿using UnityEngine;
using System.Collections;

public class PatronFactory{

	public void createNewPatron()
    {
        Debug.Log("NoMorePatrons");
       // Patron patronToCreate = new Patron((Patron.patienceLevels)Random.Range(0,(int)Patron.patienceLevels.HIGH));
        //return patronToCreate;
    }
}
