﻿using UnityEngine;
using System.Collections;

public class BarManager : MonoBehaviour {
    IBarManagerState noPatronHighlighted;
    IBarManagerState patronHighlighted;
    IBarManagerState patronClicked;
    IBarManagerState barPaused;
    IBarManagerState duckedDown;

    IBarManagerState barManagerState;

    private PatronManager Pmanager;
    private AdventureManager adventureManager;
    public BookOfQuests bookOfQuests;
    public TimeOfDayManager TimeManager;
    public InventoryManager inventoryManager;
    public EndOfDayManager endOfDayManagement;
    public Seat[] Seats = new Seat[3];
    public FillableMug fillableMug;
    public BattleReportManager battleReportManager;
    private Seat selectedSeat;
    public Seat SelectedSeat { get { return selectedSeat; } set { selectedSeat = value; } }
    public OrderManager orderManager;
    TimeOfDayManager.TimeOfDay barTimeTracker;
    RumorManager rumorManager; 



    void Start()
    {
        rumorManager = new RumorManager();
        rumorManager.initRumorWarehouse();
        Pmanager = new PatronManager();
        Pmanager.init();
        adventureManager = new AdventureManager();
        adventureManager.initAdventureManager();
    }

    void Update()
    {    
        for (int i = 0; i < Seats.Length; i++)
        {
            if (Seats[i].IsReadyForRespawn == true)
            {
                replaceBarPeople(i);
            }
           else if (Seats[i].IsNeedClear == true)
            {
                Pmanager.putAPatronBack(Seats[i].patron); // here if trouble happens, seperating the two so I can reuse clearASeat() in our send a guy out methoid, making it safe for end of day and 
                clearASeat(Seats[i]);
            }
        }

        checkTimeOfDay();
    }

    private void replaceBarPeople(int personToReplace)
    {
        if (TimeManager.CurrentTimeOfDay != TimeOfDayManager.TimeOfDay.CLOSED)
        {
            Patron p = Pmanager.DrawAPatron();
            p.OrderThePatronWants = orderManager.makeAnOrder();
            Seats[personToReplace].FillSeat(p);

        }
    }

    public void clearASeat(Seat seatToClear)
    {
       // Pmanager.putAPatronBack(seatToClear.patron);
        seatToClear.patron = null;
         seatToClear.EmptySeat();
       
        if (TimeManager.CurrentTimeOfDay == TimeOfDayManager.TimeOfDay.CLOSED)
        {
            checkIfBarIsEmpty();
            seatToClear.IsTimerPaused = true;  // HACK
        }
      
         seatToClear.setSeatTimer(TimeManager.patronOutOfSeatTimeBasedOnTimeOfDay());

    }

    private void checkTimeOfDay() 
    {
        if (barTimeTracker != TimeManager.CurrentTimeOfDay)
        {
            if (TimeManager.CurrentTimeOfDay == TimeOfDayManager.TimeOfDay.CLOSED)
            {
                checkIfBarIsEmpty();
            }
            Pmanager.TimeOfDayForPatronManager = TimeManager.CurrentTimeOfDay;
            barTimeTracker = TimeManager.CurrentTimeOfDay;
            
        }
    }

    private void checkIfBarIsEmpty()
    {
        bool isBarEmpty = true; 
        foreach (Seat s in Seats)
        {
            if (s.patron != null)
            {
                isBarEmpty = false;
                break;
            }
        }

        if (isBarEmpty)
        {
            endTheDay();
        }
    }


    public BarManager()
    {
        noPatronHighlighted = new NoPatronHighlighted(this);
        patronHighlighted = new PatronHighlighted(this);
        patronClicked = new PatronClicked(this);
        barPaused = new BarPaused(this);
        duckedDown = new DuckedDown(this);

        barManagerState = noPatronHighlighted;
    }

    public void setBarState(IBarManagerState newBarManagerState)
    {
        barManagerState = newBarManagerState;
    }

    public void ClearPatronHighlight()
    {
       
        barManagerState.ClearPatronHighlight();
    }

    public void MouseOverPatron(Seat pickedSeat)
    {
        //selectedSeat = pickedSeat;
        //Debug.Log(selectedSeat.patron.Name);
        barManagerState.MouseOverPatron(pickedSeat); // blank
    }

    public void ClickPatron()
    {
        barManagerState.ClickPatron();
    }

    public void ChangeStance()
    {
        barManagerState.ChangeStance();
    }


    public void MakeDrink(byte itemSlotToUse)
    {
        barManagerState.MakeDrink(itemSlotToUse);
        SoundManager.Instance.AddCommand("AddIngredent");
    }

    public void sellDrink()
    {

      int money = orderManager.determineDrinkPrice(selectedSeat.patron.OrderThePatronWants, fillableMug.DrinkInMug);
      Debug.Log("Earned " + money);
        inventoryManager.addGold(money);
    }

    public void serveDrink()
    {
        sellDrink();
        SelectedSeat.ConsumeBeverage(fillableMug.DrinkInMug);
        fillableMug.DrinkInMug.clearIngredentsInDrink();
        checkIfPatronSharesRumor();

        selectedSeat.patron.OrderThePatronWants = orderManager.makeAnOrder();
    }

    public void checkIfPatronSharesRumor()  // Added 7/19/17 not sure if this is any good. Checks to see if the patron spills the beans, if so, a quest is added to the rumor mill and it tells the seat to play a specal diolouge from a special function, and that the guy no longer has a rumor
    {
        if (selectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.RUMOR)
        {
            byte chanceOfSharedRumor = (byte)Random.Range(1, 3);  // not final on algorithum. 
            if (chanceOfSharedRumor == 2)
            {
                //board adds rumor to rumor mill
                selectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
                selectedSeat.PatronSharesARumor(); // uses the new added function to give the player a specefic diolouge about quests, may have a paramiter at some point to give name of quest or a few details. 
                endOfDayManagement.addRumor(rumorManager.getRandomRumorFromWarehouseByLevel(selectedSeat.patron.Level)); // OK so my thought was that since the game doesnet need to know about rumors until the end of the day, why not just hand the rumors one at a time to the end of day manager. 
                Debug.Log("RumorShared");
                
            }
        }
    }

    public void recycleDrink()
    {
        inventoryManager.refundIngredents(fillableMug.DrinkInMug);
        fillableMug.DrinkInMug.clearIngredentsInDrink();
        fillableMug.gameObject.SetActive(false);
       // setBarState(noPatronHighlighted);
    }

    public void startNextDay()
    {
        TimeManager.startNewDay();
        isTimePaused(false);
        endOfDayManagement.closeEndOfDayScreen();
        bookOfQuests.PagesInTheBookOfQuests = endOfDayManagement.QuestsToSendToTheBook; // passes the list of quests form the end of day manager to the book of quests;
        adventureManager.passTime(); // all quests in the adventure manager advance one day forward, if last day, patrons test against quest.  
        passAllFinishedPatronsToPatronManager();  // all idle adventurers return to regulars for further instuction
    }

   
    #region swapCommands
    public IBarManagerState getYesHighlight()
    {
        return patronHighlighted;
    }

    public IBarManagerState getNoHighlight()
    {
        return noPatronHighlighted;
    }

    public IBarManagerState getYesClick()
    {
        return patronClicked;
    }

    public IBarManagerState barIsPaused()
    {
        return barPaused;
    }

    public IBarManagerState DuckBeneathBar()
    {
        return duckedDown;
    }

    #endregion

    private void endTheDay()
    {
        AquirePatronManagerInformationForEndOfDayManager(); 
        recycleDrink(); // throws away current drink, possibly refunds ingredents? need to ask design when the great big drink patch comes in. 
        endOfDayManagement.pullUpEndOfDayScreen(); // pulls up end of day screen
        transferAllTakenQuestsToAdventureManager(); // checks the book for marked for removal quests, then transfers them over to the adventure manager.                                      // isTimePaused(true); // here
        Debug.Log("Our bar is empty, Pulling Up Manager");
    }

    public void AquirePatronManagerInformationForEndOfDayManager() // I don't know if this is right, It asks the patronManager to directly give the list of patrons to the end of the day manager. 
    {
        endOfDayManagement.AllPatronsTheBartenderKnows = Pmanager.AllKnownPatrons;
    }

    public void acceptQuestInBookOfQuests()
    {
        selectedSeat.patron.IsOnQuest = true; // marks our patron as on quest in the end of day rumor page. 
        bookOfQuests.sendPatronOnQuest(); // assigns patron to list of patrons in selected quest  //selectedSeat.patron
        bookOfQuests.markQuestForRemoval(); // marks book quest to be removed at the end of the day. 
        clearASeat(selectedSeat);
        closeBookOfQuests(); // closes the book
        inventoryManager.payGold(bookOfQuests.CostOfQuest);
        Debug.Log(Pmanager.Regulars.Count);
    }
  

    public void closeBookOfQuests()
    {
        isTimePaused(false);
        bookOfQuests.closeBookOfQuests();
        barManagerState.panOut(); // I don't love this, I gave each bar state a pan in and a pan out, I feel this forces functionality. There are better ways im sure, but there are also worse,,, Ill add 5 tech points and sit in the cornner
        setBarState(noPatronHighlighted); // cont kinda gives it uniformity and keeps me from calling camera manager in bar manager itself, but still, I feel a bit bad. 
    }

    public void turnPageInBattleReport()
    {
        battleReportManager.flipPageInBattleReport();
        switch (battleReportManager.currentPageOfReport)
        {
            case BattleReportManager.ReportPages.REWARDS:
                {

                   
                    foreach (StoreableItem s in battleReportManager.RewardsToRedeem)
                    {
                        Debug.Log(battleReportManager.RewardsToRedeem.Count);
                        inventoryManager.addItemToInvintory(s);
                    }

                    foreach (Unlocker u in battleReportManager.UnlockersToRedeem)
                    {
                       switch (u.WhatDoesThisUnlock)
                        {
                            case Unlocker.WhatUnlocks.PATRON:
                                {
                                    Pmanager.unlockNewPatronAndAdd(u.NameOfThingToUnlock);
                                    break;
                                }

                            case Unlocker.WhatUnlocks.RUMOR:
                                {
                                    rumorManager.unlockRumor(u.NameOfThingToUnlock);
                                    break;
                                 }

                                }
                    }
                    break;
                }

                case BattleReportManager.ReportPages.LEVEL:
                {
                    break;
                }

            case BattleReportManager.ReportPages.CLOSED:
                {
                    Debug.Log("From Bar manager Does quest repeat?" + battleReportManager.DoesQuestRepeat);
                    rumorManager.storeRumor(battleReportManager.RumorID, battleReportManager.DoesQuestRepeat); // don't know if this is out of place. 
                    isTimePaused(false);
                    setBarState(noPatronHighlighted);
                    break;
                }
        }

       
    }

    public void passAllFinishedPatronsToPatronManager()
    {
        
        foreach (Patron p in adventureManager.IdleAdventurers)
        {
            Pmanager.putAPatronBack(p);
            //Pmanager.Regulars.Add(p);
            Debug.Log("Passing patron now");
        }
        adventureManager.clearAllIdleAdventurers();
    }

    private void transferAllTakenQuestsToAdventureManager()
    {
        foreach (Quest q in bookOfQuests.PagesInTheBookOfQuests)
        {
            if (q.RemoveQuestFromBookAtEndOfDay)
            {
                adventureManager.QuestsInProgress.Add(q);
            }
        }
        bookOfQuests.removeAllTakenQuests();
    }

    public void isTimePaused(bool yesNo)
    {
        foreach (Seat s in Seats)
        {
            s.IsTimerPaused = yesNo;
            s.patronsMug.IsPaused = yesNo;
        }
        TimeManager.IsTimePaused = yesNo;
    }



}
