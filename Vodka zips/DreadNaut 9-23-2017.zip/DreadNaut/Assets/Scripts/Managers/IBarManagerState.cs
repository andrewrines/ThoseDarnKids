﻿using UnityEngine;
using System.Collections;
using System;

public interface IBarManagerState  {

    void ClearPatronHighlight();
    void MouseOverPatron(Seat selectedSeat); 
    void ClickPatron();
    void MakeDrink(byte slotToUse);
    void ChangeStance();
    void PauseBar();
    void panIn();
    void panOut();
   
   
   // void patronDucking();
   // void patronMixingDrink();
    //void patronServingDrink();
}

public class NoPatronHighlighted : IBarManagerState
{

    // I plan for all of the camera stuff to be done here. 
    

    BarManager barManager;

    public NoPatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }

   public void ClearPatronHighlight()
    {
       
    }

   public void MouseOverPatron(Seat selectedSeat)
    {
        barManager.SelectedSeat = selectedSeat;
        barManager.setBarState(barManager.getYesHighlight());
       
    }
   public  void ClickPatron()
    {
       
    }

    public void MakeDrink(byte slotToUse)
    {
        barManager.fillableMug.gameObject.SetActive(true);
        barManager.fillableMug.gameObject.transform.position = Camera.main.ScreenToWorldPoint(barManager.fillableMug.transform.position);
        barManager.fillableMug.DrinkInMug.addIngredentToDrink(barManager.inventoryManager.useIngredentFromInvintory(slotToUse));
        barManager.setBarState(barManager.getNoHighlight()); // making drink;
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    public void ChangeStance()
    {
        Camera.main.GetComponent<CameraManager>().panDown();
        barManager.setBarState(barManager.DuckBeneathBar());
    }
}

public class PatronHighlighted : IBarManagerState
{

    BarManager barManager;

    public PatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }

    public void ClearPatronHighlight()
    {
        Debug.Log("swiching to no one highlighted");
        barManager.SelectedSeat = null;
        barManager.setBarState(barManager.getNoHighlight());
        
    }

    public void MouseOverPatron(Seat selectedSeat)
    {

    }
    public void ClickPatron()
    {
        if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.TURNIN)
        {
            barManager.battleReportManager.ReadBattleReport(barManager.SelectedSeat.patron);
            barManager.isTimePaused(true);
            barManager.SelectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
            barManager.SelectedSeat.patron.QuestStub = null;
            barManager.setBarState(barManager.barIsPaused());
            barManager.SelectedSeat.TalkWithPatron();
        }

       else if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.ADVENTURE)
        {
            barManager.isTimePaused(true);
            barManager.bookOfQuests.OpenBookOfQuests(barManager.SelectedSeat.patron);
            barManager.setBarState(barManager.barIsPaused());
            barManager.SelectedSeat.TalkWithPatron();
            panIn();
        }

       else if (barManager.fillableMug.DrinkInMug.countIngredentsInDrink() > 0 && barManager.SelectedSeat.IsHasOrdered) // HACK to fix a bug where the bar keep makes a drink before asking them what they want, I want to be able to serve the drink 
        {
            barManager.serveDrink();
            barManager.setBarState(barManager.getNoHighlight());
        }
        else
        {
            barManager.SelectedSeat.TalkWithPatron();
            barManager.setBarState(barManager.getYesHighlight());
        }
    }

    public void MakeDrink(byte SlotToUse)
    {
       
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
         Camera.main.GetComponent<CameraManager>().ZoomIn( new Vector3(barManager.SelectedSeat.transform.position.x, barManager.SelectedSeat.PatronsHeight, barManager.SelectedSeat.transform.position.z));
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    public void ChangeStance()
    {
        Camera.main.GetComponent<CameraManager>().panDown();
        barManager.setBarState(barManager.DuckBeneathBar());
    }
}

public class PatronClicked : IBarManagerState
{

    BarManager barManager;
    

    public PatronClicked(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {

        Debug.Log("Patron no longer hilighted");
        barManager.setBarState(barManager.getNoHighlight());
    }

    public void MouseOverPatron(Seat selectedSeat)
    {
       
    }
    public void ClickPatron()
    {
       barManager.setBarState(barManager.getNoHighlight());
    }

    public void MakeDrink(byte slotToUse)
    {
       
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    public void ChangeStance()
    {
        Camera.main.GetComponent<CameraManager>().panDown();
        barManager.setBarState(barManager.DuckBeneathBar());
    }
}

public class DuckedDown : IBarManagerState
{

    BarManager barManager;

    public DuckedDown(BarManager barsly)
    {
        barManager = barsly; 
    }

    public void ClearPatronHighlight()
    {
        
    }

    public void ClickPatron()
    {
       
    }

    public void DuckDown()
    {
        
    }

    public void MakeDrink(byte slotToUse)
    {
      
    }

    public void MouseOverPatron(Seat selectedSeat)
    {
        throw new NotImplementedException();
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    public void ChangeStance()
    {
        Camera.main.GetComponent<CameraManager>().goBackToDefaultView();
        barManager.setBarState(barManager.getNoHighlight());
    }

    public void PauseBar()
    {
       
    }
}


public class BarPaused : IBarManagerState    
{

    BarManager barManager;


    public BarPaused(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {
       
    }

    public void MouseOverPatron(Seat selectedSeat)
    {
       
    }
    public void ClickPatron()
    {
      
    }

    public void MakeDrink(byte slotToUse)
    {

    }

    public void PauseBar()
    {
        
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
        Camera.main.GetComponent<CameraManager>().ZoomOut();
    }

    public void ChangeStance()
    {
        //barManager.setBarState(barManager.DuckBeneathBar());
    }
}
