﻿using UnityEngine;
using System.Collections;

public class StopPan : CommandWithUndo
{



    public StopPan() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        Camera.main.GetComponent<CameraManager>().stopPan();
    }
}
