﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Quest 
{

    public Quest()
    {

    }


    // private string questGiver;
    private string questName;
    public string QuestName { get { return questName; } set { questName = value; } }

    private string questDescription;
    public string QuestDescription { get { return questDescription; } set { questDescription = value; } }

    private int timeOnQuest;
    public int TimeOnQuest { get { return timeOnQuest; } set { timeOnQuest = value; } }

    private byte successesOnQuest;
    public byte SuccessesOnQuest { get { return successesOnQuest; } set { successesOnQuest = value; } }

    private byte levelOfQuest;
    public byte LevelOfQuest { get { return levelOfQuest; } set { levelOfQuest = value; } } // for our accordian sort thing in rumorLoader;

    private string rumorID;
    public string RumorID { get { return rumorID; } set { rumorID = value; } }  // in order to return the rumor to a list of selectable rumors in our rumorLoader; 

    private Queue<byte> whoToReward = new Queue<byte>();
    public Queue<byte> WhoToReward { get { return whoToReward; } set {whoToReward = value; } }

    private Queue<QuestLoader.Trial> trialsOfTheQuest = new Queue<QuestLoader.Trial>();
    public Queue<QuestLoader.Trial> TrialsOfTheQuest { get { return trialsOfTheQuest; } set { trialsOfTheQuest = value; } }

    private List<StoreableItem> rewardsFromQuest = new List<StoreableItem>();
    public List<StoreableItem> RewardsFromQuest { get { return rewardsFromQuest; } set { rewardsFromQuest = value; } }

    private List<Patron> patronsOnQuest = new List<Patron>();
    public List<Patron> PatronsOnQuest { get { return patronsOnQuest; } set { patronsOnQuest = value; } }

    private List<Unlocker> thingsToUnlock = new List<Unlocker>();
    public List<Unlocker> ThingsToUnlock { get { return thingsToUnlock; } set { thingsToUnlock = value; } }

    private bool removeQuestFromBookAtEndOfDay = false;
    public bool RemoveQuestFromBookAtEndOfDay { get { return removeQuestFromBookAtEndOfDay; } set { removeQuestFromBookAtEndOfDay = value; } }

    private Patron.Aligence whoDoesThisQuestSupport;
    public Patron.Aligence WhoDoesThisQuestSupport;

    private int expToAward;
    public int ExpToAward { get { return expToAward; } set { expToAward = value; } }

    private RumorLoader.RepeatableTypes rumorRepeat;
    public RumorLoader.RepeatableTypes RumorRepeat {get {return rumorRepeat;} set { rumorRepeat = value; } }

    private string questLocation;
    public string QuestLocation { get { return questLocation; } set { questLocation = value; } }

}
