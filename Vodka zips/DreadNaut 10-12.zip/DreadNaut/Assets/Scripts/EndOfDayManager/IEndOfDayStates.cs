﻿using UnityEngine;
using System.Collections;
using System;

public interface IEndOfDayStates {
    void PatronMenuOpen();
    void RumorMenuOpen();
    void ShowPresetAssets();
    void HidePresetAssets();
    void ScrollUp();
    void ScrollDown();
    void ShowStatsOnPage(byte index);
    // stuff I dont like and need to sort out latter as the specifically belong to rumorstate but need the command pattern hooks; 

    void ShowQuestOnPage(Quest quest);
    void AddQuestToAdventureBook();
    void BackOutOfQuestRumor();
    void turnPageLeftInQuestAtLocation();
    void turnPageRightInQuestAtLocation();


}


       


