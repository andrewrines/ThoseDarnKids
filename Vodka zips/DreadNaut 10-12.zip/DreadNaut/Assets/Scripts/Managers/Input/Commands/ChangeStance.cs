﻿using UnityEngine;
using System.Collections;

public class ChangeStance : CommandWithUndo
{


    public ChangeStance() : base()
    {
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.ChangeStance();
        }
        base.Execute(Bar);
    }
}


