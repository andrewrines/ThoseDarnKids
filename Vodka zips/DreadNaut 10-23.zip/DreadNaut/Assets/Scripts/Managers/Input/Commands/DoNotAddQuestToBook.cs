﻿using UnityEngine;
using System.Collections;

public class DoNotAddQuestToBook : CommandWithUndo
{


    public DoNotAddQuestToBook() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.BackOutOfQuestRumor();
        }
        base.Execute(Bar);
    }
}
