﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EndOfDayManager : MonoBehaviour {

    public GameObject endOfDayScreen;
    public GameObject menuBoard; // this will be the list of names and things that travels between pages.
    public GameObject endStateSelector;
    private List<Patron> allPatronsTheBartenderKnows = new List<Patron>();
    public List<Patron> AllPatronsTheBartenderKnows {get { return allPatronsTheBartenderKnows; } set { allPatronsTheBartenderKnows = value; } }

    private List<Rumor> rumorsKnownAbout = new List<Rumor>();
    public List<Rumor> RumorsKnownAbout { get { return rumorsKnownAbout; } } // set { rumorsKnownAbout = value; } }

    private List<Quest> questsToSendToTheBook = new List<Quest>();
    public List<Quest> QuestsToSendToTheBook { get { return questsToSendToTheBook; } }

    public WarRoomState warRoomState;
    public PatronScreenOpened patronState;


    IEndOfDayStates patronScreenOpened;
    IEndOfDayStates rumorScreenOpened;

    IEndOfDayStates currentManagementState;


    public void Start()
    {
        patronScreenOpened = patronState;
        rumorScreenOpened = warRoomState;
    }

    public void addRumor(Rumor rumorToAdd)
    {
        rumorsKnownAbout.Add(rumorToAdd);
    }

    public void pullUpEndOfDayScreen()
    {
        endOfDayScreen.SetActive(true);
        menuBoard.SetActive(true);
        endStateSelector.SetActive(true);
        currentManagementState = patronScreenOpened;
        currentManagementState.ShowPresetAssets();
    }

 

    public void setManagerState(IEndOfDayStates newEndOfDayState)
    {
        currentManagementState = newEndOfDayState;
    }

    public void ShowPresetAssets()
    {
        currentManagementState.ShowPresetAssets();
    }
    #region CommandPatternHooks
    public void FlipToPatronPage()
    {
        currentManagementState.PatronMenuOpen();
    }


    public void FlipToRumorPage()
    {
        currentManagementState.RumorMenuOpen();
    }

    public void ScrollUp()
    {
        currentManagementState.ScrollUp();
    }

    public void ScrollDown()
    {
        currentManagementState.ScrollDown();
    }

    public void ShowStatsOnPage(byte index)
    {
       currentManagementState.ShowStatsOnPage(index);
    }

    public void ShowQuestOnPage(Quest quest)
    {
        currentManagementState.ShowQuestOnPage(quest); 
    }

    public void AddQuestToAdventureBook() 
    {
       currentManagementState.AddQuestToAdventureBook();
    }

    public void BackOutOfQuestRumor()
    {
        currentManagementState.BackOutOfQuestRumor();
    }

    public void turnPageLeftInQuestAtLocation()
    {
        currentManagementState.turnPageLeftInQuestAtLocation();
    }

    public void turnPageRightInQuestAtLocation()
    {
        currentManagementState.turnPageRightInQuestAtLocation();
    }

    #endregion

    public void closeEndOfDayScreen()
    {
        if (currentManagementState != null)
        {
            currentManagementState.HidePresetAssets();
            endOfDayScreen.SetActive(false);
            menuBoard.SetActive(false);
            endStateSelector.SetActive(false);
        }
    }


    public IEndOfDayStates openPatronScreen()
    {
        return patronScreenOpened;
    }


    public IEndOfDayStates openRumorScreen()
    {
        return rumorScreenOpened;
    }


}
