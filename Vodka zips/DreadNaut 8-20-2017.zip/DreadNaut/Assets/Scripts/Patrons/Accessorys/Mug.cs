﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Mug : MonoBehaviour
{
    private SpriteRenderer patronsMug;
    private float ammountToDecreaseAlphaBy;
    private Color fullMugValue;
    private bool isPaused;
    public bool IsPaused { get { return isPaused; } set { isPaused = value; } }

    public void Awake()
    {
        patronsMug = GetComponent<SpriteRenderer>();
        fullMugValue = patronsMug.color;
        hideMug();
    }


    public void showMug(float drinksDesity)
    {
        this.gameObject.SetActive(true);
        ammountToDecreaseAlphaBy = drinksDesity;
        patronsMug.color = fullMugValue;
       // isPaused = false;
    }

    private void Update()
    {
        if (!isPaused)
        {
            patronsMug.color -= new Color(0, 0, 0, fullMugValue.a / ammountToDecreaseAlphaBy) * Time.deltaTime;
            if(fullMugValue.a == 0)
            {
                hideMug();
            }
        }
    }

    public void hideMug()
    {
        if (patronsMug != null)
            patronsMug.gameObject.SetActive(false);
    }

   
}
