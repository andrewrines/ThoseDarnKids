﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;


public class QuestLoader {
    string path;
    string jsonString;
    JSONObject questJSONObject;
    ItemParser itemParser; // I don't super like linking two loaders together like this, but I don't know a better way. YET
    enum questParserHelper { NAME, DESCRIPTION, ALLEGIANCE, RIVAL, LENGHT, CHECKS , REWARDS, EXP}; // a more visual way to see the construction of the quest
    

    public void JsonQuestInit()
    {
        path = Application.dataPath + "/JsonFiles/QuestsInGame.json";
        jsonString = File.ReadAllText(path);
        questJSONObject = new JSONObject(jsonString);
        itemParser = new ItemParser();


    }

    public Quest questCreator(string nameOfQuestToFind)
    {
        var QuestToFind = questJSONObject[nameOfQuestToFind];
        Quest questToBuild = new Quest(); 
        questToBuild.QuestName = QuestToFind[(byte)questParserHelper.NAME].str;
        questToBuild.QuestDescription = QuestToFind[(byte)questParserHelper.DESCRIPTION].str;
        questToBuild.TimeOnQuest = (int)QuestToFind[(byte)questParserHelper.LENGHT].i;
        questToBuild.TrialsOfTheQuest = questTrialCreator(QuestToFind[(byte)questParserHelper.CHECKS]);
        questToBuild.RewardsFromQuest = questRewardFinder(QuestToFind[(byte)questParserHelper.REWARDS]); 
        questToBuild.WhoDoesThisQuestSupport = questSupportFinder(QuestToFind[(byte)questParserHelper.ALLEGIANCE].str); // Added 8/12 as with function
        questToBuild.ExpToAward = (int)QuestToFind[(byte)questParserHelper.EXP].i;
        // needs alience as well as rival
        return questToBuild;
    }

    private int rollFor(int min , int max)
    {
        return UnityEngine.Random.Range(min, max);
    }

    public struct Trial
    {

        public bool isTrialPassed;
        public string winText;
        public string loseText;                 
       public Patron.StatTypes challengeType;
       public byte challengeRaiting;
        // Effectors Any fun things we can add to a trial to give it more spice. 
        public Trial(string WinText, string LoseText, Patron.StatTypes ChallengeType, byte ChallengeRaiting)
        {
            isTrialPassed = false;
            winText = WinText;
            challengeType = ChallengeType;
            challengeRaiting = ChallengeRaiting;
            loseText = LoseText;
        }
       
    }

    private Queue<Trial> questTrialCreator(JSONObject allTrials)
    {
        Queue<Trial> trialsToReturn = new Queue<Trial>();

        for (int i = 0; i < allTrials.Count; i++)
        {
            string winTextToFind = allTrials[i][0].str;
            string loseTextToFind = allTrials[i][1].str;
            Patron.StatTypes statToCheck = determineStatType(allTrials[i][2].str);
            byte difficulty = (byte)allTrials[i][3].i;
            Trial trialToQueue = new Trial(winTextToFind, loseTextToFind ,statToCheck, difficulty );
            trialsToReturn.Enqueue(trialToQueue);
        }
        return trialsToReturn;
    }

  

    private Patron.StatTypes determineStatType(string statToDetermine)
    {

        switch(statToDetermine.ToLower())
        {
            case "strong":
                {
                    return Patron.StatTypes.STRONG;
                }

            case "smart":
                {
                    return Patron.StatTypes.SMART;
                }

            case "sneak":
                {
                    return Patron.StatTypes.SNEAK;
                }

            case "sway":
                {
                    return Patron.StatTypes.SWAY;
                }

            default:
                {
                    Debug.Log("Fall through on search of trial type, im in quest loader");
                    return Patron.StatTypes.STRONG;
                }
        }
    
    }

    private List<StoreableItem> questRewardFinder(JSONObject allRewards)
    {
        
        List<StoreableItem> itemsToReturn = new List<StoreableItem>();
        for (int i = 0; i < allRewards.Count; i++)
        {
            itemsToReturn.Add(itemParser.itemFactory(findOutWhatKindOfItemItIs(allRewards[i][0].str), allRewards[i][1].str, (int)allRewards[i][2].i));
        }
        return itemsToReturn;

    }

    private ItemParser.KindOfItem findOutWhatKindOfItemItIs(string whatKindOfItem)
    {
        switch(whatKindOfItem)
        {
            case "EQU":
                {
                    return ItemParser.KindOfItem.EQU;
                }

            case "GOLD":
                {
                    return ItemParser.KindOfItem.GOLD;
                }

            case "ING":
                {
                    return ItemParser.KindOfItem.ING;
                }

            case "PTS":
                {
                    return ItemParser.KindOfItem.PTS;
                }

            default:
                {
                    Debug.Log("Fall through on search of reward type, im in quest loader");
                    return ItemParser.KindOfItem.GOLD;
                }

        }
    }

    private Patron.Aligence questSupportFinder(string whoseFaction) 
    {
        switch (whoseFaction.ToLower())
        {
            case "college":
                {
                    return Patron.Aligence.COLLEGE;
                }

            case "corporeal":
                {
                    return Patron.Aligence.CORPOREAL;
                }

            case "aa":
                {
                    return Patron.Aligence.AA;
                }

            case "evil":
                {
                    return Patron.Aligence.EVIL;
                }

            case "mafia":
                {
                    return Patron.Aligence.MAFIA;
                }

            case "daredevil":
                {
                    return Patron.Aligence.DAREDEVIL;
                }

            case "archaeological":
                {
                    return Patron.Aligence.ARCHAEOLOGICAL;
                }

            case "nature":
                {
                    return Patron.Aligence.NATURE;
                }

            case "neighborhood":
                {
                    return Patron.Aligence.NEIGHBORHOOD;
                }

            case "brewmaster":
                {
                    return Patron.Aligence.BREWMASTER;
                }

            case "none":
                {
                    return Patron.Aligence.NONE;
                }
            default:
                {
                    Debug.Log("Fall through on serch type faction, im in quest loader");
                    return Patron.Aligence.NONE;
                }

        }
    }
}
