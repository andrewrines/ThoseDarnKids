﻿using UnityEngine;
using System.Collections;

public class Ingredent : StoreableItem {

    public enum ingredentColor {RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE }
    private ingredentColor thisIngredentsColor;
    public ingredentColor ThisIngredentsColor { get { return thisIngredentsColor; } }
    Sprite howDoILook;

	public Ingredent(ingredentColor ThisIngredentsColor)
    {
        thisIngredentsColor = ThisIngredentsColor;
    }

    public override string sayName()
    {
        return thisIngredentsColor.ToString(); // an overrided to string may let us put in neat names for our ingredents
    }

    public override Sprite displayArt()
    {
        if (howDoILook == null)
        {
            howDoILook = ApperanceManager.instance.whatDoesTheIngredentLookLike(thisIngredentsColor);
        }
        return howDoILook;
    }
}
