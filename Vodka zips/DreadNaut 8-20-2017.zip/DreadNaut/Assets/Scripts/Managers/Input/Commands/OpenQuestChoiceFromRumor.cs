﻿using UnityEngine;
using System.Collections;

public class OpenQuestChoiceFromRumor : CommandWithUndo
{

    byte slotToFind;

    public OpenQuestChoiceFromRumor(byte invintorySlot) : base()
    {
        slotToFind = invintorySlot;
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.ShowQuestOnPage(slotToFind);
        }
        base.Execute(Bar);
    }
}
