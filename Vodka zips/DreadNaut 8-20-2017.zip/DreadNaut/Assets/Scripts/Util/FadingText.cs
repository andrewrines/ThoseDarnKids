﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FadingText : MonoBehaviour {

    Text textToFade;
    public float howLongIsThisFade;
    private float fadeCountdown;

	// Update is called once per frame
	void Update () {
        tickTimeDown();
	}

    public void sendWhatToSay(string dioOut)
    {
        this.gameObject.SetActive(true);
        textToFade = this.gameObject.GetComponent<Text>();
        textToFade.text = dioOut;
        fadeCountdown = howLongIsThisFade; 
    }

    private void tickTimeDown()
    {
        fadeCountdown -= Time.deltaTime; 
        if (fadeCountdown <= 0 )
        {

            this.gameObject.SetActive(false);  
        }
    }
}
