﻿using UnityEngine;
using System.Collections;

public class StartNextDay : CommandWithUndo
{


public StartNextDay() : base()
    {
   
    }
  
public override void Execute(BarManager Bar)
{
    var target = Bar.GetComponent<BarManager>();
    if (target is BarManager)
    {
            target.startNextDay();
    }
    base.Execute(Bar);
}
}