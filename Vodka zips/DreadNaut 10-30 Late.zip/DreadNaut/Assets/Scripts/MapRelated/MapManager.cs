﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapManager : MonoBehaviour //This doesn't have to be a Monobehaviour.  Update code to improve this!
{

    IMapStates deployState;
    IMapStates warRoomState;

    IMapStates mapMode;


    [SerializeField] List<LocationAndKey> allLocations;

    [SerializeField] QuestInfoPanel questInfoPanel;
    public QuestInfoPanel getQuestInfoPanel { get { return questInfoPanel; } }
   
    [SerializeField] RectTransform MapImage;

    [SerializeField]
    MapVisualEffects mapVisualEffectScript;
    public MapVisualEffects MapVisualEffectScript { get { return mapVisualEffectScript; } }

    private List<Patron> idleAdventurers = new List<Patron>();  // Added NC 9/24
    public List<Patron> IdleAdventurers { get { return idleAdventurers; } }

    private Patron patronToGoOnAdventure;
    public Patron PatronToGoOnAdventure {get { return patronToGoOnAdventure;}}

    public WarRoomState warRoomStateScript;
    public DeployState deployStateScript;



    [System.Serializable]
    struct LocationAndKey
    {
        public Location location;
        public Location.LocationIdentifier key;
    }

  

    List<Adventure> allCurrentAdventures = new List<Adventure>();   //A list of all currently active adventures

    /// <summary>
    /// Sets a quest to a location by name of the quest.  The quest's name must match the name given in the inspector!
    /// </summary>
    /// <param name="targetQuest"></param>
    /// <returns>Returns true if the quest was added to the location successfully</returns>
    /// 

    public void openFromEndOfDay()
    {
        if (warRoomState == null)
        {
            initWarRoomState();
        }
        mapMode = warRoomState;
        MapImage.gameObject.SetActive(true);
        mapMode.openMapProps();
    }

    public void closeMapProps()
    {
        MapImage.gameObject.SetActive(false);
        mapMode.closeMapProps();
    }

    public void nodeClicked(Location nodesLocation)  //public void AddLocationToAdventure(Location clickedLocation) This is the new!
    {
        mapMode.nodeClicked(nodesLocation);
    }


    public void mapOpenFromBar(Patron inPatronOnAdventure)    //THIS IS CALLED FROM OUTSIDE THE MAP SYSTEM.  This should start the chain of events needed to construct an adventure.
    {
        if (deployState == null)
        {
            initDeployState();
        }
        mapMode = deployState;
        patronToGoOnAdventure = inPatronOnAdventure;
        MapImage.gameObject.SetActive(true);
        mapMode.openMapProps();
        SoundManager.Instance.AddCommand("OpenMap");
    }

    public void ShowQuestInfoPanel()
    {
        mapMode.ShowQuestInfoPanel();
    }

    public void HideQuestInfoPanel()
    {
        mapMode.HideQuestInfoPanel();
    }

    public void FinishTaskOnMap()
    {
        mapMode.FinishTaskOnMap();
    }

    public void SetPotentialQuestFlag(Quest targetQuest)
    {
        findLocationFromDictionary(targetQuest).setPotentialQuestFlag();
    }

    public void removePotentialQuestFlag(Quest targetQuest)
    {
        findLocationFromDictionary(targetQuest).removePotentialQuestFlag();
    }

    public void removeTimeOutQuest(Quest targetQuest)
    {
        findLocationFromDictionary(targetQuest).removeQuestFromLocation(targetQuest);
    }

    public void AdvanceAllPatronsOnAdventures()
    {
        for (int i = 0; i < allCurrentAdventures.Count; i++) 
        {
            //move the patron, if there is a quest, the patron will roll for it. 
            allCurrentAdventures[i].advanceToNextLocation(); 

            // sends our patron back when adventure is done // NC 9/24
            if (allCurrentAdventures[i].isAdventureOver)
            {
                idleAdventurers.Add(allCurrentAdventures[i].PatronOnAdventure);
                allCurrentAdventures[i].PatronOnAdventure.currentActivity = Patron.whatDoTheyWantToDo.TURNIN;
                allCurrentAdventures.RemoveAt(i);
                i--; // when we remove one, we make the count smaller, so we need to move back one. 
                
            }
           
        }

        for (int j = 0; j < allCurrentAdventures.Count; j++) // I do not like this! I do this because I need to apply dammage after each patron has had their go at the quest, but this repeat makes me feel not
        {                                                    // not so great. I need to find a better way of doing this. 
            allCurrentAdventures[j].cleanUpPhase(); 
        }
    }

    public void clearAllIdleAdventurers() // NC added 9/24
    {
        idleAdventurers.Clear();
    }

    public void addAdventureToAllAdventures(Adventure adventureToAdd)
    {
         allCurrentAdventures.Add(adventureToAdd);
    }

    private Location findLocationFromDictionary(Quest q)
    {
        for (int i = 0; i < allLocations.Count; i++)
        {
            if (allLocations[i].key.ToString() == q.QuestLocation)
            {
                return allLocations[i].location;
            }
        }

        Debug.Log("Could Not find location" + q.QuestLocation);
        return null;
    }

    private void initWarRoomState()
    {
        warRoomState = warRoomStateScript;//new WarRoomState(this);
        warRoomState.GetRefrenceOfMapManager(this);
    }

    private void initDeployState()
    {
        deployState = deployStateScript;
        deployState.GetRefrenceOfMapManager(this);
    }

    //public void AddLocationToAdventure(Location clickedLocation)    //Called when the player clicks on a location- the button on the quest info panel (while creating an adventure)
    //{


    //    //When the player clicks 'Add Location', the panel closes and the player can click on another location
    //}

    //public void AddQuestToAdventure() //Called when the player clicks the "Choose quest" add quest button (while creating an adventure)
    //{
    //    AdventureUnderConstruction.SetNodeQuest(questInfoPanel.GetQuestFromLocation());
    //    AdventureUnderConstruction.ConfirmNewNode();
    //    MapVisualEffectScript.ZoomMapOutOfLocation(currentLocation); // Bowdish code 10/8
    //    currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
    //    questInfoPanel.HideSelf();
    //}

    //public void FinishBuildingAdventure()   //Called when the player clicks the "Confirm Adventure" button (while creating an adventure)
    //{
    //    AdventureUnderConstruction.assignAllQuestsToPatron();
    //    allCurrentAdventures.Add(AdventureUnderConstruction);
    //}

    //public void closeAdventureMap()   //Called when the player clicks the "Cancel Adventure" button (while creating an adventure) NC This is also called when a player confirms the adventure they want to go on. 
    //{
    //    MapImage.gameObject.SetActive(false);
    //    questInfoPanel.gameObject.SetActive(false);
    //    patronCheatSheet.deactivatePatronCheatSheet();
    //}









    //public void HideQuestInfoPanel()
    //{
    //    questInfoPanel.HideSelf();
    //}



    /* NOTE:
     * I feel like I should use the state pattern?
     *      -> When the player clicks on a location, they should ONLY be able to interact with the "select a quest at this location" panel
     */

}
