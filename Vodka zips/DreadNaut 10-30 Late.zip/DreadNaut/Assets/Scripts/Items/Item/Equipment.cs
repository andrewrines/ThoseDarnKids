﻿using UnityEngine;
using System.Collections;

public class Equipment : StoreableItem
{
    //private string equipmentName;
    //public string EquipmentName { get { return equipmentName; } set { equipmentName = value; } }

    //public enum howIsThisGoingToLook {SWORD, KNIFE, STAFF, POTION, BOOTS, ARMOR, SHEILD };
    //private howIsThisGoingToLook howDoesThisItemLook;
    //public howIsThisGoingToLook HowDoesThisItemLook { get { return howDoesThisItemLook; } set { howDoesThisItemLook = value; } }

    //Sprite howDoILook;

    //// enum of effects, 

    //public override string sayName()
    //{
    //    return equipmentName; // an overrided to string may let us put in neat names for our ingredents
    //}

    //public override Sprite displayArt()
    //{
    //    //if (howDoILook == null)
    //    //{
    //    //    howDoILook = ApperanceManager.instance.whatDoesTheEquipmentLookLike(howDoesThisItemLook);
    //    //}
    //    //return howDoILook;
    //}
}
