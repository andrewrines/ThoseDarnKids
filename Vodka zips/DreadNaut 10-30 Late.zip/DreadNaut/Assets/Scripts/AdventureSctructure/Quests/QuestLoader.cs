﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;


public class QuestLoader {
    string path;
    string jsonString;
    JSONObject questJSONObject;
    ItemParser itemParser; // I don't super like linking two loaders together like this, but I don't know a better way. YET
    enum questParserHelper { NAME, DESCRIPTION, ALLEGIANCE, RIVAL, CHECKS , REWARDS, EXP, PATRONUNLOCK, RUMORUNLOCK ,EVENTUNLOCK, LOCATION, MAXPATRON ,DAYS, LENGTH}; // a more visual way to see the construction of the quest
    public enum whenToUnlock {WIN, LOSE, BOTH };

    
    

    public void JsonQuestInit()
    {
        path = Application.streamingAssetsPath + "/JsonFiles/QuestsInGame.json";
        jsonString = File.ReadAllText(path);
        questJSONObject = new JSONObject(jsonString);
        itemParser = new ItemParser();
    }


    public Quest createQuestByName(string nameOfQuestToFind)
    {
        JSONObject QuestToFind = questJSONObject[nameOfQuestToFind];
        Quest questToBuild = new Quest(); 
        questToBuild.QuestName = @QuestToFind[(byte)questParserHelper.NAME].str;
        questToBuild.QuestDescription = @QuestToFind[(byte)questParserHelper.DESCRIPTION].str;
        questToBuild.TrialsOfTheQuest = questTrialCreator(QuestToFind[(byte)questParserHelper.CHECKS]);
        questToBuild.RewardsFromQuest = questRewardFinder(QuestToFind[(byte)questParserHelper.REWARDS]); 
        questToBuild.WhoDoesThisQuestSupport = questSupportFinder(QuestToFind[(byte)questParserHelper.ALLEGIANCE].str); // Added 8/12 as with function
        questToBuild.ExpToAward = (int)QuestToFind[(byte)questParserHelper.EXP].i;
        questToBuild.QuestLocation = QuestToFind[(byte)questParserHelper.LOCATION].str.ToUpper();
        AddAllKindsOfUnlocker(questToBuild, QuestToFind);
        questToBuild.MaxNumberOfPatronsOnQuest = (byte)QuestToFind[(byte)questParserHelper.MAXPATRON].i;
        questToBuild.DaysToCompleteQuest = (byte)QuestToFind[(byte)questParserHelper.DAYS].i; 
        return questToBuild;
    }

    private int rollFor(int min , int max)
    {
        return Random.Range(min, max);
    }

    public struct Trial
    {
        public bool isTrialPassed;
        //public string winText;
        //public string loseText;                 
       public Patron.StatTypes challengeType;
       public sbyte challengeRaiting;
        // Effectors Any fun things we can add to a trial to give it more spice. 
        public Trial( Patron.StatTypes ChallengeType, sbyte ChallengeRaiting)
        {
            isTrialPassed = false;
            challengeType = ChallengeType;
            challengeRaiting = ChallengeRaiting;
        }
       
    }

    private List<Trial> questTrialCreator(JSONObject allTrials)
    {
        List<Trial> trialsToReturn = new List<Trial>();

        for (int i = 0; i < allTrials.Count; i++)
        {
            //string winTextToFind = allTrials[i][0].str;
            //string loseTextToFind = allTrials[i][1].str;
            Patron.StatTypes statToCheck = determineStatType(allTrials[i][0].str);
            sbyte difficulty = (sbyte)allTrials[i][1].i;
            Trial trialToQueue = new Trial(statToCheck, difficulty );
            trialsToReturn.Add(trialToQueue);
        }
        return trialsToReturn;
    }

   



    private Patron.StatTypes determineStatType(string statToDetermine)
    {

        switch(statToDetermine.ToLower())
        {
            case "strong":
                {
                    return Patron.StatTypes.STRONG;
                }

            case "smart":
                {
                    return Patron.StatTypes.SMART;
                }

            case "sneak":
                {
                    return Patron.StatTypes.SNEAK;
                }

            case "sway":
                {
                    return Patron.StatTypes.SWAY;
                }

            default:
                {
                    Debug.Log("Fall through on search of trial type, im in quest loader");
                    return Patron.StatTypes.STRONG;
                }
        }
    
    }

    private List<StoreableItem> questRewardFinder(JSONObject allRewards)
    {
        
        List<StoreableItem> itemsToReturn = new List<StoreableItem>();
        for (int i = 0; i < allRewards.Count; i++)
        {
            itemsToReturn.Add(itemParser.itemFactory(findOutWhatKindOfItemItIs(allRewards[i][0].str), allRewards[i][1].str, (int)allRewards[i][2].i));
        }
        return itemsToReturn;

    }

    private ItemParser.KindOfItem findOutWhatKindOfItemItIs(string whatKindOfItem)
    {
        switch(whatKindOfItem)
        {
            case "EQU":
                {
                    return ItemParser.KindOfItem.EQU;
                }

            case "GOLD":
                {
                    return ItemParser.KindOfItem.GOLD;
                }

            case "ING":
                {
                    return ItemParser.KindOfItem.ING;
                }

            case "PTS":
                {
                    return ItemParser.KindOfItem.PTS;
                }

            default:
                {
                    Debug.Log("Fall through on search of reward type, im in quest loader");
                    return ItemParser.KindOfItem.GOLD;
                }

        }
    }

    private Patron.Aligence questSupportFinder(string whoseFaction) 
    {
        switch (whoseFaction.ToLower())
        {
            case "college":
                {
                    return Patron.Aligence.COLLEGE;
                }

            case "corporeal":
                {
                    return Patron.Aligence.CORPOREAL;
                }

            case "aa":
                {
                    return Patron.Aligence.AA;
                }

            case "evil":
                {
                    return Patron.Aligence.EVIL;
                }

            case "mafia":
                {
                    return Patron.Aligence.MAFIA;
                }

            case "daredevil":
                {
                    return Patron.Aligence.DAREDEVIL;
                }

            case "archaeological":
                {
                    return Patron.Aligence.ARCHAEOLOGICAL;
                }

            case "nature":
                {
                    return Patron.Aligence.NATURE;
                }

            case "neighborhood":
                {
                    return Patron.Aligence.NEIGHBORHOOD;
                }

            case "brewmaster":
                {
                    return Patron.Aligence.BREWMASTER;
                }

            case "none":
                {
                    return Patron.Aligence.NONE;
                }
            default:
                {
                    Debug.Log("Fall through on serch type faction, im in quest loader");
                    return Patron.Aligence.NONE;
                }

        }
    }

    private void AddAllKindsOfUnlocker(Quest questToAddTo, JSONObject whatToAdd)
    {
        List<Unlocker> unlockersListToAdd = new List<Unlocker>();
        Unlocker unlockerToAdd;

        for (questParserHelper i = questParserHelper.PATRONUNLOCK; i < questParserHelper.LENGTH; i++)
        {
            for (int j = 0; j < whatToAdd[(int)i].Count; j++)
            {
                unlockerToAdd = new Unlocker();
                unlockerToAdd.setWhenToUnlock(whatToAdd[(int)i][j][0].str);
                unlockerToAdd.NameOfThingToUnlock = whatToAdd[(int)i][j][1].str;
                unlockerToAdd.setWhatThisUnlocks(i.ToString());
                unlockersListToAdd.Add(unlockerToAdd);
            }
        }

        questToAddTo.ThingsToUnlock = unlockersListToAdd;
    }
}
