﻿using UnityEngine;
using System.Collections;
using System.Text;
using UnityEngine.UI;

public class Seat : ABSTFadableObject
{
    public Patron patron;
    public FadingText fadingText;
    public Mug patronsMug;
    public IconPack patronWantsIcons;
    private float patronsHeight;
    public float PatronsHeight { get { return patronsHeight; } set { patronsHeight = value; } }
    public float timeToFadeInOut;
    private SpriteRenderer patronArt;
   
    ISeatStates patronIsLeaving;
    ISeatStates noOneSeated;
    ISeatStates patronSeated;
    ISeatStates patronOrdered;
    ISeatStates patronIsDrinking;
    ISeatStates patronIsDrunk;
    ISeatStates patronWantsAdventure;
    ISeatStates patronReturningFromAdventure;

    ISeatStates seatState;

    bool isReadyForRespawn; 
    public bool IsReadyForRespawn { get { return isReadyForRespawn; } set { isReadyForRespawn = value; } }

    bool isNeedClear;
    public bool IsNeedClear { get { return isNeedClear; } set { isNeedClear = value; } }


    bool isHasOrdered;
    public bool IsHasOrdered { get { return isHasOrdered; }  set{ isHasOrdered = value; } }

    float waitTimer;
    public float WaitTimer { get { return waitTimer; } set { waitTimer = value; } }

    float drinkTimer;
    public float DrinkTimer { get { return DrinkTimer; } set { drinkTimer = value; } }

    bool isTimerPaused;
    public bool IsTimerPaused { get { return isTimerPaused; } set { isTimerPaused = value; } }





    private void Start()
    {
        noOneSeated = new NoOneSeated(this);
         patronSeated= new PatronSeated(this);
        patronOrdered = new PatronOrdered(this);
        patronIsDrinking = new PatronIsDrinking(this);
        patronIsDrunk = new PatronIsDrunk(this);
        patronWantsAdventure = new PatronWantsAdventure(this); // Added
        patronReturningFromAdventure = new PatronReturningFromAdventure(this);

        seatState = noOneSeated;
        isTimerPaused = false;
        this.GetComponent<BoxCollider2D>().enabled = false;
        waitTimer = Random.Range(1f,3f); // added 

        patronWantsIcons.initIconsToDisplay();
        patronWantsIcons.initFadeTime(timeToFadeInOut);

        patronsMug.initMug();

        patronArt = this.GetComponent<SpriteRenderer>(); // our seats spriteRenderer
        assignObjectToFade(patronArt);
        setFadeTime(timeToFadeInOut);
       
        //fullHereColor = patronArt.color; // used for our fade in and out; 
        //patronArt.color = new Color(fullHereColor.r, fullHereColor.g, fullHereColor.b, emptyAlphaValue); // sets our art to 

        
       // this.GetComponent<SpriteRenderer>().color.a = emptyAlphaValue;

       // IsReadyForRespawn = true;

    }

    private void Update()
    {
        if (currentAnimationState == animationStates.ENTER)
        {
            runEnterAnimation();
        }

        if (currentAnimationState == animationStates.EXIT)
        {
            runExitAnimation();
        }

        if (drinkTimer > 0)
        {
            drinkCountdown();
        }
        else
            patienceCountdown();
    }

    public void setSeatState(ISeatStates newSeatState)
    {
        seatState = newSeatState;
    }

    public void EmptySeat()
    {
        seatState.EmptySeat();
        startExitAnimation();
        patronWantsIcons.startExitAnimation();
        patronsMug.fadeMug(timeToFadeInOut);
        fadingText.cutOff(timeToFadeInOut);     
    }

    public void FillSeat(Patron patronToSit)
    {
        
        isHasOrdered = false;
        seatState.FillSeat(patronToSit);
        startEnterAnimation();

        if (patron.currentActivity == Patron.whatDoTheyWantToDo.RUMOR)
        {
            patronWantsIcons.patronWantsToTellYouSomething(); //shows an icon for I have a rumor, the rumory bits are actually handled in bar manager because it knows what a quest manager is.
            patronWantsIcons.startEnterAnimation(); 
        }

        else if (patron.currentActivity == Patron.whatDoTheyWantToDo.TURNIN)
        {
            seatState.PatronReturnsFromQuest();
            patronWantsIcons.patronIsReturningFromQuest();
            patronWantsIcons.startEnterAnimation();

        }

        else if (patron.currentActivity == Patron.whatDoTheyWantToDo.ADVENTURE)  // added
        {
            seatState.PatronWantsToGoOnAdventure(); // Sets the state to I WANT TO ADVENTURE, locking it out of ordering drinks
            patronWantsIcons.PatronWantsToGoOnAnAdventure(); // displays icon for I want to adventure. 
            patronWantsIcons.startEnterAnimation();
        }

           

    }

    public void TalkWithPatron()
    {
        seatState.TalkWithPatron();
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        seatState.ConsumeBeverage(drinkToConsume);

    }

     public void PatronSharesARumor()
    {
        seatState.PatronSharesARumor();
    }


    #region yesCommands

    public ISeatStates ClearSeat()
    {
        return noOneSeated;
    }


    public ISeatStates SeatIsFilled()
    {
        return patronSeated;
    }

    public ISeatStates orderHasBeenTaken()
    {
        return patronOrdered;
    }

    public ISeatStates patronIsdrinking()
    {
        return patronIsDrinking;
    }

    public ISeatStates patronIsNowDrunk()
    {
        return patronIsDrunk;
    }

    public ISeatStates patronWouldLikeToGoOnAdventure()
    {
        return patronWantsAdventure;
    }

    public ISeatStates patronIsReturningFromAdventure()
    {
        return patronReturningFromAdventure;
    }

    #endregion


   public void setSeatTimer(float timeToSet)
    {
        waitTimer = timeToSet;
    }

    public void drinkCountdown()
    {
        if (!isTimerPaused)
        {
            drinkTimer -= Time.deltaTime;
            if (drinkTimer <= 0)
            {
                setSeatState(patronSeated);
                if (patron.currentActivity == Patron.whatDoTheyWantToDo.DRINK)
                {
                    patronWantsIcons.clearNeedsIcons();
                }
            }
        }
    }

    public void patienceCountdown()
    {
        if (!isTimerPaused)  
       {
          if (waitTimer > 0)
          {
               waitTimer -= Time.deltaTime;
           }
           else if (seatState == noOneSeated)
          {
            isReadyForRespawn = true;
          }
           else    
            {
            isNeedClear = true;
            }
          
        }
    }


    public void patronSays(string thingToSay)
    {
       fadingText.sendWhatToSay(patron.Name + " : " + thingToSay);
    }

    //private void startEnterBarAnimation()
    //{
    //    currentAnimationState = animationStates.ENTER;
    //}

    //private void EnteringAnimation()
    //{
    //    patronArt.color += new Color(0, 0, 0, fullHereColor.a / amountToFadeBy) * Time.deltaTime;
    //    if (patronArt.color.a >= fullHereColor.a)
    //    {
    //        currentAnimationState = animationStates.NONE;
    //    }

    //}

    //private void startExtingBarAnimation()
    //{
    //    currentAnimationState = animationStates.EXIT;
    //}

    //private void ExitingAnimation()
    //{
    //    patronArt.color -= new Color(0, 0, 0, fullHereColor.a / amountToFadeBy) * Time.deltaTime;
    //    if (patronArt.color.a <= emptyAlphaValue) 
    //    {
    //        patronWantsIcons.clearNeedsIcons();
    //        currentAnimationState = animationStates.NONE;
    //    }
    //}

}

