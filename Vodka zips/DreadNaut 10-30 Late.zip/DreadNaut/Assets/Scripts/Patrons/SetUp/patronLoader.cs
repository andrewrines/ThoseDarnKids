﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class patronLoader
{
    private string FallThroughHelper;  // used to help me find JSON typos
   // private static patronLoader instance = null;
   // private static readonly object padloc = new object();
      
   private enum jsonHelper {NAME, DISPOSITION, TIES,TOLERANCE,STATS,BS1,BS2,BS3, PATIENCE, BIO };      
    private string path;
    private string jsonString;
   private JSONObject patronToParse;
   private List<byte> indexingNumbers;
   
    
    //private Patron patronGuy;

    //public static patronLoader Instance
    //{
    //    get
    //    {
    //        lock (padloc)
    //        {

    //            if (instance == null)
    //            {
    //                instance = new patronLoader();
    //               instance.loadTools();

    //            }
    //            return instance;
    //        }
    //    }
    //}

    public void loadTools()
    {
        indexingNumbers = new List<byte>();

        path = Application.streamingAssetsPath + "/JsonFiles/CharactersInGame.json";   
        jsonString = File.ReadAllText(path);
       // patronGuy = JsonUtility.FromJson<Patron>(jsonString);
        patronToParse = new JSONObject(jsonString);
        loadIndexer((byte)patronToParse[0].Count);
        
    }

    private void loadIndexer(byte indexerSize)
    {
        for (byte i = 0; i < indexerSize; i++)
        {
            indexingNumbers.Add(i);
        }
    }

    public Patron spawnRandomPatron()
    {
        int indexNumberToShareAndRemove = Random.Range(0, indexingNumbers.Count);
        byte numberToindex = indexingNumbers[indexNumberToShareAndRemove];
        indexingNumbers.RemoveAt(indexNumberToShareAndRemove);
        Patron patronToReturn = spawnPatron(0,numberToindex, numberToindex);
        return patronToReturn;
        
    }


    public Patron unlockSpecificPatron(string name)
    {
        var keyFinder = patronToParse[1].keys;
        byte index = 0;
        byte ID;
        Patron patronToReturn; 
        foreach (string o in keyFinder)
        {
            if (o == name)
            {
                break;
            }
            index++;
        }

        ID = (byte)(index + patronToParse[0].Count);
        patronToReturn = spawnPatron(1, index, ID);
        return patronToReturn;
    }

    private Patron spawnPatron(byte lockLevel, byte patronIndex, byte patronID) // I dont know about this... parsing stuff. Not sure if its a pain or if its good. 
    {
        JSONObject randomlyCraftedPatron = patronToParse[lockLevel][patronIndex];
        string craftedName = randomlyCraftedPatron[(int)jsonHelper.NAME].str;
        FallThroughHelper = craftedName;
        packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]);
        Patron.disposition craftedDisposition = dispositionParser(randomlyCraftedPatron[(int)jsonHelper.DISPOSITION].str);
        Patron.Aligence CraftedAligence = aligenceParser(randomlyCraftedPatron[(int)jsonHelper.TIES].str);
        Patron.drinkLevel CraftedDrinkLevel = ToleranceParser(randomlyCraftedPatron[(int)jsonHelper.TOLERANCE].str);
        Patron.patienceLevels craftedPatience = PatienceParser(randomlyCraftedPatron[(int)jsonHelper.PATIENCE].str);
        string craftedBIO = @randomlyCraftedPatron[(int)jsonHelper.BIO].str;
        Patron patronToReturn = new Patron(craftedName, 0,  CraftedAligence, CraftedDrinkLevel, packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]), craftedPatience , craftedDisposition, craftedBIO);
        patronToReturn.ID = patronID;
        return patronToReturn;

    }


   


    private Patron.disposition dispositionParser(string dispositionToParse)// { TOUGH, CALM, NOBLE, BOOKSMART, EVIL, SILENT }
    {
        switch (dispositionToParse.ToLower())
        {

            case "stalwart": 
                {
                    return Patron.disposition.STALWART;
                }
            case "reserved": 
                {
                    return Patron.disposition.RESERVED;
                }
            case "upbeat":
                {
                    return Patron.disposition.UPBEAT;
                }
            case "dark":
                {
                    return Patron.disposition.DARK;
                }
            case "arrogant": 
                {
                    return Patron.disposition.ARROGANT;
                }

            default:
                {
                    Debug.Log("Disposition Fall through:" + FallThroughHelper);
                    return Patron.disposition.UPBEAT;
                }

        }

        
    }

    private Patron.Aligence aligenceParser(string DndToParse)
    {

        switch (DndToParse.ToLower())
        {

            case "college":
                {
                    return Patron.Aligence.COLLEGE;
                }
            case "corporeal":
                {
                    return Patron.Aligence.CORPOREAL;
                }
            case "aa":
                {
                    return Patron.Aligence.AA;
                }
            case "evil":
                {
                    return Patron.Aligence.EVIL;
                }
            case "mafia":
                {
                    return Patron.Aligence.MAFIA;
                }

            case "daredevil":
                {
                    return Patron.Aligence.DAREDEVIL;
                }

            case "archaeological":
                {
                    return Patron.Aligence.ARCHAEOLOGICAL;
                }
            case "nature":
                {
                    return Patron.Aligence.NATURE;
                }
            case "neighborhood":
                {
                    return Patron.Aligence.NEIGHBORHOOD;
                }

            case "brewmaster":
                {
                    return Patron.Aligence.BREWMASTER;
                }

            case "none":
                {
                    return Patron.Aligence.NONE;
                }

            default:
                {
                    Debug.Log(" Ties Fall through:" + FallThroughHelper);
                    return Patron.Aligence.NONE;
                }

        }
        
    }

    private Patron.drinkLevel ToleranceParser(string levelToParse)
    {


        switch (levelToParse.ToLower())
        {

            case "low":
                {
                    return Patron.drinkLevel.LOW;
                }
            case "mid":
                {
                    return Patron.drinkLevel.MID;
                }
            case "high":
                {
                    return Patron.drinkLevel.HIGH;
                }
            case "none":
                {
                    return Patron.drinkLevel.NONE;
                }
            default:
                {
                    Debug.Log("Drink level Fall through:" + FallThroughHelper);
                    return Patron.drinkLevel.NONE;
                }

        }

    }

    private Patron.patienceLevels PatienceParser(string patienceToParse)
    {
        switch (patienceToParse.ToLower())
        {

            case "low":
                {
                    return Patron.patienceLevels.LOW;
                }
            case "mid":
                {
                    return Patron.patienceLevels.MID;
                }
            case "high":
                {
                    return Patron.patienceLevels.HIGH;
                }
            default:
                {
                    Debug.Log("patience level Fall through:" + FallThroughHelper);
                    return Patron.patienceLevels.MID;
                }

        }
      
    }

    private sbyte[] packageStats(JSONObject statsToPackage)  // don't know if this is confusing, basicly I just wanted to pass all of the stats as an array and not by themselves. 
    {
        sbyte[] craftedStates = new sbyte[4];// Tell me if it is and ill fix it. 
        for (int j= 0; j < statsToPackage.Count; j++)
        {
            craftedStates[j] = (sbyte)statsToPackage[j].i;
        }
        return craftedStates;
    }
}
