﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class BookOfQuests : MonoBehaviour {

    CostCalculator costCalculator; 

    private List<Quest> pagesInTheBookOfQuests = new List<Quest>();
    public List<Quest> PagesInTheBookOfQuests { get { return pagesInTheBookOfQuests; } set { pagesInTheBookOfQuests = value; } }

    private int costOfQuest;
    public int CostOfQuest { get { return costOfQuest; } set { costOfQuest = value; } }

    Patron patronToGoOnAdventure;
    public Text GoldCostText; 

    public Text questName;
    public Text GoldPriceForQuest;
    public Text PageNumberText;
    public Button acceptQuest;
    public Button BackButton;
    public Button leftButton;
    public Button rightButton;
    Button[] allButtons;
    

    private int pageNumber;

    private void initBookOfQuests()
    {
        costCalculator = new CostCalculator();
        initButtons();
    }

    private void initButtons()
    {
        allButtons = new Button[4];
        allButtons[0] = acceptQuest;
        allButtons[1] = BackButton;
        allButtons[2] = leftButton;
        allButtons[3] = rightButton;
    }

    public void OpenBookOfQuests(Patron seatedPatron) 
    {
        if (costCalculator == null)
        {
            initBookOfQuests();
        }

        patronToGoOnAdventure = seatedPatron;
        pageNumber = 0;
        showQuestBookButtons(false);
        this.gameObject.SetActive(true);
        if (pagesInTheBookOfQuests.Count <= 0)
        {
            questName.text = "No Quests Left!";
            PageNumberText.text = " ";
            BackButton.gameObject.SetActive(true);
        }
        else
        {
            showQuestBookButtons(true);
            showQuestNameOnPage();
        }
    }

    public void sendPatronOnQuest()  //Patron patronToSendOnQuest
    {
        pagesInTheBookOfQuests[pageNumber].PatronsOnQuest.Add(patronToGoOnAdventure);
       
    }

    public void markQuestForRemoval()
    {
        pagesInTheBookOfQuests[pageNumber].RemoveQuestFromBookAtEndOfDay = true;
    }
   

    public void closeBookOfQuests()
    {
        this.gameObject.SetActive(false);
    }

    private void showQuestBookButtons(bool onOff) // here
    {

        foreach(Button b in allButtons)
        {
            b.gameObject.SetActive(onOff);
        }
    }

    private void showQuestNameOnPage()
    {
        clearGoldCost();
        questName.text = pagesInTheBookOfQuests[pageNumber].QuestName;
        PageNumberText.text = (pageNumber +1) + " / " + pagesInTheBookOfQuests.Count;
        displayGoldCost(pagesInTheBookOfQuests[pageNumber]);
        costOfQuest = costCalculator.RunningCostOfQuest;
    }

    public void flipPageLeft()
    {
        
        if (pageNumber > 0)
        {
            pageNumber--;
        }
        else
        {
            pageNumber = pagesInTheBookOfQuests.Count - 1;
        }
        Debug.Log(pageNumber);

        showQuestNameOnPage();
    }

    public void flipPageRight()
    {
       
        if (pageNumber < pagesInTheBookOfQuests.Count -1)
        {
            pageNumber++;
  
        }
        else
        {
            pageNumber = 0;
        }
        showQuestNameOnPage();
    }

    public void removeAllTakenQuests()
    {

        for (int i = 0; i < pagesInTheBookOfQuests.Count; i++)
        {
            if (pagesInTheBookOfQuests[i].RemoveQuestFromBookAtEndOfDay)
            {
                pagesInTheBookOfQuests.RemoveAt(i);
                i--;
            }
        }
    }

    private void clearGoldCost()
    {
        costCalculator.clearCost();
        GoldCostText.text = "";

    }

    private void displayGoldCost(Quest questToTallyUp)
    {
        costCalculator.priceOfTravelTime(questToTallyUp.TimeOnQuest);
        costCalculator.moralCodeChecker(patronToGoOnAdventure.thisPatronsAligence, questToTallyUp.WhoDoesThisQuestSupport);  // these are all split up because at one point I wanted a break down of why quests costed as much as they did.
        costCalculator.patronLevelModifier(patronToGoOnAdventure.Level);
        costCalculator.addBaseCost();
        GoldCostText.text += "Price: " + costCalculator.RunningCostOfQuest + " Coins";

    }

}
