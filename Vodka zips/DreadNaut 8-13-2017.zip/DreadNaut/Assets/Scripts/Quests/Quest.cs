﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Quest : MonoBehaviour
{


    // private string questGiver;
    private string questName;
    public string QuestName { get { return questName; } set { questName = value; } }

    private string questDescription;
    public string QuestDescription { get { return questDescription; } set { questDescription = value; } }

    private int timeOnQuest;
    public int TimeOnQuest { get { return timeOnQuest; } set { timeOnQuest = value; } }

    private byte successesOnQuest;
    public byte SuccessesOnQuest { get { return successesOnQuest; } set { successesOnQuest = value; } }

    private Queue<QuestLoader.Trial> trialsOfTheQuest = new Queue<QuestLoader.Trial>();
    public Queue<QuestLoader.Trial> TrialsOfTheQuest { get { return trialsOfTheQuest; } set { trialsOfTheQuest = value; } }

    private List<StoreableItem> rewardsFromQuest = new List<StoreableItem>();
    public List<StoreableItem> RewardsFromQuest { get { return rewardsFromQuest; } set { rewardsFromQuest = value; } }

    private List<Patron> patronsOnQuest = new List<Patron>();
    public List<Patron> PatronsOnQuest { get { return patronsOnQuest; } set { patronsOnQuest = value; } }


    private bool removeQuestFromBookAtEndOfDay = false;
    public bool RemoveQuestFromBookAtEndOfDay { get { return removeQuestFromBookAtEndOfDay; } set { removeQuestFromBookAtEndOfDay = value; } }

    private Patron.Aligence whoDoesThisQuestSupport;
    public Patron.Aligence WhoDoesThisQuestSupport;
    //public Quest( string QuestName, string QuestDescription, int TimeOnQuest, Queue<QuestLoader.Trial> TrialsOfTheQuest)
    // {

    //     questName = QuestName ;
    //     questDescription = QuestDescription ;
    //     timeOnQuest = TimeOnQuest;
    //     trialsOfTheQuest = TrialsOfTheQuest;

    // } 

    //public void assignQuestGiver(string giverIn)
    // {
    //     questGiver = giverIn;
    // }

    // public void assignQuestName (string questIn)
    // {
    //     questName = questIn;
    // }

    // public void assignQuestDescript(string discriptIn)
    // {
    //     questDescription = discriptIn;
    // }

    // public string getQuestName()
    // {
    //     return questName;
    // }

    // public string getQuestGiver()
    // {
    //     return questGiver;
    // }

    // public string getQuestDescription()
    // {
    //     return questDescription;
    // }

    // public void assignQuestLength(string questLength)
    // {
    //     int.TryParse(questLength, out timeOnQuest);
    // }

    // public int getQuestLenght()
    // {
    //     return timeOnQuest;
    // }

    // public QuestLoader.Trial attemptNextTrial()
    // {
    //     return trialsOfTheQuest.Peek();
    // }

    // public void compleeteTrial()
    // {
    //     trialsOfTheQuest.Dequeue();
    // }

    // public void assignTrials (Queue<QuestLoader.Trial> trialsToAdd)
    // {
    //     trialsOfTheQuest = trialsToAdd;
    // }

    // public Queue<QuestLoader.Trial> getTrials()
    // {
    //     return trialsOfTheQuest;
    // }

    // public byte getTrialsRemaining()
    // {
    //     return (byte)trialsOfTheQuest.Count;
    // }

    // //public void clearAllTrials()
    // //{
    // //    if (trialsOfTheQuest != null)
    // //    trialsOfTheQuest.Clear();
    // //}

    public void debugAllTrials()
    {
        Debug.Log(trialsOfTheQuest.Count);
        foreach (QuestLoader.Trial t in trialsOfTheQuest)
        {
            Debug.Log(t.challengeType.ToString());
        }
    }
}
