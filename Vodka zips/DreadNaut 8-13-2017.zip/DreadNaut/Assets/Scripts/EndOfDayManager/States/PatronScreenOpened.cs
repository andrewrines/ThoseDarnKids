﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class PatronScreenOpened : MonoBehaviour, IEndOfDayStates
{

    public EndOfDayManager endOfDayManager;


   // public Text DEBUGPATRONSINREGULARS; // to be replaced with some fancy button system. 
    public Button[] buttonsWithPatronsOnThem = new Button[6];
    public Button scrollUpButton;
    public Button scrollDownButton;
    public Text patronNameText;
    public Text patronFactionText;
    public Text patronStatsText;
    public Image patronPortrait;
    public Image patronPictureFrame;

    private int topOfTheListIndexNumber;
    private int bottomOfTheListIndexNumber;

    byte numberOfButtonsTodisplay;
    
       
    
    public void MapMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openMapScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to map from Patron");
    }

    public void PatronMenuOpen()
    {
       
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openRumorScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from Patron");
    }

    public void ShowPresetAssets()
    {
        topOfTheListIndexNumber = 0;
        bottomOfTheListIndexNumber = topOfTheListIndexNumber + buttonsWithPatronsOnThem.Length;
        scrollUpButton.gameObject.SetActive(true);
        scrollDownButton.gameObject.SetActive(true); // might need a better place for these, getting a bit crammped
        patronNameText.gameObject.SetActive(true);
        patronFactionText.gameObject.SetActive(true);
        patronStatsText.gameObject.SetActive(true);
        patronPortrait.gameObject.SetActive(true);
        patronPictureFrame.gameObject.SetActive(true);

         numberOfButtonsTodisplay = (byte)buttonsWithPatronsOnThem.Length; // here
        if (endOfDayManager.PatronsInRegulars.Count < buttonsWithPatronsOnThem.Length)
        {
            numberOfButtonsTodisplay = (byte)endOfDayManager.PatronsInRegulars.Count;
        }

        for (byte i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithPatronsOnThem[i].gameObject.SetActive(true);
        }
        labelButtons();
        ShowStatsOnPage(0);
        // DEBUGPATRONSINREGULARS.gameObject.SetActive(true);
     

            //string listOfPatronsFirstNames = " ";
            //foreach (Patron p in endOfDayManager.PatronsInRegulars)
            //{
            //    listOfPatronsFirstNames += p.Name + "\n";
            //}

            //DEBUGPATRONSINREGULARS.text = listOfPatronsFirstNames;
    }

    public void HidePresetAssets()
    {
        foreach (Button b in buttonsWithPatronsOnThem)
        {
            b.GetComponentInChildren<Text>().text = " ";
            b.gameObject.SetActive(false);
        }
        scrollUpButton.gameObject.SetActive(false);
        scrollDownButton.gameObject.SetActive(false);
        patronNameText.gameObject.SetActive(false);
        patronFactionText.gameObject.SetActive(false);
        patronStatsText.gameObject.SetActive(false);
        patronPortrait.gameObject.SetActive(false);
        patronPictureFrame.gameObject.SetActive(false);
    }

    public void labelButtons()
    {
        for (int i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithPatronsOnThem[i].GetComponentInChildren<Text>().text = endOfDayManager.PatronsInRegulars[i + topOfTheListIndexNumber].Name;
        }
    }

   public void ScrollUp()
    {
        if (topOfTheListIndexNumber > 0)
        {
            topOfTheListIndexNumber--;
            bottomOfTheListIndexNumber--;
            labelButtons();
        }
    }
   public void ScrollDown()
    {
        if(bottomOfTheListIndexNumber < endOfDayManager.PatronsInRegulars.Count)
        {
            topOfTheListIndexNumber++;
            bottomOfTheListIndexNumber++;
            labelButtons();
        }
    }

    public void ShowStatsOnPage(byte whichPatronToIndex)
    {
        int i = whichPatronToIndex + topOfTheListIndexNumber;
       patronNameText.text = endOfDayManager.PatronsInRegulars[i].Name;
        patronFactionText.text = endOfDayManager.PatronsInRegulars[i].thisPatronsAligence.ToString();

        patronStatsText.text = " ";
        for (Patron.StatTypes j = 0; j <= Patron.StatTypes.SWAY; j++ )
        {
            patronStatsText.text += j + ": " + endOfDayManager.PatronsInRegulars[i].PatronsStats[(byte)j] + "\n";
        }

        patronPortrait.sprite = ApperanceManager.instance.HowPatronLooks(endOfDayManager.PatronsInRegulars[i].thisPatronsJob); //endOfDayManager.apperanceManager.HowPatronLooks(endOfDayManager.PatronsInRegulars[i].thisPatronsJob);
    }

    public void ShowQuestOnPage(byte index)
    {

    }


    public void AddQuestToAdventureBook()
    {
       
    }

    public void BackOutOfQuestRumor()
    {
        
    }

}
