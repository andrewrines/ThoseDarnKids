﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class drinkOrderBubble : MonoBehaviour {

    Text order;
	public void displayDrinkRequest( Vector3 locationToMoveBubbleTo, string requestToDisplay)
    {
        this.gameObject.SetActive(true);
       
        this.transform.position = RectTransformUtility.WorldToScreenPoint(Camera.main, new Vector3(locationToMoveBubbleTo.x, locationToMoveBubbleTo.y, locationToMoveBubbleTo.z));//new Vector3((locationToMoveBubbleTo.x + (Screen.width/2)), Screen.height / 2, locationToMoveBubbleTo.z);
        order = this.GetComponentInChildren<Text>();
        order.text = requestToDisplay;
    }

    public void bubbleGoesAway()
    {
        this.gameObject.SetActive(false);
    }
}
