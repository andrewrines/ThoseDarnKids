﻿using UnityEngine;
using System.Collections;

public class Seat : MonoBehaviour
{
   public Patron patron;
   // public ApperanceManager apperanceManger;
    public drinkOrderBubble orderBubble;
    public FadingText fadingText;
    public Mug patronsMug;
    public IconPack patronWantsIcons;
    
   
    ISeatStates patronIsLeaving;
    ISeatStates noOneSeated;
    ISeatStates patronSeated;
    ISeatStates patronOrdered;
    ISeatStates patronIsDrinking;
    ISeatStates patronIsDrunk;
    ISeatStates patronWantsAdventure;
    ISeatStates patronReturningFromAdventure;

    ISeatStates seatState;

    bool isReadyForRespawn; 
    public bool IsReadyForRespawn { get { return isReadyForRespawn; } set { isReadyForRespawn = value; } }

    bool isNeedClear;
    public bool IsNeedClear { get { return isNeedClear; } set { isNeedClear = value; } }


    bool isHasOrdered;
    public bool IsHasOrdered { get { return isHasOrdered; }  set{ isHasOrdered = value; } }

    float waitTimer;
    public float WaitTimer { get { return waitTimer; } set { waitTimer = value; } }

    float drinkTimer;
    public float DrinkTimer { get { return DrinkTimer; } set { drinkTimer = value; } }

    bool isTimerPaused;
    public bool IsTimerPaused { get { return isTimerPaused; } set { isTimerPaused = value; } }





    private void Start()
    {
        noOneSeated = new NoOneSeated(this);
         patronSeated= new PatronSeated(this);
        patronOrdered = new PatronOrdered(this);
        patronIsDrinking = new PatronIsDrinking(this);
        patronIsDrunk = new PatronIsDrunk(this);
        patronWantsAdventure = new PatronWantsAdventure(this); // Added
        patronReturningFromAdventure = new PatronReturningFromAdventure(this);

        seatState = noOneSeated;
        isTimerPaused = false;


       // IsReadyForRespawn = true;

    }

    private void Update()
    {
        if (drinkTimer > 0)
        {
            drinkCountdown();
        }
        else
            patienceCountdown();
    }

    public void setSeatState(ISeatStates newSeatState)
    {
        seatState = newSeatState;
    }

    public void EmptySeat()
    {
        
       seatState.EmptySeat();
        patronWantsIcons.clearNeedsIcons();
    }

    public void FillSeat(Patron patronToSit)
    {
        isHasOrdered = false;
        seatState.FillSeat(patronToSit);

        if (patron.HasRumorToShare)
        {
            patronWantsIcons.patronWantsToTellYouSomething(); //shows an icon for I have a rumor, the rumory bits are actually handled in bar manager because it knows what a quest manager is. 
        }

        else if (patron.ReturningFromAQuest)
        {
            seatState.PatronReturnsFromQuest();
            patronWantsIcons.patronIsReturningFromQuest();

        }

        else if (patron.WantsToGoOnAdventure)  // added
        {
            seatState.PatronWantsToGoOnAdventure(); // Sets the state to I WANT TO ADVENTURE, locking it out of ordering drinks
            patronWantsIcons.PatronWantsToGoOnAnAdventure(); // displays icon for I want to adventure. 
        }

           

    }



    public void TalkWithPatron()
    {
        seatState.TalkWithPatron();
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        seatState.ConsumeBeverage(drinkToConsume);

    }

     public void PatronSharesARumor()
    {
        seatState.PatronSharesARumor();
    }


    #region yesCommands

    public ISeatStates ClearSeat()
    {
        return noOneSeated;
    }


    public ISeatStates SeatIsFilled()
    {
        return patronSeated;
    }

    public ISeatStates orderHasBeenTaken()
    {
        return patronOrdered;
    }

    public ISeatStates patronIsdrinking()
    {
        return patronIsDrinking;
    }

    public ISeatStates patronIsNowDrunk()
    {
        return patronIsDrunk;
    }

    public ISeatStates patronWouldLikeToGoOnAdventure()
    {
        return patronWantsAdventure;
    }

    public ISeatStates patronIsReturningFromAdventure()
    {
        return patronReturningFromAdventure;
    }

    #endregion


   public void setSeatTimer(float timeToSet)
    {
        waitTimer = timeToSet;
    }

    public void drinkCountdown()
    {
        if (!isTimerPaused)
        {
            drinkTimer -= Time.deltaTime;
            if (drinkTimer <= 0)
            {
                setSeatState(patronSeated);
                if (!patron.HasRumorToShare)
                {
                    patronWantsIcons.clearNeedsIcons();
                }
            }
        }
    }

    public void patienceCountdown()
    {
        if (!isTimerPaused)  
       {
          if (waitTimer > 0)
          {
               waitTimer -= Time.deltaTime;
           }
           else if (seatState == noOneSeated)
          {
            isReadyForRespawn = true;
          }
           else    
            {
            isNeedClear = true;
            }
          
        }
    }


    public void patronSays(string thingToSay)
    {
        fadingText.sendWhatToSay(patron.Name + " : " + thingToSay);
    }

}

