﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AdventureManager  {

    private List<Quest> questsInProgress;
    public List<Quest> QuestsInProgress { get { return questsInProgress; } set { questsInProgress = value; } }

    private List<Quest> questsToMakeChecks;

    private List<Patron> idleAdventurers;
    public List<Patron>  IdleAdventurers { get { return idleAdventurers; } set { idleAdventurers = value; } }

    public void initAdventureManager()
    {
        questsInProgress = new List<Quest>();
        questsToMakeChecks = new List<Quest>();
        idleAdventurers = new List<Patron>();

    }

    public void passTime()
    {
        foreach (Quest q in questsInProgress)
        {
            
            q.TimeOnQuest--;
            Debug.Log(q.QuestName);
            Debug.Log(q.TimeOnQuest);
            Debug.Log(q.PatronsOnQuest.Count);
            if (q.TimeOnQuest == 0)
            {
                questsToMakeChecks.Add(q);
            }
        }
        Debug.Log(questsInProgress.Count);
        if (questsToMakeChecks.Count > 0)
        {
            makeChecksForFinishedQuests();
            removeFinishedQuests();
        }
    }


    private void makeChecksForFinishedQuests()
    {
        foreach(Quest q in questsToMakeChecks)
        {
           foreach(QuestLoader.Trial t in q.TrialsOfTheQuest)
            {
                foreach (Patron p in q.PatronsOnQuest)
                {
                    if (p.PatronsStats[(byte)t.challengeType] > Random.Range(1,t.challengeRaiting))
                    {
                        // give xp to the person who compleeted the task, also have multiple people compleete tasks?
                        q.SuccessesOnQuest++;
                        break;
                    }
                }
            }
            q.PatronsOnQuest[0].QuestStub = q;
            q.PatronsOnQuest[0].ReturningFromAQuest = true;
            if (q.SuccessesOnQuest == q.TrialsOfTheQuest.Count) // this may need to change at some point;
            {
                q.PatronsOnQuest[0].WasQuestSucessful = true;
            }
            else
                q.PatronsOnQuest[0].WasQuestSucessful = false;

            foreach (Patron p in q.PatronsOnQuest)
            {
                Debug.Log("Something moved to idleadventurers");
                idleAdventurers.Add(p);
            }

            

        }

        questsToMakeChecks.Clear();
    }

    private void removeFinishedQuests()
    {
        for (int i = 0; i < questsInProgress.Count; i++)
        {
            if (questsInProgress[i].TimeOnQuest == 0)
            {
                Debug.Log("Pass the plate" +i);
                questsInProgress.RemoveAt(i);
                i--;
            }
        }
       
    }

    public void clearAllIdleAdventurers()
    {
        idleAdventurers.Clear();
    }

}
