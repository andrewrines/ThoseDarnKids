﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class BattleReportManager : MonoBehaviour {

    //public ApperanceManager apperanceManager;

    [SerializeField]
    GameObject BattleReportPannel;
    [SerializeField]
    Text QuestTitleText;
    [SerializeField]
    Text WinOrLose; // to be replaced with art
    [SerializeField]
    Text RecapText;
    [SerializeField]
    Button RedeemRewardsButton;
    public Image[] rewardImage = new Image[5];
    public Text[] howMuchOfRewardText = new Text[5];
    private List<StoreableItem> rewardsToRedeem = new List<StoreableItem>();
    public List<StoreableItem> RewardsToRedeem { get { return rewardsToRedeem; } }
    public enum ReportPages { OUTCOME,REWARDS,LEVEL, CLOSED};
    public ReportPages currentPageOfReport;

	// Use this for initialization
	void Start () {
	
	}
	
     public void ReadBattleReport(Patron patronCarryingPaystub)
    {
        currentPageOfReport = ReportPages.OUTCOME;
        BattleReportPannel.SetActive(true);
        QuestTitleText.text = patronCarryingPaystub.QuestStub.QuestName;

        if (patronCarryingPaystub.WasQuestSucessful)
        {
            WinOrLose.text = "WIN!";
            foreach (StoreableItem s in patronCarryingPaystub.QuestStub.RewardsFromQuest)
            {
                rewardsToRedeem.Add(s);
            }
            RedeemRewardsButton.GetComponentInChildren<Text>().text = "Redeem Rewards!";
        }
        else if (!patronCarryingPaystub.WasQuestSucessful)
        {
            WinOrLose.text = "LOSE...";
            RedeemRewardsButton.GetComponentInChildren<Text>().text = "Continue";
        }

    }

    public void flipOutcomePage()
    {
        currentPageOfReport++;
        switch(currentPageOfReport)
        {
            case ReportPages.REWARDS:
                {
                    FlipToRewardsPage();
                    break;   
                }


            case ReportPages.LEVEL:
                {
                    clearAllText();
                    break;
                }

            case ReportPages.CLOSED:
                {
                    clearAllText();
                    closeBattleReportPage();
                    break;
                }
        }
    }

    private void FlipToRewardsPage()
    {
        clearAllText();
        byte numberOfRewards = 0;
        foreach (StoreableItem s in rewardsToRedeem) 
        {
            rewardImage[numberOfRewards].gameObject.SetActive(true);
            rewardImage[numberOfRewards].sprite = s.displayArt();
            howMuchOfRewardText[numberOfRewards].text = s.NumberLeft.ToString();
            numberOfRewards++;
        }
    }

    private void FlipToLevelUpPage()
    {

    }

    public void closeBattleReportPage() 
    {
        rewardsToRedeem.Clear();
        BattleReportPannel.SetActive(false);
    }

    private void clearAllText()// really need to decide what I want to do with the rewards page. REALLY DON"T LOVE SPEARHEADING, but hey, sometimes you're to lazy to go to the computer lab. 
    {

     WinOrLose.text = "";
    // RecapText.text = "";

       foreach(Image i in rewardImage)
        {
            i.gameObject.SetActive(false);
        }
    }
}
