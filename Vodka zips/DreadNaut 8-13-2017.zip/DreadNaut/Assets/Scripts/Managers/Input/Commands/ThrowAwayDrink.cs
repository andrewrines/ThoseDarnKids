﻿using UnityEngine;
using System.Collections;

public class ThrowAwayDrink : CommandWithUndo
{

   

    public ThrowAwayDrink() : base()
    {
        
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.throwAwayDrink();
        }
        base.Execute(Bar);
    }
}
