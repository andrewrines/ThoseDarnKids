﻿using UnityEngine;
using System.Collections;

public class CommandWithUndo : Command, ICommandWithUndo
{
    BarManager Bar;                   //Refernece to the barManager
    public UndoCommand UndoCommand { get; set; }

    public CommandWithUndo() : base()
    {

    }

    public override void Execute(BarManager bar)
    {
        this.Bar = bar;   //Hold a refernce to the game componet this command was excuted on
        base.Execute(Bar);
    }
    public void UnExecute()
    {
        this.UndoCommand.Execute(Bar);
    }
}
