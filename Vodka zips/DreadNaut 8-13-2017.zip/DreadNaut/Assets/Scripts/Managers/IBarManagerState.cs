﻿using UnityEngine;
using System.Collections;
using System;

public interface IBarManagerState  {

    void ClearPatronHighlight();
    void MouseOverPatron();
    void ClickPatron();
    void MakeDrink(byte slotToUse);
    void PauseBar();
   
   // void patronDucking();
   // void patronMixingDrink();
    //void patronServingDrink();
}

public class NoPatronHighlighted : IBarManagerState
{

    BarManager barManager;

    public NoPatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }

   public void ClearPatronHighlight()
    {

    }

   public void MouseOverPatron()
    {
        barManager.setBarState(barManager.getYesHighlight());
    }
   public  void ClickPatron()
    {
       
    }

    public void MakeDrink(byte slotToUse)
    {
        barManager.drinkToServe.gameObject.SetActive(true);
        barManager.drinkToServe.gameObject.transform.position = Camera.main.ScreenToWorldPoint(barManager.drinkToServe.transform.position);
        barManager.drinkToServe.addIngredentToDrink(barManager.inventoryManager.useIngredentFromInvintory(slotToUse));
        barManager.drinkToServe.gameObject.GetComponent<drinkOrderBubble>().displayDrinkRequest(barManager.drinkToServe.transform.position, barManager.drinkToServe.listIngredentsInDrink());
        //barManager.drinkToServe.gameObject.GetComponent<MixingColors>().addColor(slotToUse); SHHHHHHHH!
        barManager.setBarState(barManager.getNoHighlight()); // making drink;
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }
}

public class PatronHighlighted : IBarManagerState
{

    BarManager barManager;

    public PatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }

    public void ClearPatronHighlight()
    {
        Debug.Log("swiching to no one highlighted");
        barManager.SelectedSeat = null;
        barManager.setBarState(barManager.getNoHighlight());
            
    }

    public void MouseOverPatron()
    {
    }
    public void ClickPatron()
    {
        if (barManager.SelectedSeat.patron.ReturningFromAQuest)
        {
            barManager.battleReportManager.ReadBattleReport(barManager.SelectedSeat.patron);
            barManager.isTimePaused(true);
            barManager.SelectedSeat.patron.ReturningFromAQuest = false;
            barManager.SelectedSeat.patron.QuestStub = null;
            barManager.setBarState(barManager.barIsPaused());
            barManager.SelectedSeat.TalkWithPatron();
        }

       else if (barManager.SelectedSeat.patron.WantsToGoOnAdventure)
        {
            barManager.isTimePaused(true);
            barManager.bookOfQuests.OpenBookOfQuests(barManager.SelectedSeat.patron);
            barManager.setBarState(barManager.barIsPaused());
            barManager.SelectedSeat.TalkWithPatron();
        }

       else if (barManager.drinkToServe.countIngredentsInDrink() > 0 && barManager.SelectedSeat.IsHasOrdered) // HACK to fix a bug where the bar keep makes a drink before asking them what they want, I want to be able to serve the drink 
        {
            barManager.serveDrink();
            barManager.setBarState(barManager.getNoHighlight());
        }
        else
        {
            barManager.SelectedSeat.TalkWithPatron();
            barManager.setBarState(barManager.getYesHighlight());
        }
    }

    public void MakeDrink(byte SlotToUse)
    {
       
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }
}

public class PatronClicked : IBarManagerState
{

    BarManager barManager;
    

    public PatronClicked(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {

        Debug.Log("Patron no longer hilighted");
        barManager.setBarState(barManager.getNoHighlight());
    }

    public void MouseOverPatron()
    {
       
    }
    public void ClickPatron()
    {
       barManager.setBarState(barManager.getNoHighlight());
    }

    public void MakeDrink(byte slotToUse)
    {
       
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }
}


public class BarPaused : IBarManagerState    // rename this pause bar Time;
{

    BarManager barManager;


    public BarPaused(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {

    }

    public void MouseOverPatron()
    {

    }
    public void ClickPatron()
    {
      
    }

    public void MakeDrink(byte slotToUse)
    {

    }

    public void PauseBar()
    {
        
    }
}
