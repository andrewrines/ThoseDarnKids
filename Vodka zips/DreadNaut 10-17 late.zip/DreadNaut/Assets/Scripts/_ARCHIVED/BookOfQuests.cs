﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class BookOfQuests : MonoBehaviour { }

//    CostCalculator costCalculator; 

//    private List<Quest> pagesInTheBookOfQuests = new List<Quest>();
//    public List<Quest> PagesInTheBookOfQuests { get { return pagesInTheBookOfQuests; } set { pagesInTheBookOfQuests = value; } }

//    private int costOfQuest;
//    public int CostOfQuest { get { return costOfQuest; } set { costOfQuest = value; } }

//    Patron patronToGoOnAdventure;
//    public MapManager mManager;
//    public Text GoldCostText;
//    public GameObject BookOfQuestsAnchor;
//    public Text questName;
//    public Text GoldPriceForQuest;
//    public Text PageNumberText;
//    public Button acceptQuest;
//    public Button BackButton;
//    public Button leftButton;
//    public Button rightButton;
//    Button[] allButtons;

//    public Text cheatSheetName;
//    public Text cheatSheetLevel;
//    public Text cheatSheetExp;
//    public Text cheatSheetStats;
//    public Text cheatSheetFaction; 
    

//    private int pageNumber;

//    private void initBookOfQuests()
//    {
//        costCalculator = new CostCalculator();
//        initButtons();
//    }

//    private void initButtons()
//    {
//        allButtons = new Button[4];
//        allButtons[0] = acceptQuest;
//        allButtons[1] = BackButton;
//        allButtons[2] = leftButton;
//        allButtons[3] = rightButton;
//    }

//    public void OpenBookOfQuests(Patron seatedPatron) 
//    {
//        //if (mManager== null)
//        //{
//        //    mManager = FindObjectOfType<MapManager>(); // TODO fix this at some point
//        //}
//        //mManager.CreateNewAdventure(seatedPatron);

//        if (costCalculator == null)
//        {
//            initBookOfQuests();
//        }

//        patronToGoOnAdventure = seatedPatron;
//        pageNumber = 0;
//        showQuestBookButtons(false);
//        BookOfQuestsAnchor.gameObject.SetActive(true);
//        //this.gameObject.SetActive(true);
       
//        if (pagesInTheBookOfQuests.Count <= 0)
//        {
//            questName.text = "No Quests Left!";
//            PageNumberText.text = " ";
//            BackButton.gameObject.SetActive(true);
//            clearGoldCost();
//        }
//        else
//        {
//            showQuestBookButtons(true);
//            showQuestNameOnPage();
//        }
//        showPatronCheatSheet();
//    }

//    public void sendPatronOnQuest()  //Patron patronToSendOnQuest
//    {
//        pagesInTheBookOfQuests[pageNumber].PatronsOnQuest.Add(patronToGoOnAdventure);
//        patronToGoOnAdventure.NameOfQuestOn = pagesInTheBookOfQuests[pageNumber].QuestName; // here we add the name of the adventure the patron is on, not sure if this is the best place for it or not. 
//        patronToGoOnAdventure.NumberOfDaysLeftOnQuest = pagesInTheBookOfQuests[pageNumber].TimeOnQuest;
//    }

//    public void markQuestForRemoval()
//    {
//        pagesInTheBookOfQuests[pageNumber].RemoveQuestFromBookAtEndOfDay = true;
//    }
   

//    public void closeBookOfQuests()
//    {
//        BookOfQuestsAnchor.gameObject.SetActive(false);
//    }

//    private void showQuestBookButtons(bool onOff) // here
//    {

//        foreach(Button b in allButtons)
//        {
//            b.gameObject.SetActive(onOff);
//        }
//    }

//    private void showQuestNameOnPage()
//    {
//        clearGoldCost();
//        questName.text = pagesInTheBookOfQuests[pageNumber].QuestName;
//        PageNumberText.text = (pageNumber +1) + " / " + pagesInTheBookOfQuests.Count;
//        displayGoldCost(pagesInTheBookOfQuests[pageNumber]);
//        costOfQuest = costCalculator.RunningCostOfQuest;
//    }

//    public void flipPageLeft()
//    {
        
//        if (pageNumber > 0)
//        {
//            pageNumber--;
//        }
//        else
//        {
//            pageNumber = pagesInTheBookOfQuests.Count - 1;
//        }
//        Debug.Log(pageNumber);

//        showQuestNameOnPage();
//    }

//    public void flipPageRight()
//    {
       
//        if (pageNumber < pagesInTheBookOfQuests.Count -1)
//        {
//            pageNumber++;
  
//        }
//        else
//        {
//            pageNumber = 0;
//        }
//        showQuestNameOnPage();
//    }

//    public void removeAllTakenQuests()
//    {

//        for (int i = 0; i < pagesInTheBookOfQuests.Count; i++)
//        {
//            if (pagesInTheBookOfQuests[i].RemoveQuestFromBookAtEndOfDay)
//            {
//                pagesInTheBookOfQuests.RemoveAt(i);
//                i--;
//            }
//        }
//    }

//    private void clearGoldCost()
//    {
//        costCalculator.clearCost();
//        GoldCostText.text = "";

//    }

//    private void displayGoldCost(Quest questToTallyUp)
//    {
//        costCalculator.priceOfTravelTime(questToTallyUp.TimeOnQuest);
//        costCalculator.moralCodeChecker(patronToGoOnAdventure.thisPatronsAligence, questToTallyUp.WhoDoesThisQuestSupport);  // these are all split up because at one point I wanted a break down of why quests costed as much as they did.
//        costCalculator.patronLevelModifier(patronToGoOnAdventure.Level);
//        costCalculator.addBaseCost();
//        GoldCostText.text += "Price: " + costCalculator.RunningCostOfQuest + " Coins";

//    }

//    private void showPatronCheatSheet()
//    {
//        cheatSheetName.text = "Name:" + patronToGoOnAdventure.Name;
//        cheatSheetLevel.text = "Level:" + patronToGoOnAdventure.Level.ToString();
//        cheatSheetExp.text = "Exp:" + patronToGoOnAdventure.ExperiencePoints + "/" + patronToGoOnAdventure.ExperienceThresholdToNextLevel;
//        cheatSheetFaction.text = "Faction:" + patronToGoOnAdventure.thisPatronsAligence.ToString();

//        cheatSheetStats.text = "Stats: \n ";
//        for (Patron.StatTypes j = 0; j <= Patron.StatTypes.SWAY; j++)
//        {
//            cheatSheetStats.text += j + ": " + StatDescriptorLoader.Instance.statOut(j, patronToGoOnAdventure.PatronsStats[(byte)j]) + "\n";
//        }
//    }

//}
