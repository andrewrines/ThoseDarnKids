﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class RumorLoader
{
  
    string path;
    string jsonString;
    JSONObject rumorToCraft;
    enum rumorParserHelper { NAME,DESCRIPTION,QUESTS, REPEATABLE }; // a more visual way to see the construction of the rumor
    public enum RepeatableTypes {BASIC,REPEATABLE,STORY,FETCH};  // no = quest goes away after any compleetion, yes means the quest comes back after compleetion, onfail means the quest comes back after it is failed, fetch means the quest never leaves the pool and multiple instances can be made. 

    private RumorWarehouse rumorWarehouse = new RumorWarehouse(); 
    private List<byte> allRumorNumbers; 
    //private QuestLoader qLoader = new QuestLoader();


    public void JsonRumorInit()
    {
        path = Application.streamingAssetsPath + "/JsonFiles/RumorsInGame.json";
        jsonString = File.ReadAllText(path);
        rumorToCraft = new JSONObject(jsonString);
       // qLoader.JsonQuestInit();
    }

    private void declareSizeOfWarehouse()
    {
        rumorWarehouse.initRumorsByLevelArray(rumorToCraft.Count - 1);
    }

    public RumorWarehouse populateWarehouse()
    {
        declareSizeOfWarehouse();
        for (byte level = 0; level < rumorToCraft.Count; level++)
        {
            var rumorLevel = rumorToCraft[level].keys;
            foreach (string s in rumorLevel)
            {
               
               Rumor rumorToStore = rumorCreator(level, s); 

                if (level < rumorToCraft.Count -1)
                    rumorWarehouse.storeRumor(level, rumorToStore);

                else
                    rumorWarehouse.storeUnlockable(s, rumorToStore);
            }
        }

        return rumorWarehouse;
    }

  

    private Rumor rumorCreator(byte levelOfRumor, string rumorIndexer)
    {

        List<string> namesToFind = new List<string>(); 
        byte RumorLevel = levelOfRumor;
        RepeatableTypes repType = translateRepeatableType(rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.REPEATABLE].str);
        string RumorName = rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.NAME].str; // trying this out to make creation a little more readable; 
        string RumorDescription = rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.DESCRIPTION].str;

        for (int i = 0; i < rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.QUESTS].Count; i++) // adds the names of the quests we would like to attach to this rumor, these will be found in RUMORQUESTCOMBINER.
        {

             namesToFind.Add(rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.QUESTS][i].str);
            //Quest q = new Quest();
            //q = qLoader.questCreator(rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.QUESTS][i].str);
            //q.RumorID = rumorToReturn.RumorName;
            //q.LevelOfQuest = levelOfRumor;
            //q.RumorRepeat = rumorToReturn.RepeatableType;
            //rumorToReturn.QuestForThisRumor.Add(q);
        }
        Rumor rumorToReturn = new Rumor(RumorName, RumorDescription, RumorLevel, repType, namesToFind);
        return rumorToReturn; 
    }

   

    private RepeatableTypes translateRepeatableType(string RepeatableType)
    {
        switch (RepeatableType.ToLower())
        {
            case "basic":
                {
                    return RepeatableTypes.BASIC;
                }

            case "repeatable":
                {
                    return RepeatableTypes.REPEATABLE; 
                }

            case "story":
                {
                    return RepeatableTypes.STORY;
                }

            case "fetch":
                {
                    return RepeatableTypes.FETCH;
                }

            default:
                {
                    Debug.Log("Fall through on search of repeat type, im in rumor loader");
                    return RepeatableTypes.BASIC;
                }
        }
    }
}
