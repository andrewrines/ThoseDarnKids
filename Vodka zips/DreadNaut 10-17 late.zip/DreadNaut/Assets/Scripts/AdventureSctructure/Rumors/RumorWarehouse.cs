﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RumorWarehouse
{
    List<Rumor> commonKnowlage = new List<Rumor>();
    List<Rumor>[] rumorsByLevel;
    Dictionary<string, Rumor> unlockableRumors = new Dictionary<string, Rumor>();
    QuestLoader questLoader = new QuestLoader(); 


    public void initRumorWarehouse()
    {
        questLoader.JsonQuestInit();
    }

    public void initRumorsByLevelArray(int levelsOfRumor)
    {
        rumorsByLevel = new List<Rumor>[levelsOfRumor];
       
        for (int i = 0; i < rumorsByLevel.Length; i++)
        {
            rumorsByLevel[i] = new List<Rumor>();
        }
    }

    public void storeRumor(int level, Rumor rumorToStore)
    {

        rumorToStore.QuestForThisRumor.Clear();

        if (level > rumorsByLevel.Length)
        {
            commonKnowlage.Add(rumorToStore);
        }
        else
        rumorsByLevel[level].Add(rumorToStore);
    }

    public void storeUnlockable(string nameOfUnlockableRumor, Rumor rumorToStore)
    {
        unlockableRumors.Add(nameOfUnlockableRumor, rumorToStore);
    }

    public Rumor giveRandomRumorBasedOnLevel(byte levelOfRumor)
    {
        Rumor rumorToReturn;
        if (commonKnowlage.Count != 0)
        {
            rumorToReturn = commonKnowlage[0];
            commonKnowlage.RemoveAt(0);
            // TODO figgure an algorighum to sometimes pick unockable rumors onece this works; 
        }
        else
        {
            int randy = Random.Range(0, rumorsByLevel[levelOfRumor].Count);
            rumorToReturn = rumorsByLevel[levelOfRumor][randy];
            rumorsByLevel[levelOfRumor].RemoveAt(randy);
        }

        if (rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.FETCH)
        {
            Rumor rumorToStoreAgain = new Rumor(rumorToReturn.RumorName, rumorToReturn.RumorDescription, rumorToReturn.RumorLevel, rumorToReturn.RepeatableType, rumorToReturn.QuestsToFind);
            storeRumor(rumorToStoreAgain.RumorLevel,rumorToStoreAgain);
        }



        foreach (string questName in rumorToReturn.QuestsToFind)
        {
            Quest questToAdd = new Quest();
            questToAdd = questLoader.createQuestByName(questName);
            questToAdd.RumorID = rumorToReturn.RumorName;
            questToAdd.LevelOfQuest = levelOfRumor;
            questToAdd.RumorRepeatType = rumorToReturn.RepeatableType;
            rumorToReturn.QuestForThisRumor.Add(questToAdd);
        }
        return rumorToReturn;
    }

    public void unlockSpecificRumorBasedOnName(string name)
    {
        Rumor RumorToAssign = unlockableRumors[name];
        Rumor RumorToAdd = new Rumor(RumorToAssign.RumorName, RumorToAssign.RumorDescription, RumorToAssign.RumorLevel, RumorToAssign.RepeatableType, RumorToAssign.QuestsToFind);
        commonKnowlage.Add(RumorToAdd);
        Debug.Log("Regarding unlockable quests" + commonKnowlage.Count);
    }


}
