﻿using UnityEngine;
using System.Collections;

public class ApperanceManager : MonoBehaviour {

    public static ApperanceManager instance { get; private set; }

    public Sprite flagSprite;
    public Sprite potentialQuestFlag;

    Sprite[] ingredentApperance = new Sprite[4];
    public Sprite RED;
    public Sprite YELLOW;
    public Sprite GREEN;
    public Sprite BLUE;

    public Sprite[] allCurrenciesApperances = new Sprite[5];
    public Sprite Gold;
    public Sprite AApts;
    public Sprite EvilOrderPts;
    public Sprite CollegePts;
    public Sprite CorporealPts;

    public Sprite[] allFactionArt = new Sprite[4];


    public Sprite[] PatronArtInGame = new Sprite[200];

    public Sprite[] PatronTokens = new Sprite[12];

   // public Sprite[] allEquipmentApperances = new Sprite[1]; // more comming soon!




    private void Awake()
    {
        instance = this;
        ingredentApperance[0] = RED;
        ingredentApperance[1] = YELLOW;
        ingredentApperance[2] = GREEN;
        ingredentApperance[3] = BLUE;

        allCurrenciesApperances[0] = Gold;
        allCurrenciesApperances[1] = AApts;
        allCurrenciesApperances[2] = EvilOrderPts;
        allCurrenciesApperances[3] = CollegePts;
        allCurrenciesApperances[4] = CorporealPts;

       
        allFactionArt[0] = CollegePts;
        allFactionArt[1] = CorporealPts;
        allFactionArt[2] = AApts;
        allFactionArt[3] = EvilOrderPts;

    }

    public Sprite whatDoesTheIngredentLookLike(Ingredent.ingredentColor theColorOfTheIngredent)
    {
        return ingredentApperance[(int)theColorOfTheIngredent];
    }

    public Sprite HowThisPatronLooks(byte patronsId)
    {
        return PatronArtInGame[patronsId];
    }

    public Sprite ThisPatronsToken(byte patronsId)
    {
        return PatronTokens[patronsId];
    }


    public Sprite whatCurrencyLooksLike(Currency.whosCurrencyIsThis currencyIn)
    {
        return allCurrenciesApperances[(int)currencyIn];
    }

    public Sprite whatFactionIsThis(Patron.Aligence aligenceIn)
    {
        return allFactionArt[(int)aligenceIn];
    }

    public Sprite getFlag() // later to replace with getFlag by number of quest 
    {
        return flagSprite;
    }

    public Sprite getPotentialQuestFlag()
    {
        return potentialQuestFlag;
    }



}
