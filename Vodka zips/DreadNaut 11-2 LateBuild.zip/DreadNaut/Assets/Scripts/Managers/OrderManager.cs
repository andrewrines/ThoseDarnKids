﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class OrderManager : MonoBehaviour {

    public List<Drink> drinkCollection = new List<Drink>();
    private DrinkLoader dLoader = new DrinkLoader();

    public enum orderAccuracy {NONE,MIXUP, CORRECT};

    private void Start()
    {
        dLoader.loadTools();
        drinkCollection = dLoader.populateDrinkCollection();
    }


    private Drink chooseRandomDrink()
    {
       int orderNumber = Random.Range(0, drinkCollection.Count);

        return drinkCollection[orderNumber];
    }

    public orderAccuracy determineDrinkPrice(IOrder PatronOrder, Drink drinkMade)
    {
        Drink drinkFromDatabase = findDrinkInDataBase(drinkMade);

        if (drinkFromDatabase == null)
        {
            Debug.Log("This drink dosen't even exist");
            return orderAccuracy.NONE;
        }

        if (PatronOrder.checkAccuracy(drinkFromDatabase))
        {
            Debug.Log("Correct Drink");
            drinkMade.CorrectPrice = drinkFromDatabase.CorrectPrice;
            return orderAccuracy.CORRECT;
        }
        else
        {
            Debug.Log("Mix up");
            drinkMade.MixUpPrice = drinkFromDatabase.MixUpPrice;
            return orderAccuracy.MIXUP;
        }

    }

    private Drink findDrinkInDataBase (Drink drinkToFind)
    {
        
        bool canDrinkBeReturned;


        foreach (Drink d in drinkCollection)
        {
           canDrinkBeReturned = true;
            if (d.NumberOfIngredentsInDrink != drinkToFind.NumberOfIngredentsInDrink)
            {
                continue;
            }

            else
            {
                for (int i = 0; i < d.DrinkIngredents.Length; i++)
                {
                    if (d.DrinkIngredents[i] != drinkToFind.DrinkIngredents[i])
                    {
                        canDrinkBeReturned = false;
                        break;
                    }
                }
                if (canDrinkBeReturned)
                {
                     return d;

                }
            }
        }

        return null;

    }

    public IOrder makeAnOrder()
    {
        int randomNumber = Random.Range(0, 5);

        switch (randomNumber)
        {
            case 1:
                {
                    return new OrderByName(chooseRandomDrink());
                  
                }
            case 2:
                {
                    return new OrderByFlavor(chooseRandomDrink().ThisDrinksFlavor);
                   
                }
            case 3:
                {
                    return new OrderByIngredent();
                 
                }

            case 4:
                {
                    return new OrderByLackOfIngredent();
                   
                }

            default:
                {
                    return new OrderByName(chooseRandomDrink());
                 
                }
        }
    }
}
