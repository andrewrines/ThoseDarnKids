﻿
public interface IPurchaseable  {

    void purchaseItem();
    void unlock();
    void setPrice(int newPrice);
    
}
