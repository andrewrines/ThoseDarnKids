﻿using UnityEngine;
using System.Collections;
using System;

public class ShopState : MonoBehaviour, IEndOfDayStates
{

    public EndOfDayManager endOfDayManager;

    public void AddQuestToMap()
    {
        throw new NotImplementedException();
    }

    public void BackOutOfQuestRumor()
    {
        throw new NotImplementedException();
    }

    public void HidePresetAssets()
    {
        Debug.Log("Im hiding the preset assets");
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from store");
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openRumorScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from store");
    }

    public void StoreMenuOpen()
    {

    }

    public void ScrollDown()
    {
        throw new NotImplementedException();
    }

    public void ScrollUp()
    {
        throw new NotImplementedException();
    }

    public void ShowPresetAssets()
    {
        Debug.Log("Hi im the preset assets for this page");
    }

    public void ShowQuestOnPage(Quest quest)
    {
        throw new NotImplementedException();
    }

    public void ShowStatsOnPage(byte index)
    {
        throw new NotImplementedException();
    }

    public void turnPageLeftInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void turnPageRightInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void formatButtonsForThisPage()
    {

    }



    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
