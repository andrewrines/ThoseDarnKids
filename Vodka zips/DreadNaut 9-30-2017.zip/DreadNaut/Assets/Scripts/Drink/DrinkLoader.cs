﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class DrinkLoader  {

    private string FallThroughHelper;  // used to help me find JSON typos
                                       // private static patronLoader instance = null;
                                       // private static readonly object padloc = new object();

    private enum drinkjsonHelper {NAME,RED,YELLOW,BLUE,GREEN,FLAVOR,CORRECT,MIXUP};
    private string jsonString;
    private string path;

    private JSONObject drinkToParse;
    

   

    public void loadTools()
    {
        path = Application.dataPath + "/JsonFiles/DrinkList.json";
        jsonString = File.ReadAllText(path);
       drinkToParse = new JSONObject(jsonString);
    }

    public List<Drink> populateDrinkCollection()
    {
        List<Drink> drinkListToReturn = new List<Drink>();
        for (int i = 0; i < drinkToParse.Count; i++)
        {
           drinkListToReturn.Add(DrinkCreator(i));
        }

        return drinkListToReturn;
    }



    private Drink DrinkCreator(int drinkIndexer)
    {
        Drink drinkToCreate = new Drink();
        drinkToCreate.DrinkName = drinkToParse[drinkIndexer][(int)drinkjsonHelper.NAME].str; 
        drinkToCreate.DrinkIngredents[0] = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.RED].i;
        drinkToCreate.DrinkIngredents[1] = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.YELLOW].i;
        drinkToCreate.DrinkIngredents[2] = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.GREEN].i;
        drinkToCreate.DrinkIngredents[3] = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.BLUE].i;
        drinkToCreate.CorrectPrice = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.CORRECT].i;
        drinkToCreate.MixUpPrice = (byte)drinkToParse[drinkIndexer][(int)drinkjsonHelper.MIXUP].i;
        drinkToCreate.ThisDrinksFlavor = drinkFlavorParser(drinkToParse[drinkIndexer][(int)drinkjsonHelper.FLAVOR].str);
        drinkToCreate.NumberOfIngredentsInDrink = addAllIngredents(drinkToCreate);
        return drinkToCreate;
    }

    private int addAllIngredents(Drink drinkWithIngredentsToCount)
    {
        int runningTotalToReturn = 0;

        for (int i = 0; i < drinkWithIngredentsToCount.DrinkIngredents.Length; i++)
        {
            runningTotalToReturn += drinkWithIngredentsToCount.DrinkIngredents[i];
        }

        return runningTotalToReturn;
    }



    private Drink.flavor drinkFlavorParser(string flavorToParse)
    {
        switch (flavorToParse.ToLower())
        {

            case "sweet":
                {
                    return Drink.flavor.SWEET;
                }
            case "bitter":
                {
                    return Drink.flavor.BITTER;
                }
            case "fruity":
                {
                    return Drink.flavor.FRUITY;
                }
            case "magic":
                {
                    return Drink.flavor.MAGIC;
                }
            default:
                {
                    Debug.Log("Flavor Fall through:" + FallThroughHelper);
                    return Drink.flavor.FRUITY;
                }

        }


    }

  

}
