﻿using UnityEngine;
using System.Collections;

public class ScanforItemClick : CommandWithUndo
{


    public ScanforItemClick() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {

        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
           // change state to drink makery
        }
        base.Execute(Bar);
    }
}
