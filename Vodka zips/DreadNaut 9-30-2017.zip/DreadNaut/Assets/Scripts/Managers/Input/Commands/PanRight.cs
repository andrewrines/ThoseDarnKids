﻿using UnityEngine;
using System.Collections;

public class PanRight : CommandWithUndo
{

    public PanRight() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        Camera.main.GetComponent<CameraManager>().panRight();
    }
}
