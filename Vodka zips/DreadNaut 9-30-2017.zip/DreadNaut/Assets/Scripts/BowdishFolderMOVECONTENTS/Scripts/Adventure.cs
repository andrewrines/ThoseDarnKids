﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class Adventure
{
    Color colorWhenSelected;
    Color colorWhenNotSelected;

    public bool isAdventureOver = false; // NC added 9/24 not sure if this is the best way to go about this, want to inform map manager that the quest is over without passing adventure nodes, swaps in advance location method I added

    List<AdventureNode> AdventureNodes = new List<AdventureNode>(); //A list of all the nodes the patron will travel to throughout the adventure .. nc made public for debug purpose
    AdventureNode NodeUnderConstruction;                                //As a player clicks on locations and quests, this temporary node will hold the info
                                                                        //Will eventually to be added to AdventureNodes

    Patron patronOnAdventure;   //The patron that will be on this adventure
    public Patron PatronOnAdventure{get { return patronOnAdventure; }}//pardon my reach

    public Adventure(Patron desiredPatron, Location startingNode, Color _colorWhenSelected, Color _colorWhenNotSelected)
    {
        patronOnAdventure = desiredPatron;
        colorWhenSelected = _colorWhenSelected;
        colorWhenNotSelected = _colorWhenNotSelected;

        //make the first node the bar
        NodeUnderConstruction = new AdventureNode();

        SetNodeUnderConstructionToDefault();
        SetNodeLocation(startingNode, null);
        ConfirmNewNode();
    }

   public struct AdventureNode  // made public for debug purposes
    {
        public Location location;
        public Quest targetQuest;
        public Road roadHighlighted;
    }

    public void SetNodeLocation(Location desiredLocation, Road connectingRoad)
    {
        if (desiredLocation != null)
        {
            desiredLocation.GetComponent<Image>().color = colorWhenSelected;
            NodeUnderConstruction.location = desiredLocation;
        }

        if (connectingRoad != null)
        {
            connectingRoad.GetComponent<Image>().color = colorWhenSelected;
            NodeUnderConstruction.roadHighlighted = connectingRoad;
        }

    }

    public void SetNodeQuest(Quest desiredQuestName)
    {
        if (desiredQuestName != null)
        {
            Debug.Log(PatronOnAdventure + "Took quest" + desiredQuestName.QuestName);
            PatronOnAdventure.QuestsToCompleete.Add(desiredQuestName);
        }

        NodeUnderConstruction.targetQuest = desiredQuestName;
       
    }

    void SetNodeRoadToHighlight(Road desiredRoad)
    {
        NodeUnderConstruction.roadHighlighted = desiredRoad;
    }

    public void ConfirmNewNode()
    {
        AdventureNodes.Add(NodeUnderConstruction);
        SetNodeUnderConstructionToDefault();
    }

    public void SetNodeUnderConstructionToDefault()
    {
        NodeUnderConstruction.location = null;
        NodeUnderConstruction.targetQuest = null;
        NodeUnderConstruction.roadHighlighted = null;
    }

    public bool IsLocationAlreadyInAdventure(Location locationToCheck)
    {
        for (int i = 0; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].location == locationToCheck)
                return true;
        }

        return false;
    }

    public void RemoveAllNodesPastGivenNodeLocation(Location desiredLastLocation)
    {
        int foundIndex = -1;

        for (int i = 0; i < AdventureNodes.Count; i++) // "i < Count - 1" because we don't need to check the last element in the list
        {
            if(foundIndex != -1 && i > foundIndex)
            {
                AdventureNodes[i].location.GetComponent<Image>().color = colorWhenNotSelected;
                AdventureNodes[i].roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected;
            }
            else if(AdventureNodes[i].location == desiredLastLocation)
            {
                foundIndex = i;
            }
        }

        if(foundIndex != -1)
            AdventureNodes.RemoveRange(foundIndex + 1, AdventureNodes.Count-(foundIndex+1));

    }

    void RemoveAllNodesPastGivenNodeLocation(int locationIndex)
    {
        for (int i = locationIndex; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].location != null) { AdventureNodes[i].location.GetComponent<Image>().color = colorWhenNotSelected; }
            if (AdventureNodes[i].roadHighlighted != null) { AdventureNodes[i].roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected; }
        }
        if (NodeUnderConstruction.roadHighlighted != null) { NodeUnderConstruction.roadHighlighted.GetComponent<Image>().color = colorWhenNotSelected; }
        if (NodeUnderConstruction.location != null) { NodeUnderConstruction.location.GetComponent<Image>().color = colorWhenNotSelected; }
        //AdventureNodes.Clear(); This actually deletes the previous adventure, making the patron come home in one day. 

    }

    public void ClearAdventure()
    {
        RemoveAllNodesPastGivenNodeLocation(0);
    }

    public void advanceToNextLocation() // NC added 9/24
    {
        AdventureNodes.RemoveAt(0);

        //  foreach (AdventureNode a in AdventureNodes)
        //{
        // Debug.Log(PatronOnAdventure.Name + "+" + a.location);

        //}
        if (AdventureNodes.Count == 0)
        {
            Debug.Log(patronOnAdventure.Name + "Is done with their adventure");
            isAdventureOver = true;
        }
        else
        {
            resolveLocationEvents();
        }

    }

    public void resolveLocationEvents()
    {
       
        if (PatronOnAdventure.QuestsToCompleete.Count != 0 && PatronOnAdventure.QuestsToCompleete[0] == AdventureNodes[0].targetQuest)
        {
            rollForQuest();
        }


    }

    private void rollForQuest()
    {
        Debug.Log(PatronOnAdventure.Name + " Is attempting " + AdventureNodes[0].targetQuest.QuestName);

        for (int i = 0; i < PatronOnAdventure.QuestsToCompleete[0].TrialsOfTheQuest.Count; i++ )
        {
            QuestLoader.Trial trialToTest = PatronOnAdventure.QuestsToCompleete[0].TrialsOfTheQuest[i];
            byte patronsRoll = PatronOnAdventure.rollPatronStat(trialToTest.challengeType);
            Debug.Log(PatronOnAdventure.Name + " : " + patronsRoll + " VS " + trialToTest.challengeType+ " : " + trialToTest.challengeRaiting +" Trial number:" + i + " Help:" + trialToTest.winText );
            if (patronsRoll < trialToTest.challengeRaiting)
            {
                PatronOnAdventure.fatiguePatron(trialToTest.challengeType, (byte)(trialToTest.challengeRaiting -patronsRoll));
                Debug.Log("AHHHH a nasty gash for " + (trialToTest.challengeRaiting - patronsRoll) + " Fatigue");

                if (patronOnAdventure.IsExhausted)
                {
                    Debug.Log(patronOnAdventure.Name + " is exhaused, they are returning to base");
                    //AdventureNodes.Clear();
                    PatronOnAdventure.QuestsToCompleete[0].IsQuestSucessful = false;
                    isAdventureOver = true; // i don't know if this is ok, clears all adventures and tells the map manager that the quest is in fact over.
                    break; // breaks, we don't test anymore if someone fails outright
                }
            }

          
        }

        if (!isAdventureOver)
        {
            Debug.Log("They did the quest");
            PatronOnAdventure.QuestsToCompleete[0].IsQuestSucessful = true;
        }
        PatronOnAdventure.reSortQuests();

    }

    public string About() //For debugging purposes
    {
        string aboutMessage =
            patronOnAdventure.Name + " is completing...\n";

        for (int i = 0; i < AdventureNodes.Count; i++)
        {
            if (AdventureNodes[i].targetQuest != null)
                aboutMessage += AdventureNodes[i].targetQuest.QuestName + " at ";
            else
                aboutMessage += "no quest at ";

            if (AdventureNodes[i].location != null)
                aboutMessage += AdventureNodes[i].location.Name + "\n";
            else
                aboutMessage += "some unknown location\n";
        }

        Debug.Log("THERE are " + AdventureNodes.Count + " Quests left");

        return aboutMessage;
    }
}
