﻿using UnityEngine;
using System.Collections;
using System.IO;

public class ItemParser  {   //IDEA and TODO, merge all loaders into some sort of parent loader class. 
    
        string path;
        string jsonString;
        JSONObject itemToReturn;
        public enum KindOfItem{DRINK,INGREDENT,EQUIPMENT};


    public ItemParser()
    {
        path = Application.dataPath + "/JsonFiles/ItemsInGame.json";
        jsonString = File.ReadAllText(path);
        itemToReturn = new JSONObject(jsonString);
    }
        

        public StoreableItem FetchItem(KindOfItem itemIndexHelper, string nameOfItem)
        {
       
        JSONObject item = itemToReturn[(int)itemIndexHelper][findItemByName(itemIndexHelper, nameOfItem)];
        StoreableItem itemToBuild;

        if (itemIndexHelper == KindOfItem.DRINK)
        { 
            itemToBuild = new Drinks(item[0].str, item[1].str, int.Parse(item[2].str), int.Parse(item[3].str), int.Parse(item[4].str), item[5].b, int.Parse(item[6].str));
        }

        else if (itemIndexHelper == KindOfItem.INGREDENT)
        {
            Debug.Log("Coming soon");
            itemToBuild = null;
        }
        
        else if (itemIndexHelper == KindOfItem.EQUIPMENT)
        {
            Debug.Log("Coming soon");
            itemToBuild = null;
        }
        else
            itemToBuild = null;

            return itemToBuild;
        }

        private int findItemByName(KindOfItem itemIndexHelper,string nameOfItem)
    {
        for (int i = 0; i < itemToReturn[(int)itemIndexHelper].Count; i++)
        {
            if (nameOfItem == itemToReturn[(int)itemIndexHelper][i][0].str)
            {
                return i;
            }
        }

        return 0;
    }
    }
