﻿using UnityEngine;
using System.Collections;

public class Drinks : StoreableItem {


    public Drinks(string ConName,string ConDesc, int ConPrice, int ConValue, float ConTimeToDrink, bool conIsAlcoholic, int ConAlcoholContent ): base(ConName,ConDesc,ConPrice,ConValue)
    {
        isAlcoholic = conIsAlcoholic;
        timeToDrink = ConTimeToDrink;
        alcoholContent = ConAlcoholContent; 
    }
    //enum modifiers ALL THE FUN MODIFIERS WE CAN THINK OF. 
    float timeToDrink;

    bool isAlcoholic;

    int alcoholContent ; // how many drinks does this count as

    public float getTimeToDrink()
    {
        return timeToDrink;
    }

    public bool getIsAlcoholic()
    {
        return isAlcoholic;
    }

    public int getAlcoholContent()
    {
        return alcoholContent;
    }

   

}
