﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class InventoryManager {

    private int gold;
    private List<StoreableItem> thePlayersInvintory;
    private ItemParser itemParser; 

    public void init()
    {
        itemParser = new ItemParser();
        thePlayersInvintory = new List<StoreableItem>();
        gold = 3000;
        addItemToInvintory(ItemParser.KindOfItem.DRINK, "StockBeer", 10);
        addItemToInvintory(ItemParser.KindOfItem.DRINK, "Juice", 10);

    }

    public void addItemToInvintory(ItemParser.KindOfItem kindOfItem, string nameOfItem)
    {
        addItemToInvintory(kindOfItem, nameOfItem, 1);
    }

    public void addItemToInvintory(ItemParser.KindOfItem kinOfItem, string nameOfItem, int numberOfItem)
    {
        bool isItemFound = false;
        foreach (StoreableItem s in thePlayersInvintory)
        {
            if( s.getname() == nameOfItem)
            {
                s.incrementNumberOfItems(numberOfItem);
                isItemFound = true;
            }
        }
        if (!isItemFound)
        {
            thePlayersInvintory.Add(itemParser.FetchItem(kinOfItem, nameOfItem));
            addItemToInvintory(kinOfItem, nameOfItem, numberOfItem);
        }
    }

    public List<StoreableItem> getPlayerInvintory()
    {
        return thePlayersInvintory;
    }

    public Drinks serveDrinkOnTap(bool isAlcholic)
    {
        foreach (Drinks d in thePlayersInvintory)
        {
            if (d.getIsAlcoholic() == isAlcholic)
            {
                d.decrementNumberOfItem();
               
                Drinks drinkToServe = d;
                if (d.getNumberLeft() == 0)
                {
                    thePlayersInvintory.Remove(d);
                }
                return drinkToServe;
            }  
        }

        Debug.Log("We're sorry, but you have no more beers");
        return null; 
    }

    public int sellItem(int itemsValue)
    {
        gold += itemsValue;
        return gold; 
    }

    public void buyItem(ItemParser.KindOfItem kinOfItem, string nameOfItem, int numberOfItem)
    {
        StoreableItem itemToBuy = itemParser.FetchItem(kinOfItem, nameOfItem);

        if (gold < itemToBuy.getPrice())
        {
            Debug.Log("Not Enough Gold");
        }
        else
        {
            pay(itemToBuy.getPrice());
            addItemToInvintory(kinOfItem, nameOfItem, numberOfItem);
        }
    }

    public int pay(int itemsCost)
    {
        gold -= itemsCost;
        return gold;
    }
    public int getGoldAmount()
    {
        return gold;
    }
}

