﻿using UnityEngine;
using System.Collections;

public class StoreableItem {

    private string Name;
    private string Description; 
    private int price;
    private int value; 


    private int numberOfThisLeft;

    Sprite apperanceOfItem; 

    public StoreableItem(string ConName, string ConDescription, int ConPrice, int Convalue)
    {
        Name = ConName;
        Description = ConDescription;
        price = ConPrice;
        value = Convalue;
    }

    public void incrementNumberOfItems()
    {
        numberOfThisLeft++;
    }

    public void incrementNumberOfItems(int numberToIncreaseBy)
    {
        numberOfThisLeft += numberToIncreaseBy;
    }

    public void decrementNumberOfItem()
    {
        numberOfThisLeft--;
    }

    public void decrementNumberOfItem(int numberToDecreaseBy)
    {
        numberOfThisLeft -= numberToDecreaseBy;
    }

    public int getPrice()
    {
        return price;
    }

    public int getValue()
    {
        return value;
    }

    public string getname()
    {
        return Name; 
    }

    public int getNumberLeft()
    {
        return numberOfThisLeft;
    }

    public string getDescription()
    {
        return Description;
    }
}
