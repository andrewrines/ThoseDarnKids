﻿using UnityEngine;
using System.Collections;

public class InvintorySlot : MonoBehaviour {

    public StoreableItem storedItem;

    public void assignStoreableItem(StoreableItem itemToHold)
    {
        storedItem = itemToHold;
    }


}
