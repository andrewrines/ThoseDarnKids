﻿//using UnityEngine;
//using System.Collections;

//public class BarManager : MonoBehaviour {

//    public PatronManager Pmanager;
//    public QuestManager Qmanager;
//    public DiologueLoader Dman;
//    public HaggleManager Hmanager;
//    public Seat[] Seats = new Seat[3];
//    private Patron[] patronAtBar = new Patron[3];
//    public float minWaitTime;
//    public float maxWaitTime;


//    // Use this for initialization
//    void Start () {
//        Dman = new DiologueLoader();
//        Pmanager.loadStarterPack();
//       // Dman.init();
//       // Dman.loadDiologue();
//       // turn();
//	}
	
//	// Update is called once per frame
//	void Update () {
//        for (int i = 0; i < patronAtBar.Length; i++)
//        {
//            if (Seats[i].checkSeats() == Seat.seatState.RESPAWNING)
//            {
//                replaceBarPeople(i);
//            }
//            if (Seats[i].checkSeats() == Seat.seatState.LEAVING)
//            {
//                clearASeat(Seats[i]);
//            }
//        }
//	}

//    public void StartDay()
//    {
//        // Throw in a command processor to process what the player wants to do,
//        // The player can, talk to Jim,
//        // Put up quests
//        // order more ingreedents 
//        // Shop for better loot
//        // Start the day
//    }

//    public void turn()
//    {
//        // A turn, here the patron manager will draw 3 patrons from the regulars deck
//        //for ( int i = 0; i < patronAtBar.Length ; i++)
//        //{
//        //    if (patronAtBar[i] == null)
//        //    {
//        //        replaceBarPeople(i);
//        //    }  
//        //}


//        // The player can talk to one of the three patrons, who will offer a greeting based on race and class ( possibly)
//        // The player can offer them a drink
//        // get information
//        // talk ( so they can go on a quest) 
//        // or ask roudy patrons to go away
//        // patrons will persist from turn to turn.
//        // after all patrons have been served ( or the player chooses) the turn will end and a new turn will start
//        // there are 3 turns in a day, noon, afternoon and night. 
//        // possibly have an after close function that will handle a score of the day's activities. 
//    }

//    private void replaceBarPeople(int personToReplace)
//    {
//        patronAtBar[personToReplace] = Pmanager.drawPatronFromRegulars();
//        patronAtBar[personToReplace].setHasInformation(Pmanager.rollForHasInformation(patronAtBar[personToReplace].sayLevel())); //does our seated patron know anything? // may need to move to patron manager or factory.
//        patronAtBar[personToReplace].setPatience(Random.Range(minWaitTime, maxWaitTime));
//        patronAtBar[personToReplace].setDrinkLimit((byte)Random.Range(2, 5)); // placeHolder, in the future I want the class and level to factor into how much our patron can have to drink
//        Seats[personToReplace].patronTakesASeat(patronAtBar[personToReplace]);
//    }

////    public string thingToSay(DiologueLoader.responceType responce, Patron selectedPatron)
////    {
////        if (responce == DiologueLoader.responceType.TALK)
////        {
////            if (selectedPatron.giveHasInformation() == true)
////            {
////                selectedPatron.setHasInformation(false);
////                Qmanager.PostToBoard(); // placeHolder, this will be put in a list of possible quests at some point once I get start of day working.
////                return Dman.lookUp(DiologueLoader.responceType.RUMOR, selectedPatron.sayClass());
////            }
////        }

////        if (responce == DiologueLoader.responceType.ADVENTURE && Qmanager.getNumberofQuests() != 0)
////        {
////            //Hmanager.openDebateMenu(Qmanager.chooseAQuestFromBoard(),selectedPatron);
////        }

////        if (responce == DiologueLoader.responceType.ACCEPT)
////        {
////            Qmanager.removeTakenQuest();
////        }

////        if (responce == DiologueLoader.responceType.DRINK)
////        {
////            if (selectedPatron.getDrinkLimit() > selectedPatron.getDrinksConsumed())
////            {
////                selectedPatron.incrementDrinksHad();
////            }
////            else
////            {
////                responce = DiologueLoader.responceType.ABOUTDRUNK;
////                selectedPatron.setIsDrunk(true);
////            }
////        }
////        return Dman.lookUp(responce, selectedPatron.sayClass());
////    }


////    public void makePatronsWait(bool arePatronsWaiting)
////    {

////        for (int i = 0; i < Seats.Length; i++)
////        {
////            Seats[i].isTimerPaused(arePatronsWaiting);
////        }

////    }

//    public void clearASeat(Seat seatToClear)
//    {
//        for (int i = 0; i < patronAtBar.Length; i++)
//        {
//            if (Seats[i] == seatToClear)
//            {
//                Pmanager.addToRegulars(patronAtBar[i]);
//                patronAtBar[i] = null;
//                Seats[i].emptySeat();
//                Seats[i].setTimer(10);
//            }
//        }
       

//    }
//}

