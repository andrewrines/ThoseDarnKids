﻿using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class QuestLoader {
    string path;
    string jsonString;
    JSONObject questToReturn;
	

    public void JsonQuestInit()
    {
        path = Application.dataPath + "/JsonFiles/QuestsInGame.json";
        jsonString = File.ReadAllText(path);
        questToReturn = new JSONObject(jsonString);
       

    }

    public Quest questCreator()
    {
        int questIndexer = Random.Range(0, questToReturn[0].Count);
        Quest questToBuild = new Quest(questToReturn[0][questIndexer][0].str, questToReturn[0][questIndexer][1].str, (int)questToReturn[0][questIndexer][4].i, questTrialCreator(questToReturn[0][questIndexer][5]));
       
        
        
       // questToBuild.assignQuestName(questToReturn[0][questIndexer][0].str);   // 0 is subject to change, based on level of adventure giving the quest
       // questToBuild.assignQuestDescript(questToReturn[0][questIndexer][1].str);
       // questToBuild.assignQuestLength(questToReturn[0][questIndexer][3].str);
        return questToBuild;
    }

    private int rollFor(int min , int max)
    {
        return Random.Range(min, max);
    }

    public struct Trial
    {
       public Patron.StatTypes challengeType;
       public byte challengeRaiting;
        // Effectors Any fun things we can add to a trial to give it more spice. 
        public Trial(Patron.StatTypes ChallengeType, byte ChallengeRaiting)
        {
            challengeType = ChallengeType;
            challengeRaiting = ChallengeRaiting;
        }
       
    }

    private Queue<Trial> questTrialCreator(JSONObject allTrials)
    {
        Queue<Trial> trialsToReturn = new Queue<Trial>();

        for (int i = 0; i < allTrials.Count; i++)
        {
            Patron.StatTypes statToCheck = determineStatType(allTrials[i][0].str);
            byte difficulty = (byte)allTrials[i][1].i;
            Trial trialToQueue = new Trial(statToCheck, difficulty);
            trialsToReturn.Enqueue(trialToQueue);
        }
        Debug.Log(trialsToReturn.Count);
        return trialsToReturn;
    }

    private Patron.StatTypes determineStatType(string statToDetermine)
    {
        if (statToDetermine == "Strong")
        {
            return Patron.StatTypes.STRONG;
        }

        if (statToDetermine == "Smart")
        {
            return Patron.StatTypes.SMART;
        }

        if (statToDetermine == "Sneak")
        {
            return Patron.StatTypes.SNEAK;
        }

        if (statToDetermine == "Sway")
        {
            return Patron.StatTypes.SWAY;
        }

        else
        {
            Debug.Log("Trial Stat FallThrough");
            return Patron.StatTypes.STRONG;
        }

        
    }
}
