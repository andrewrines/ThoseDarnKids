﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Quest : MonoBehaviour
{
    private string questGiver;
    private string questName = " ";
    private string questDescription;
    private int timeOnQuest;
    private byte sucessesOnQuest; 
    private Queue<QuestLoader.Trial> trialsOfTheQuest = new Queue<QuestLoader.Trial>();

   public Quest( string QuestName, string QuestDescription, int TimeOnQuest, Queue<QuestLoader.Trial> TrialsOfTheQuest)
    {

        questName = QuestName ;
        questDescription = QuestDescription ;
        timeOnQuest = TimeOnQuest;
        trialsOfTheQuest = TrialsOfTheQuest;
        
    } 

   public void assignQuestGiver(string giverIn)
    {
        questGiver = giverIn;
    }

    public void assignQuestName (string questIn)
    {
        questName = questIn;
    }

    public void assignQuestDescript(string discriptIn)
    {
        questDescription = discriptIn;
    }

    public string getQuestName()
    {
        return questName;
    }

    public string getQuestGiver()
    {
        return questGiver;
    }

    public string getQuestDescription()
    {
        return questDescription;
    }

    public void assignQuestLength(string questLength)
    {
        int.TryParse(questLength, out timeOnQuest);
    }

    public int getQuestLenght()
    {
        return timeOnQuest;
    }

    public QuestLoader.Trial attemptNextTrial()
    {
        return trialsOfTheQuest.Peek();
    }

    public void compleeteTrial()
    {
        trialsOfTheQuest.Dequeue();
    }

    public void assignTrials (Queue<QuestLoader.Trial> trialsToAdd)
    {
        trialsOfTheQuest = trialsToAdd;
    }

    public Queue<QuestLoader.Trial> getTrials()
    {
        return trialsOfTheQuest;
    }

    public byte getTrialsRemaining()
    {
        return (byte)trialsOfTheQuest.Count;
    }

    //public void clearAllTrials()
    //{
    //    if (trialsOfTheQuest != null)
    //    trialsOfTheQuest.Clear();
    //}

    public void debugAllTrials()
    {
        Debug.Log(trialsOfTheQuest.Count);
        foreach (QuestLoader.Trial t in trialsOfTheQuest)
        {
            Debug.Log(t.challengeType.ToString());
        }
    }
}
