﻿using UnityEngine;
using System.Collections;

public class NewBarManager : MonoBehaviour {

    public PatronManager Pmanager;
    public QuestManager Qmanager;
    public HaggleManager Hmanager;
    public Seat[] Seats = new Seat[5];
  
    public float minWaitTime;
    public float maxWaitTime;
    JsonDialogueLoader JDiologueManager;
    // DiologueLoader DiologueManager;
    public UIManager uiManager;
    public TimeOfDayManager dayManager;
    public Seat adventureChair;
    InventoryManager invintory;

    Seat highlightedSeat; 
    Seat selectedSeat;  // who are we interacting with? 
    public enum BarStates { NO_ONE, HIGHLIGHT_PATRON, SELECT_PATRON,PATRON_HAS_ORDERED,PATRONISDRINKING,QUEST_LIST, HAGGLE, CLOSED, DUCKING, POSTING}; // Added posting
    public BarStates stateOfTheBar;

    private TimeOfDayManager.TimeOfDay currentTimeOfDay;

    // Use this for initialization
      
	void Start () {
        Pmanager.loadStarterPack();
        JDiologueManager = new JsonDialogueLoader();
        JDiologueManager.JsonDialogueInit();
        Seats[Seats.Length-1] = adventureChair;
        currentTimeOfDay = TimeOfDayManager.TimeOfDay.MORNING; 
        invintory = new InventoryManager();
        invintory.init();
        uiManager.updateGold(invintory.getGoldAmount());
    }

    private void Update()
    {
        for (int i = 0; i < Seats.Length; i++)
        {
            if (Seats[i].checkSeats() == Seat.seatState.RESPAWNING)
            {
                replaceBarPeople(i);
            }
            if (Seats[i].checkSeats() == Seat.seatState.LEAVING)
            {
                if (Seats[i] == adventureChair)
                {
                    dayManager.tickTimeForward();
                    if (dayManager.getTimeOfDay() != currentTimeOfDay)
                    {
                        currentTimeOfDay = dayManager.getTimeOfDay();
                        Pmanager.progressQuests();
                        if (currentTimeOfDay == TimeOfDayManager.TimeOfDay.CLOSED)
                        {
                            closeUpShop();
                        }
                    }

                }
                clearASeat(Seats[i]);
            }
        }
    }


    private void replaceBarPeople(int personToReplace)
    {
        Seats[personToReplace].patron = Pmanager.drawPatronFromRegulars();
        Seats[personToReplace].patron.setHasInformation(Pmanager.rollForHasInformation(Seats[personToReplace].patron.sayLevel())); //does our seated patron know anything? // may need to move to patron manager or factory.
        Seats[personToReplace].patron.setPatience(Random.Range(minWaitTime, maxWaitTime));
        Seats[personToReplace].patron.setDrinkLimit();
        Seats[personToReplace].patronTakesASeat(Seats[personToReplace].patron);
    }


    public void clearASeat(Seat seatToClear)
    {
        for (int i = 0; i < Seats.Length; i++)
        {
            if (Seats[i] == seatToClear)
            {
                Pmanager.addToRegulars(Seats[i].patron);
                Seats[i].patron = null;
                Seats[i].emptySeat();
                Seats[i].setTimer(10);
            }
        }
    }

    public void openShop()
    {
        foreach (Seat s in Seats)
        {
            s.isTimerPaused(false);
        }
        dayManager.startNewDay();
        currentTimeOfDay = dayManager.getTimeOfDay();
        changeBarState(BarStates.NO_ONE);
        uiManager.changeLoadout(stateOfTheBar, new Vector3(0, 0, 0));
    }

    private void closeUpShop()
    {
        foreach (Seat s in Seats)
        {
            Pmanager.addToRegulars(s.patron);
            s.emptySeat();
            s.thisPatronsMug.hideMug(); // This
            s.isTimerPaused(true);
        }
        Qmanager.CleanUpBoardAtEndOfDay();
        changeBarState(BarStates.CLOSED);
        uiManager.changeLoadout(stateOfTheBar, new Vector3(0, 0, 0));
    }

    public void selectSeatedPatron(Seat seatToServe) // Gets a targeted seat from our input manager and sets it to our Selected Seat.
    {
        if (stateOfTheBar != BarStates.QUEST_LIST && stateOfTheBar != BarStates.HAGGLE && stateOfTheBar != BarStates.DUCKING) // HACK
        {
            highlightedSeat = seatToServe;
            uiManager.sendToNameDisplay(highlightedSeat.patron.SayName(), highlightedSeat.transform.position);
            changeBarState(BarStates.HIGHLIGHT_PATRON);
        }
    }


    public void clearPatronNametag() // if no one is selected, clear the PatronToolTip, also if an idle click is preformed, does not go back to last selected patron
    {
        uiManager.clearNameDisplay();
        if (stateOfTheBar != BarStates.QUEST_LIST && stateOfTheBar != BarStates.HAGGLE && stateOfTheBar != BarStates.CLOSED && stateOfTheBar != BarStates.DUCKING)    // HACK
            changeBarState(BarStates.NO_ONE);


    }

    public void registerIdleClick()  // sorry for the scarry name, all I want to do is open the menu when a patron is clicked on.
    {                               
        if (stateOfTheBar == BarStates.HIGHLIGHT_PATRON)
        {
            changeBarState(BarStates.SELECT_PATRON);

            selectedSeat = highlightedSeat;
            
            if(selectedSeat.patron.getIfPatronIsReturningFromAdventure())
            {
                if (selectedSeat.patron.getIfQuestIsSucessful())
                {
                    talkToPatron(JsonDialogueLoader.responceType.TRIUMPH);
                    uiManager.sendToastMessage("Mission Passed!", selectedSeat.transform.position);
                }
                else
                {
                    talkToPatron(JsonDialogueLoader.responceType.FAIL);
                    uiManager.sendToastMessage("Mission Failed!", selectedSeat.transform.position);
                }

                    selectedSeat.patron.setIfPatronReturningFromAdventure(false);
            }
            else
                talkToPatron(JsonDialogueLoader.responceType.GREET);
            // Debug.Log(selectedSeat.patron.sayAllStats() + selectedSeat.patron.SayName());
            uiManager.changeLoadout(stateOfTheBar, selectedSeat.transform.position);
            pauseSelectedSeat(); // HACK 
            if (selectedSeat == adventureChair)
            {
                uiManager.isDisplayAdventureOption(true, selectedSeat.transform.position);
            }

            if (selectedSeat.checkIfStillDrinking() == Seat.orderingState.DRINKING)
            {
                uiManager.changeLoadout(BarStates.PATRONISDRINKING, selectedSeat.transform.position);
            }
 
        }
    }

    private void pauseSelectedSeat() 
    {
        foreach (Seat s in Seats)
        {
            s.isTimerPaused(false);

            if (s == selectedSeat)
            {
                s.isTimerPaused(true);
            }
        }
    }

   

    private void changeBarState(BarStates newBarState)
    {
        stateOfTheBar = newBarState;
    }


    public void GetOrder() // Put in the option for specialized orders at some point. 
    {
        if (selectedSeat.patron.getTolerance() == Patron.drinkLevel.NONE)
            talkToPatron(JsonDialogueLoader.responceType.NONALCOHOLORDER);
        else
            talkToPatron(JsonDialogueLoader.responceType.ORDER);

        uiManager.changeLoadout(BarStates.PATRON_HAS_ORDERED, selectedSeat.transform.position);
    }

    public void serveTapDrink()
    {

            Drinks DrinkPatronIsEnjoying = invintory.serveDrinkOnTap(true);
            if (DrinkPatronIsEnjoying == null)
        {
            uiManager.sendToastMessage("Sorry, you are all out of beers", selectedSeat.transform.position);
        }
       
            if (selectedSeat.patron.getIsdrunk())
            {
                talkToPatron(JsonDialogueLoader.responceType.DRUNK);
            }
            else if (selectedSeat.patron.getDrinkLimit() >= selectedSeat.patron.getDrinksConsumed())
            {
                selectedSeat.patron.incrementDrinksHad();
                talkToPatron(JsonDialogueLoader.responceType.DRINK);
                selectedSeat.patronStartsDrinking(DrinkPatronIsEnjoying.getTimeToDrink());
                uiManager.updateGold(invintory.sellItem(DrinkPatronIsEnjoying.getValue()));
               

        }
            else
            {
                talkToPatron(JsonDialogueLoader.responceType.ABOUTDRUNK);
                selectedSeat.patron.setIsDrunk(true);
                selectedSeat.patronStartsDrinking(DrinkPatronIsEnjoying.getTimeToDrink());
                uiManager.updateGold(invintory.sellItem(DrinkPatronIsEnjoying.getValue()));
              
        }
            changeBarState(BarStates.PATRONISDRINKING);
            uiManager.changeLoadout(stateOfTheBar, selectedSeat.transform.position);

        
       


    }

    public void serveCustomDrink()
    {
        serveTapDrink();// For NOW, all this does is serve an alchaolic drink... Later their will be a menu and a similar check for drunkeness
       
       
    }

    public void serveNonAlcholicDrink()
    {
        Drinks DrinkPatronIsEnjoying = invintory.serveDrinkOnTap(false);
        if (DrinkPatronIsEnjoying == null)
        {
            uiManager.sendToastMessage("Sorry, you are all out of sodas", selectedSeat.transform.position);
        }

        talkToPatron(JsonDialogueLoader.responceType.DRINK);
            selectedSeat.patronStartsDrinking(DrinkPatronIsEnjoying.getTimeToDrink());
            uiManager.updateGold(invintory.sellItem(DrinkPatronIsEnjoying.getValue()));
           
            changeBarState(BarStates.PATRONISDRINKING);
            uiManager.changeLoadout(stateOfTheBar, selectedSeat.transform.position);

    }

    public void inquireQuestFromPatron()
    {
        if (selectedSeat.patron.giveHasInformation())
        {
            selectedSeat.patron.setHasInformation(false);
            talkToPatron(JsonDialogueLoader.responceType.RUMOR);
            Qmanager.AddRumorToQuestList();
            uiManager.sendToastMessage("Rumor added!", selectedSeat.transform.position);
            Debug.Log(Qmanager.getNumberOfQuestsInInvintory());
        }
        else
            talkToPatron(JsonDialogueLoader.responceType.TALK);

        shutOptions();
    }

    public void Haggle()
    {

        if ( Qmanager.getNumberofQuests() != 0)
        {
            pauseSelectedSeat();
            changeBarState(BarStates.HAGGLE);
            Hmanager.determineHagglePrice(selectedSeat.patron);
            selectedSeat.patron.setQuestGoneOn(Qmanager.chooseAQuestFromBoard());
            uiManager.openHaggleUI(selectedSeat.patron.getQuestGoneOn(), selectedSeat.patron); 
        }
        
    }

    public void checkTheHaggledValue()
    {
        int priceOffered = uiManager.getPlayersPrice();
        if (priceOffered >= invintory.getGoldAmount())
        {
            Debug.Log("Sorry, not enough gold");
            shutOptions();
        }
        else
        if(priceOffered >= selectedSeat.patron.getGoldThreshold())
        {
            talkToPatron(JsonDialogueLoader.responceType.ADVENTURE);
            uiManager.isHaggleUiOpen(false);
            Pmanager.sendPatronOnAdventure(selectedSeat.patron, selectedSeat.patron.getQuestGoneOn().getQuestLenght());  // ehhh
            selectedSeat.emptySeat();
            Qmanager.removeTakenQuest();
            uiManager.updateGold(invintory.pay(priceOffered));
            shutOptions();
        }
        else
        {
            talkToPatron(JsonDialogueLoader.responceType.DECLINE);
            Hmanager.negotiateNewPrice(selectedSeat.patron);
            uiManager.openHaggleUI(Qmanager.chooseAQuestFromBoard(), selectedSeat.patron);
        }
    }

    private void talkToPatron(JsonDialogueLoader.responceType responce)
    {
        uiManager.patronSays(JDiologueManager.dioOut(responce, selectedSeat.patron.sayClass()));
    }

    public void openQuestBoard() // HACK if the bar is closed, will not change the bar state but will change the loadout. I will need to refactor once I get design team something...
    {
        if (stateOfTheBar == BarStates.CLOSED)
        {
            uiManager.changeLoadout(BarStates.QUEST_LIST, new Vector3(0, 0, 0));
           // Qmanager.listQuests();
        }
        else
        {
            changeBarState(BarStates.QUEST_LIST);
            uiManager.changeLoadout(stateOfTheBar, new Vector3(0, 0, 0));
        }
        
       
        
    }

    public void getQuestDetails(byte questToinquire)
    {

            uiManager.isQuestDescriptionShowing(true);
            uiManager.openQuestDetails(Qmanager.shareABoardQuest(questToinquire), Qmanager.getQuestInInvintoryIndexer(), Qmanager.getNumberOfQuestsInInvintory());
           


    }

    public void viewQuestToPostQuestToBoard(byte questSlotToAssign)  // Find me in openQuestDetail command. 
    {
        if (Qmanager.getNumberOfQuestsInInvintory() > 0)
        {
            Qmanager.changeQuestSlotToAccess(questSlotToAssign);
            //uiManager.isQuestDescriptionShowing(true);
            uiManager.changeLoadout(BarStates.POSTING, new Vector3(0, 0, 0));
            uiManager.openQuestDetails(Qmanager.shareAnInvintoryQuest(),Qmanager.getQuestInInvintoryIndexer(), Qmanager.getNumberOfQuestsInInvintory());
            
        }
       
    }

    public void postQuestToBoard()
    {
        Qmanager.PostToBoard();
        uiManager.isQuestDescriptionShowing(false);
    }

    public void TurnQuestInvintoryPageForward()
    {
        Qmanager.incrementInvintoryQuestToShare();
        uiManager.changeLoadout(BarStates.POSTING, new Vector3(0, 0, 0));
        uiManager.openQuestDetails(Qmanager.shareAnInvintoryQuest(), Qmanager.getQuestInInvintoryIndexer(), Qmanager.getNumberOfQuestsInInvintory());
    }

    public void TurnQuestInvintoryPageBackward()
    {
        Qmanager.DecrementInvintoryQuestToShare();
        uiManager.changeLoadout(BarStates.POSTING, new Vector3(0, 0, 0));
        uiManager.openQuestDetails(Qmanager.shareAnInvintoryQuest(), Qmanager.getQuestInInvintoryIndexer(), Qmanager.getNumberOfQuestsInInvintory());
    }

    public void getItemDetails(byte itemToinquire)
    {
        uiManager.isItemDescriptionShowing(true);
        uiManager.openItemDetails(itemToinquire);
    }

    public void closeCurrentQuest()
    {
        uiManager.isQuestDescriptionShowing(false);   // HACK split this up, Item description and quest description should probably have thier own functions.
        uiManager.isItemDescriptionShowing(false);
    }

   public void shutOptions() // I will fix this to be a command und0
    {

        if (stateOfTheBar != BarStates.CLOSED)
        {
            if (selectedSeat != null)
            {
                selectedSeat.isTimerPaused(false);
            }
            changeBarState(BarStates.NO_ONE);
        }
        uiManager.changeLoadout(stateOfTheBar, this.transform.position);
       

    }


    public void purchaseStockBeer()
    {
        invintory.buyItem(ItemParser.KindOfItem.DRINK, "StockBeer", 1);
        uiManager.updateGold(invintory.getGoldAmount());
       
    }

    public void purchaseStockSoda()
    {
        invintory.buyItem(ItemParser.KindOfItem.DRINK, "Juice", 1);
        uiManager.updateGold(invintory.getGoldAmount());
    }

    public void panDownAndCheckInvintory()
    {
        uiManager.showInvintory(invintory.getPlayerInvintory());
        changeBarState(BarStates.DUCKING);
        uiManager.changeLoadout(NewBarManager.BarStates.DUCKING, new Vector3(0, 0, 0));
    }

    public void standUp()
    {
        uiManager.hideInvintory();
        shutOptions();
    }

    public void ReadItem(InvintorySlot itemToRead)
    {
        uiManager.sendToNameDisplay(itemToRead.storedItem.getname(), itemToRead.transform.position);
    }

    //private void areAllSeatsEnabled(bool isActive)
    //{
    //    foreach(Seat s in Seats)
    //    {
    //        s.GetComponent<BoxCollider2D>().enabled = isActive;
    //    }
    //}

}
