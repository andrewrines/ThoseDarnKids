﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class UIManager : MonoBehaviour {


    public float drinkButtonOffsetX;
    public float drinkButtonOffsetY;

    public float adventureButtonOffsetX;
    public float adventureButtonOffsetY;

    public float talkButtonOffsetX;
    public float talkButtonOffsetY;

    public float nameTagOffsetX;
    public float nameTagOffsetY;

    public float backButtonOffsetX;
    public float backButtonOffsetY;

    public float textTimer;
    private float textCountDown;

    [SerializeField]
    GameObject background;

    [SerializeField]
    GameObject bar;

    [SerializeField]
    Text patronsNameDisplay;  // later to be replaced with a fold out picture thing. 

    [SerializeField]
    Text toastText;
    private float desiredToastHight = Screen.height * .75f;
    public float howFastIsToast;
    private float toastCountDown;
    private bool isToastSent;
    public float howLongDoesToastLast;

    [SerializeField]
    Text PatronSaysThis;

    [SerializeField]
    Button adventureButton;
    [SerializeField]
    Button inquireButton;
    [SerializeField]
    Button backButton;
    [SerializeField]
    Button panLeft;
    [SerializeField]
    Button panRight;
    [SerializeField]
    Button panDown;
    [SerializeField]
    Button StandUp;
    [SerializeField]
    Button talkButton;

    [SerializeField]
    Button postButton;
    [SerializeField]
    Button nextQuestButton;
    [SerializeField]
    Button previousQuestButton;
    

    [SerializeField]
    Button serveTap;
    [SerializeField]
    Button serveCustom;
    [SerializeField]
    Button serveNonAlcoholic;

    [SerializeField]
    GameObject questBoard;

    [SerializeField]
    GameObject questPage;

    [SerializeField]
    Text QuestTitle;

    [SerializeField]
    Text QuestDescription;
    [SerializeField]
    Text QuestPageNumber;

    [SerializeField]
    GameObject itemPage;

    [SerializeField]
    Text itemDescription;

    [SerializeField]
    GameObject HagglePannel;

    [SerializeField]
    Text HaggleQuestName;

    [SerializeField]
    Text HaggleQuestDescription;

    [SerializeField]
    Text patronsHaggle;

    [SerializeField]
    GameObject HaggleField;

    [SerializeField]
    GameObject EndOfDayPannel;

    [SerializeField]
    Text Gold;
     // The below to be moved to some sort of apperance manager at some point. 
    public Sprite placeHolderDrinkIcon;

    public Sprite placeHolderIngredentIcon;

    public Sprite placeHolderWeaponIcon;

    public Sprite placeHolderNone;
    //End


    private Button[] controls; // contains Drink,Adventure, talk, and back options. 
    private Button[] drinkChoices;
    private Button[] panControls;
    private Button[] talkControls;
    private Button[] duckButtons;
    private Button[] postQuestsButtons;

    public GameObject[] itemsUnderBar;
   

    private void Start()
    {
        initButtonArray();
        isToastSent = false;
       // setDefaultValues();
    }

    private void Update()
    {
        if (isToastSent)
        {
            toastText.transform.position = Vector3.Lerp(toastText.transform.position, new Vector3(toastText.transform.position.x, desiredToastHight, toastText.transform.position.z), howFastIsToast);
            checkIfToastIsOver();
        }
        

        if (textCountDown <= 0)
        {
            hideText();
        }
      else
        decrementTimer();
    }

    private void initButtonArray()
    {
        controls = new Button[3];
        controls[0] = backButton;
        controls[1] = inquireButton;
        controls[2] = adventureButton;

        drinkChoices = new Button[4];
        drinkChoices[0] = backButton;
        drinkChoices[1] = serveCustom;
        drinkChoices[2] = serveNonAlcoholic;
        drinkChoices[3] = serveTap;

        panControls = new Button[3];
        panControls[0] = panLeft;
        panControls[1] = panRight;
        panControls[2] = panDown;

        talkControls = new Button[3];
        talkControls[0] = backButton;
        talkControls[1] = talkButton;
        talkControls[2] = adventureButton;

        duckButtons = new Button[1];
        duckButtons[0] = StandUp;

        postQuestsButtons = new Button[3];
        postQuestsButtons[0] = postButton;
        postQuestsButtons[1] = previousQuestButton;
        postQuestsButtons[2] = nextQuestButton;

        //itemsUnderBar = new GameObject[8];
    }


 


    public void sendToNameDisplay(string patronName, Vector3 SeatsLocation)
    {
        patronsNameDisplay.text = patronName;
        patronsNameDisplay.transform.position =  RectTransformUtility.WorldToScreenPoint(Camera.main ,new Vector3 (SeatsLocation.x+ nameTagOffsetX, SeatsLocation.y + nameTagOffsetY , SeatsLocation.z));
    }

    public void patronSays(string thingForThePatronToSay)
    {
        PatronSaysThis.text = thingForThePatronToSay;
        setDioTimer();
    }


    public void clearNameDisplay()
    {
        patronsNameDisplay.text = " ";
    }

    public void sendToastMessage(string notificationToToast, Vector3 SeatsLocation)
    {
        toastText.transform.position = RectTransformUtility.WorldToScreenPoint(Camera.main, new Vector3(SeatsLocation.x , SeatsLocation.y , SeatsLocation.z)); 
        toastText.text = notificationToToast;
        setToastTimer();
        isToastSent = true;
    }

    private void checkIfToastIsOver()
    {
        toastCountDown -= Time.deltaTime;
        if (toastCountDown <= 0)
        {
            toastText.text = " ";
            isToastSent = false;
        }
        
    }

    public void changeLoadout(NewBarManager.BarStates stateToSwapTo, Vector3 SeatsLocation)
    {
        shutOptions();
        if (stateToSwapTo == NewBarManager.BarStates.NO_ONE)
        {
            activateControlScheme(panControls);
        }
        if (stateToSwapTo == NewBarManager.BarStates.SELECT_PATRON)
        {
            Camera.main.GetComponent<CameraManager>().ZoomIn(SeatsLocation);
            activateControlScheme(controls);
            controls[0].transform.position =  new Vector3(SeatsLocation.x + backButtonOffsetX, SeatsLocation.y + backButtonOffsetY);
            controls[1].transform.position = new Vector3(SeatsLocation.x + talkButtonOffsetX, SeatsLocation.y + talkButtonOffsetY);
            controls[2].gameObject.SetActive(false);
        }

       else if (stateToSwapTo == NewBarManager.BarStates.PATRON_HAS_ORDERED)
        {
            Camera.main.GetComponent<CameraManager>().ZoomIn(SeatsLocation);
            activateControlScheme(drinkChoices);
            drinkChoices[0].transform.position = new Vector3(SeatsLocation.x + backButtonOffsetX, SeatsLocation.y + backButtonOffsetY);
            drinkChoices[1].transform.position = new Vector3(SeatsLocation.x + talkButtonOffsetX, SeatsLocation.y + talkButtonOffsetY);
            drinkChoices[2].transform.position = new Vector3(SeatsLocation.x + drinkButtonOffsetX, SeatsLocation.y + drinkButtonOffsetY);
            drinkChoices[3].transform.position = new Vector3(SeatsLocation.x + adventureButtonOffsetX, SeatsLocation.y + adventureButtonOffsetY);
        }

       else if (stateToSwapTo == NewBarManager.BarStates.PATRONISDRINKING)
        {
            Camera.main.GetComponent<CameraManager>().ZoomIn(SeatsLocation);
            activateControlScheme(talkControls);
            talkControls[0].transform.position = new Vector3(SeatsLocation.x + backButtonOffsetX, SeatsLocation.y + backButtonOffsetY);
            talkControls[1].transform.position = new Vector3(SeatsLocation.x + talkButtonOffsetX, SeatsLocation.y + talkButtonOffsetY);
            talkControls[2].gameObject.SetActive(false);
        }

       else if (stateToSwapTo == NewBarManager.BarStates.QUEST_LIST)
        {
            isQuestBoardOpen(true);
        }

        else if (stateToSwapTo == NewBarManager.BarStates.DUCKING)
        {
            activateControlScheme(duckButtons);
        }

        else if (stateToSwapTo == NewBarManager.BarStates.CLOSED)
        {
            isEndOfDayPannelOpen(true);
        }

        else if (stateToSwapTo == NewBarManager.BarStates.POSTING)
        {
            isQuestBoardOpen(true);
            isQuestDescriptionShowing(true);
            QuestPageNumber.gameObject.SetActive(true);
            activateControlScheme(postQuestsButtons);
        }
    }

    public void isDisplayAdventureOption(bool isOptionDisplayed, Vector3 seatsPosition)
    {
        controls[2].gameObject.SetActive(isOptionDisplayed);
        controls[2].transform.position = new Vector3(seatsPosition.x + adventureButtonOffsetX, seatsPosition.y + adventureButtonOffsetY);
    }

    public void isQuestDescriptionShowing(bool openClose)
    {
        questPage.SetActive(openClose);
    }

    public void isQuestBoardOpen(bool openClose)
    {
        questBoard.SetActive(openClose);
    }


    public void openQuestDetails(Quest questToInquire , int IndexingPageOn, int totalQuestsInInvintory)
    {
        QuestTitle.text = questToInquire.getQuestName();
        QuestDescription.text = questToInquire.getQuestDescription();
        QuestPageNumber.text = "Page " + (IndexingPageOn+1) + " / " + totalQuestsInInvintory;
    }

    public void isItemDescriptionShowing(bool yesNo)
    {
        itemPage.SetActive(yesNo);
    }


    public void openItemDetails(byte itemToInquire)
    {
        itemDescription.text = itemsUnderBar[itemToInquire].GetComponent<InvintorySlot>().storedItem.getname() +
            "\n" + itemsUnderBar[itemToInquire].GetComponent<InvintorySlot>().storedItem.getDescription() +
            "\n  SOLD FOR:" + itemsUnderBar[itemToInquire].GetComponent<InvintorySlot>().storedItem.getValue() +
            "\n COST:" + itemsUnderBar[itemToInquire].GetComponent<InvintorySlot>().storedItem.getPrice();
    }



    public void openHaggleUI(Quest questToparse , Patron haggler)
    {
        isHaggleUiOpen(true);
        HaggleQuestName.text = questToparse.getQuestName();
        HaggleQuestDescription.text = questToparse.getQuestDescription();
        patronsHaggle.text = "I'll pay " + haggler.getmaximumGoldWanted(); // Debug This is default stuff, later I wanna replace this with unique haggle diolouge. 
    }

    public void isHaggleUiOpen(bool yesNo)
    {
        HagglePannel.SetActive(yesNo);
    }

    public int getPlayersPrice()
    {
        return Convert.ToInt16(HaggleField.GetComponent<InputField>().text);
    }

    public void isEndOfDayPannelOpen(bool yesNo)
    {
        EndOfDayPannel.SetActive(yesNo);
        bar.SetActive(!yesNo);
        background.SetActive(!yesNo);
    }

    public void updateGold(int goldAmnt)
    {
        Gold.text = "Gold:" + goldAmnt.ToString();
    }

    public void showInvintory(List<StoreableItem> itemsInplayersInvintory)
    {
        for (int i = 0; i < itemsUnderBar.Length; i++)
        {
            itemsUnderBar[i].gameObject.SetActive(true);
            if (i >= itemsInplayersInvintory.Count)
            {
                itemsUnderBar[i].GetComponentInChildren<Text>().text = "None";
                itemsUnderBar[i].GetComponent<Image>().sprite = placeHolderNone;
                continue;
            }
            else
            {
                itemsUnderBar[i].GetComponent<InvintorySlot>().storedItem = itemsInplayersInvintory[i];
                //Camera.main.ScreenToWorldPoint(itemsUnderBar[i].transform.position);
                if (itemsUnderBar[i].GetComponent<InvintorySlot>().storedItem is Drinks)
                { 
                  itemsUnderBar[i].gameObject.GetComponent<Image>().sprite = placeHolderDrinkIcon;
                }

                itemsUnderBar[i].GetComponentInChildren<Text>().text = itemsUnderBar[i].GetComponent<InvintorySlot>().storedItem.getNumberLeft().ToString();

                
            }
        }
    }

   

   

    public void hideInvintory()
    {
        foreach(GameObject g in itemsUnderBar)
        {
            g.gameObject.SetActive(false);
        }
    }


    //////Tool////////

    private string formatText(string textToFormat)  // TODO give public accessTo designer to change how many characters before cut off. 
    {
        System.Text.StringBuilder strBuilder = new System.Text.StringBuilder(textToFormat);
        int i = 0;
        for (int j = 0; j < textToFormat.Length; j++)
        {
            if (i >= 25 && strBuilder[j] == ' ')
            {
                strBuilder[j] = '\n';
                i = 0;
            }
            i++;
        }
        textToFormat = strBuilder.ToString();
        return textToFormat;
    }

    private void activateControlScheme(Button[] arrayToActivate)
    {
        for (int i = 0; i < arrayToActivate.Length ; i++) 
        {
            arrayToActivate[i].gameObject.SetActive(true);
        }
       
    }

    public void shutOptions()  // The future plan is to again refactor this into a proper command pattern with an undo. I just want to get everything working again before attempting this. 
    {
        foreach(Button b in controls)
        {
            b.gameObject.SetActive(false);
        }

        foreach (Button b in drinkChoices)
        {
            b.gameObject.SetActive(false);
        }

        foreach (Button b in panControls)
        {
            b.gameObject.SetActive(false);
        }

        foreach(Button b in talkControls)
        {
            b.gameObject.SetActive(false);
        }

        foreach(Button b in duckButtons)
        {
            b.gameObject.SetActive(false);
        }

        foreach(Button b in postQuestsButtons)
        {
            b.gameObject.SetActive(false);
        }

       //isDisplayAdventureOption(false, this.transform.position);

       isQuestBoardOpen(false);

       isHaggleUiOpen(false);

        isEndOfDayPannelOpen(false);

        QuestPageNumber.gameObject.SetActive(false);  // This might need a better home

        Camera.main.GetComponent<CameraManager>().ZoomOut();
    }

    // timer

    private void setDioTimer()
    {
        textCountDown = textTimer;
    }

    private void decrementTimer()
    {
        textCountDown -= Time.deltaTime;
    }


    private void hideText()
    {
        PatronSaysThis.text = " ";
    }

    private void setToastTimer()
    {
        toastCountDown = howLongDoesToastLast; 
    }
}


