﻿using UnityEngine;
using System.Collections;

public class Back : CommandWithUndo
{


    public Back() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.shutOptions();
        }
        base.Execute(Bar);
    }
}

