﻿using UnityEngine;
using System.Collections;

public class checkHaggleValue : CommandWithUndo
{


    public checkHaggleValue() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            // target.talkToPatron(DiologueLoader.responceType.TALK);
            //target.serveDrink();
            target.checkTheHaggledValue();
        }
        base.Execute(Bar);
    }
}
