﻿using UnityEngine;
using System.Collections;

public class openQuestDetail : CommandWithUndo
{
    private byte questSlot;

    public openQuestDetail(byte QuestToinquire) : base()
    {
        questSlot = QuestToinquire;
    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            if (target.stateOfTheBar != NewBarManager.BarStates.CLOSED)
            {
                target.getQuestDetails(questSlot);
            }

            else

                target.viewQuestToPostQuestToBoard(questSlot);
        }
        base.Execute(Bar);
    }
}


