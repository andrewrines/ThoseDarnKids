﻿using UnityEngine;
using System.Collections;

public class OpenItemDescriptionPage : CommandWithUndo
{
    private byte itemToinquire;

    public OpenItemDescriptionPage(byte ItemToinquire) : base()
    {
        itemToinquire = ItemToinquire;
    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.getItemDetails(itemToinquire);
        }
        base.Execute(Bar);
    }
}
