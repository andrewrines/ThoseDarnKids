﻿using UnityEngine;
using System.Collections;

public class CloseQuest : CommandWithUndo
{


    public CloseQuest() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {



        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.closeCurrentQuest();
        }
        base.Execute(Bar);
    }
}
