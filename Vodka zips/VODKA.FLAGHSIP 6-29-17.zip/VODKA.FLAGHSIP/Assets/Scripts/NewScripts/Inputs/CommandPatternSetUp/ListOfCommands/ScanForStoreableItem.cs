﻿using UnityEngine;
using System.Collections;

public class ScanForStoreableItem : CommandWithUndo
{

    InvintorySlot invintoryItem;
    public ScanForStoreableItem(InvintorySlot scannedItem) : base()
    {
        invintoryItem = scannedItem;
    }

    public override void Execute(NewBarManager Bar)
    {



        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.ReadItem(invintoryItem);
        }
        base.Execute(Bar);
    }
}
