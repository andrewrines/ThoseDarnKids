﻿using UnityEngine;
using System.Collections;

public class askForTheDrinkTheyWant : CommandWithUndo
{


    public askForTheDrinkTheyWant() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.GetOrder();
        }
        base.Execute(Bar);
    }
}
