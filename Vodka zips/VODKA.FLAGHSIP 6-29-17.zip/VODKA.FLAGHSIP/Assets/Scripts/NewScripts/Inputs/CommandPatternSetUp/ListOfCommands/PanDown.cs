﻿using UnityEngine;
using System.Collections;

public class PanDown : CommandWithUndo
{


    public PanDown() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.panDownAndCheckInvintory();
        }
        base.Execute(Bar);
        Camera.main.GetComponent<CameraManager>().panDown();
    }
}
