﻿using UnityEngine;
using System.Collections;

public class BuySoda : CommandWithUndo
{


    public BuySoda() : base()
    {

}

public override void Execute(NewBarManager Bar)
{

    var target = Bar.GetComponent<NewBarManager>();
    if (target is NewBarManager)
    {
        target.purchaseStockSoda();
    }
    base.Execute(Bar);
}
}
