﻿using UnityEngine;
using System.Collections;

public class StandBackUp :CommandWithUndo
{


    public StandBackUp() : base()
    {

}

public override void Execute(NewBarManager Bar)
{
        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.standUp();
        }

        Camera.main.GetComponent<CameraManager>().setBackToNormal();
    }
}
