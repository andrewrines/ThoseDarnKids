﻿using UnityEngine;
using System.Collections;

public class BuyBeer : CommandWithUndo
{


    public BuyBeer() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.purchaseStockBeer();
        }
        base.Execute(Bar);
    }
}

