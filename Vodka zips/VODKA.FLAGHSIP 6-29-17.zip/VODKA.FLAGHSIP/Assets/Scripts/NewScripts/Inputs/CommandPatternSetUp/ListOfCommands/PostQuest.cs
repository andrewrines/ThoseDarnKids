﻿using UnityEngine;
using System.Collections;

public class PostQuest : CommandWithUndo
{


    public PostQuest() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.postQuestToBoard();
        }
        base.Execute(Bar);
    }
}
