﻿using UnityEngine;
using System.Collections;

public class Adventure : CommandWithUndo
{


    public Adventure() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.Haggle();
        }
        base.Execute(Bar);
    }
}