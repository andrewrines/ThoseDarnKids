﻿using UnityEngine;
using System.Collections;

public class PanRight : CommandWithUndo
{


    public PanRight() : base()
    {

    }

    public override void Execute(NewBarManager Bar)
    {

        //    var target = Bar.GetComponent<NewBarManager>();
        //    if (target is NewBarManager)
        //    {
        //        target.talkToPatron(DiologueLoader.responceType.TALK);
        //        target.serveDrink();
        //        target.inquireQuestFromPatron();
        //    }
        //    base.Execute(Bar);
        //}
        Camera.main.GetComponent<CameraManager>().panRight();
    }
}
