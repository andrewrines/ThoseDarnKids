﻿using UnityEngine;
using System.Collections;

public class ScanForPatron : CommandWithUndo
{

    Seat seatedPatron;
    public ScanForPatron(Seat SeatedPatron) : base()
    {
        seatedPatron = SeatedPatron;
    }

    public override void Execute(NewBarManager Bar)
    {


       
        var target = Bar.GetComponent<NewBarManager>();
        if (target is NewBarManager)
        {
            target.selectSeatedPatron(seatedPatron);
        }
        base.Execute(Bar);
    }
}
