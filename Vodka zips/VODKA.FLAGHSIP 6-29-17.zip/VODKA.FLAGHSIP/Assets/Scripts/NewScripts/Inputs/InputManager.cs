﻿using UnityEngine;
using System.Collections;
public class InputManager : MonoBehaviour {

    CommandWithUndo command;

    public NewBarManager barManager;


    // Update is called once per frame
    void Update()
    {
        command = null; 
        ScanForPatron();        // sees if we mouse over a patron
        scanForIdleClicks();    // checks to see if our click is targeting something, if a patron, then it opens the menu, if not targeting, closes the menu
  }

    private void ScanForPatron() // not too sure about this. 
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.z = 5f;

        Vector2 v = Camera.main.ScreenToWorldPoint(mousePosition);

        Collider2D[] col = Physics2D.OverlapPointAll(v);
       

        if (col.Length > 0)
        {
            foreach (Collider2D c in col)
            {
                if (c.GetComponent<Seat>() != null)
                {
                    command = new ScanForPatron(c.GetComponent<Seat>());
                    ActivateCommand(command);
                }

              else if (c.GetComponent<InvintorySlot>() != null)
                {
                    command = new ScanForStoreableItem(c.GetComponent<InvintorySlot>());
                    ActivateCommand(command);
                }

            }
        }
        else
        {
            command = new NoOneHighlighted();
            ActivateCommand(command);
        }
    }

    private void scanForIdleClicks()
    {
        if (Input.GetMouseButtonDown(0))
        {
            command = new ScanForIdleClicks();
            ActivateCommand(command);
        }
    }

    public void tapDrinkButtonClicked()
    {
        command = new TapDrink();
        ActivateCommand(command);
    }

    public void customDrinkButtonClicked()
    {
        command = new CustomDrink();
        ActivateCommand(command);
    }

    public void nonAlcoholicDrinkClicked()
    {
        command = new NonAlcoholicDrink();
        ActivateCommand(command);
    }

    public void askWhatTheyWant()
    {
        command = new askForTheDrinkTheyWant();
        ActivateCommand(command);
    }

    public void talkButtonClicked()
    {
        command = new Talk();
        ActivateCommand(command);
    }

    public void adventureButtonClicked()
    {
        command = new Adventure();
        ActivateCommand(command);
    }

    public void stopTalkingButtonClicked()
    {
        command = new StopTalking();
        ActivateCommand(command);
    }

    public void questButtonClicked()
    {
        command = new openQuestBoard();
        ActivateCommand(command);
    }

    public void backButtonClicked()
    {
        command = new Back();
        ActivateCommand(command);
    }

    public void questButton1Clicked()
    {
        command = new openQuestDetail(0);
        ActivateCommand(command);
    }

    public void questButton2Clicked()
    {
        command = new openQuestDetail(1);
        ActivateCommand(command);
    }

    public void questButton3Clicked()
    {
        command = new openQuestDetail(2);
        ActivateCommand(command);
    }

    public void questButton4Clicked()
    {
        command = new openQuestDetail(3);
       ActivateCommand(command);
    }

    public void questButton5Clicked()
    {
        command = new openQuestDetail(4);
        ActivateCommand(command);
    }



    public void invintory1Clicked()
    {
        command = new OpenItemDescriptionPage(0);
            ActivateCommand(command);
    }

    public void invintory2Clicked()
    {
        command = new OpenItemDescriptionPage(1);
        ActivateCommand(command);
    }
    public void invintory3Clicked()
    {
        command = new OpenItemDescriptionPage(2);
        ActivateCommand(command);
    }
    public void invintory4Clicked()
    {
        command = new OpenItemDescriptionPage(3);
        ActivateCommand(command);
    }
    public void invintory5Clicked()
    {
        command = new OpenItemDescriptionPage(4);
        ActivateCommand(command);
    }
    public void invintory6Clicked()
    {
        command = new OpenItemDescriptionPage(5);
        ActivateCommand(command);
    }
    public void invintory7Clicked()
    {
        command = new OpenItemDescriptionPage(6);
        ActivateCommand(command);
    }
    public void invintory8Clicked()
    {
        command = new OpenItemDescriptionPage(7);
        ActivateCommand(command);
    }



    public void closeSelectedQuest() // In the future, possibly use the command pattern for what it actually is supposed to do and have a command like this undo one step for all , back buttons. 
    {
        command = new CloseQuest();
        ActivateCommand(command);
    }

    public void panLeft()
    {
        command = new PanLeft();
        ActivateCommand(command);
    }

    public void panRight()
    {
        command = new PanRight();
        ActivateCommand(command);
    }

    public void panDonw()
    {
        command = new PanDown();
        ActivateCommand(command);
    }

    public void standBackUp()
    {
        command = new StandBackUp();
        ActivateCommand(command);
    }

    

    //public void closeHaggle()
    //{
    //    command = new CloseHaggle();
    //    ActivateCommand(command);
    //}

    public void enterHaggleValue()
    {
        command = new checkHaggleValue();
        ActivateCommand(command);
    }

    public void startNextDay()
    {
        command = new StartNextDay();
        ActivateCommand(command);
    }

    public void buyStockBeer()
    {
        command = new BuyBeer();
        ActivateCommand(command);
    }

    public void buyStockSoda()
    {
        command = new BuySoda();
        ActivateCommand(command);
    }

    public void postQuest()
    {
        command = new PostQuest();
        ActivateCommand(command);
    }

    public void indexPreviousQuestInInvintory()
    {
        command = new GoBackInQuestInvintory();
        ActivateCommand(command);
    }

    public void indexNextQuestInInvintory()
    {
        command = new GoForwardInQuestInvintory();
        ActivateCommand(command);
    }



    private void ActivateCommand(Command command)
    {
        command.Execute(barManager);
    }


}
