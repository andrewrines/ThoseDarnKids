﻿using UnityEngine;
using System.Collections;

public class Mug : MonoBehaviour {
    private SpriteRenderer patronsMug;
    private float ammountToDecreaseAlphaBy;
    private Color fullMugValue;
    private bool isPaused;

    private void Start()
    {
        
        patronsMug = this.GetComponent<SpriteRenderer>();
        fullMugValue = patronsMug.color; 
        hideMug();
    }
    public void showMug(float drinksDesity)
    {
        patronsMug.gameObject.SetActive(true);
        ammountToDecreaseAlphaBy = drinksDesity;
        patronsMug.color = fullMugValue; 
    }

    private void Update()
    {
        if (!isPaused)
        {
            patronsMug.color -= new Color(0, 0, 0, fullMugValue.a / ammountToDecreaseAlphaBy) * Time.deltaTime;
        }
    }

    public void hideMug()
    {
        if (patronsMug != null)
        patronsMug.gameObject.SetActive(false);
    }

    public void isMugPaused(bool yesNo)
    {
        isPaused = yesNo;
    }
}
