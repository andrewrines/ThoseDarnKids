﻿using UnityEngine;
using System.Collections;

public class TimeOfDayManager : MonoBehaviour {
    public Sprite MorningBackdrop;
    public Sprite NoonBackdrop;
    public Sprite NightBackdrop;
    public GameObject backDrop;
    public enum TimeOfDay { MORNING,NOON,NIGHT, CLOSED}; // CLOSED Is for the management protion of the game, a time to order drinks and post quests to the board;
    TimeOfDay currentTimeOfDay;
    private int adventurersInLine;
    private int dayNumber;

    private void Start()
    {
        startNewDay();
    }

    public void tickTimeForward()
    {
        adventurersInLine--; 
        if (adventurersInLine == 0)
        {
            currentTimeOfDay++;
            Debug.Log(currentTimeOfDay);
            changeBackdrop();
            rollForAdventures();
        }
    }

    public TimeOfDay getTimeOfDay()
    {
        return currentTimeOfDay;
    }

    private void rollForAdventures()
    {
        if (currentTimeOfDay == TimeOfDay.MORNING)
        {
            adventurersInLine = Random.Range(2, 4);
        }

        if (currentTimeOfDay == TimeOfDay.NOON)
        {
            adventurersInLine = Random.Range(3, 5);
        }

        if (currentTimeOfDay == TimeOfDay.NIGHT)
        {
            adventurersInLine = Random.Range(3, 5);
        }

    }

    private void changeBackdrop()
    {
        if (currentTimeOfDay == TimeOfDay.MORNING)
        {
            backDrop.GetComponent<SpriteRenderer>().sprite = MorningBackdrop;
        }

        if (currentTimeOfDay == TimeOfDay.NOON)
        {
            backDrop.GetComponent<SpriteRenderer>().sprite = NoonBackdrop;
        }

        if (currentTimeOfDay == TimeOfDay.NIGHT)
        {
            backDrop.GetComponent<SpriteRenderer>().sprite = NightBackdrop;
        }
    }

    public void startFirstDay()
    {
        dayNumber++;
        currentTimeOfDay = TimeOfDay.CLOSED;  
        Debug.Log("Day:" + dayNumber);
        //changeBackdrop();
        //rollForAdventures();
    }

    public void startNewDay()
    {
        dayNumber++;
        currentTimeOfDay = TimeOfDay.MORNING;  // morning  Swaped For debug 6/20/17
        Debug.Log("Day:" + dayNumber);
        changeBackdrop();
        rollForAdventures();
        //Roll for holiday or other town event; 
    }
}
