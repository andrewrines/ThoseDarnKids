﻿using UnityEngine;
using System.Collections;
using System.IO;

public class JsonDialogueLoader {
    public enum responceType {GREET,TALK, RUMOR, DRINK, ABOUTDRUNK, DRUNK, ADVENTURE, DECLINE, ACCEPT, EXIT, ORDER, SPECIALORDER, NONALCOHOLORDER , TRIUMPH, FAIL};
    //{ GREET, TALK, ADVENTURE, DECLINE, DRINK, ACCEPT, RUMOR, EXIT, DRUNK, ABOUTDRUNK };
    string path;
    string jsonString;
    JSONObject dioToReturn;
    
    
 public void JsonDialogueInit()
    {
        path = Application.dataPath + "/JsonFiles/Dialog.json";
        jsonString = File.ReadAllText(path);
        dioToReturn = new JSONObject(jsonString);
    }

    public string dioOut(responceType type, Patron.type patronsJob)
    {
        // Debug.Log(jsonString);
        string dioToSend = dioToReturn[(int)type][(int)patronsJob][Random.Range(0,dioToReturn[(int)type][(int)patronsJob].Count)].str; // possibly the worst? Ill see if I can optimize this at some point. Kinda a mess to read too.
        return dioToSend;
        //Debug.Log();
        //Debug.Log(dioToReturn.ResponceType.Length);
    }
}


