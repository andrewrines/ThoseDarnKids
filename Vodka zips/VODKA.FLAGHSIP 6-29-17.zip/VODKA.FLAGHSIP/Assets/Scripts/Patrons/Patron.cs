﻿using UnityEngine;
using System.Collections;

public class Patron : MonoBehaviour
{
    public enum type { WARRIOR = 0, ROUGE, WIZARD, BARD };
    public enum Aligence { COLLEGE, CORPOREAL, AA, EVIL, MAFIA, DAREDEVIL, ARCHAEOLOGICAL, NATURE, NEIGHBORHOOD, BREWMASTER, NONE };
    public enum drinkLevel { NONE, LOW, MID, HIGH };
    public enum StatTypes {STRONG,SMART,SNEAK,SWAY}
    private string name;
    private byte level; 
    public type disciplineType { get;  set; }
    public Aligence thisPatronsAligence { get; set; }
    public drinkLevel thisPatronsTolerance;
    private byte[] patronsStats;

    private bool hasInformation = false;
    private bool isDrunk = false; 

    private byte drinkLimit;
    private byte drinksConsumed; 

    private int goldThreshold;
    private int maximumGoldWanted;
    private float patience;
    private int timeLeftOnAdventure; // I dont know if we need this anymore.
    private Quest questGoneOn;
    private bool isQuestSuccessful; // Change this to enum later on when we figgure stuff out
    private bool isPatronReturningFromAdventure;

    public Patron(string newName,byte newLevel, Aligence newPatronsAligence ,type newType,  drinkLevel newDrinkLevel, byte[] newStats)
    {
        name = newName;
        level = newLevel;
        disciplineType = newType;
        thisPatronsAligence = newPatronsAligence;
        thisPatronsTolerance = newDrinkLevel;
        patronsStats = newStats;
        isPatronReturningFromAdventure = false; 
    }

    public string SayName()
    {
        return name;
    }

    public byte sayLevel()
    {
        return level;
    }

    public Aligence sayAligence()
    {
        return thisPatronsAligence;
    }

    public type sayClass()
    {
        return disciplineType;
    }
    
    public void setHasInformation(bool informed)
    {
        hasInformation = informed;
    }

    public bool giveHasInformation()
    {
        return hasInformation; 
    }

    public void changeThreshold(int moneyNeeded)
    {
        goldThreshold = moneyNeeded;
    }

    public int getGoldThreshold()
    {
        return goldThreshold;
    }

    public void changeMaximumGoldWanted(int moneyWanted)
    {
        maximumGoldWanted = moneyWanted;
    } 

    public int getmaximumGoldWanted()
    {
        return maximumGoldWanted;
    }

    public void setPatience(float PatienceIn)
    {
        patience = PatienceIn;
    }
    public float getPatience()
    {
        return patience;
    }

    public byte getDrinkLimit()
    {
        return drinkLimit;
    }

    public drinkLevel getTolerance()
    {
        return thisPatronsTolerance;
    }

    public void setDrinkLimit()
    {
        if (thisPatronsTolerance == drinkLevel.NONE)
        {
            drinkLimit = 0;
        }

        if (thisPatronsTolerance == drinkLevel.LOW)
        {
            drinkLimit = (byte)Random.Range(1, 2);
        }

        if (thisPatronsTolerance == drinkLevel.MID)
        {
            drinkLimit = (byte)Random.Range(2, 4);
        }
        if (thisPatronsTolerance == drinkLevel.HIGH)
        {
            drinkLimit = (byte)Random.Range(3, 5);
        }
    }

    public void incrementDrinksHad() // possibly in the future, a drink may count as two drinks???
    {
        drinksConsumed++;
    }

    public void resetDrinksHad()
    {
        drinksConsumed = 0; 
    }

    public byte getDrinksConsumed()
    {
        return drinksConsumed;
    }

    public bool getIsdrunk()
    {
        return isDrunk;
    }

    public void setIsDrunk(bool areTheyDrunk)
    {
        isDrunk = areTheyDrunk;
    }

    public bool getIfPatronIsReturningFromAdventure()
    {
        return isPatronReturningFromAdventure;
    }

    public void setIfPatronReturningFromAdventure(bool areTheyReturningFromAdventure)
    {
        isPatronReturningFromAdventure = areTheyReturningFromAdventure;
    }

    public void setTimeOnAdventure(int howLongisThisAdventure)
    {
        timeLeftOnAdventure = howLongisThisAdventure;
    }

    public void decrementTimeOnAdventure()
    {
        timeLeftOnAdventure--;
    }

    public bool isDoneWithAdventure()
    {
        if (timeLeftOnAdventure > 0)
            return false;

        else
            return true;
        
    }

    public bool getIfQuestIsSucessful()
    {
        return isQuestSuccessful;
    }

    public void setQuestGoneOn(Quest questToGoOn)
    {
        questGoneOn = questToGoOn;
    }

    public Quest getQuestGoneOn()
    {
        return questGoneOn;
    }

    public void attemptStatCheck()
    {
        if (!isQuestSuccessful)
        {
            QuestLoader.Trial trialToAttempt = questGoneOn.attemptNextTrial();
            if (trialToAttempt.challengeRaiting <= patronsStats[(int)trialToAttempt.challengeType] + RollFor(1, 6)) // Gets patron stat and rolls a D6 no plan for catstrophic failure yet. 
            {
                questGoneOn.compleeteTrial();
                checkIfQuestIsOver();
            }
        }
    }

    public void checkIfQuestIsOver()
    {
        if (questGoneOn.getTrialsRemaining() == 0)
        {
            isQuestSuccessful = true;
        }

        else
            isQuestSuccessful = false;
    }

    public byte getStat (StatTypes typeToGet)
    {
        return patronsStats[(byte)typeToGet];
    }

    public string sayStat (StatTypes typeToGet)
    {
        return typeToGet.ToString() + ":" + patronsStats[(byte)typeToGet];
    }

    public string sayAllStats()
    {
        string AllStatsInAString = " ";
       
        for (StatTypes stat = 0; stat <= StatTypes.SWAY ; stat++)
        {
            AllStatsInAString += stat + ":" + patronsStats[(byte)stat] + "\n";
        }

        return AllStatsInAString;
                
    }

    private int RollFor(int min, int max)
    {
        return Random.Range(min, max);
    }
}
