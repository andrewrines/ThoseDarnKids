﻿using UnityEngine;
using System.Collections;

public class Seat : MonoBehaviour { // ArmSTRONG family style programming

    public ApperanceManager aM;
    public Patron patron;
    public Mug thisPatronsMug;
    public enum seatState{EMPTY,FULL, RESPAWNING, LEAVING};
    public enum orderingState {WAITING,ORDERING,DRINKING };
    public seatState thisSeatIs;
    public orderingState drinkState;
    private float countDown;
    private float drinkCountDown;
    private bool isTimeHalted; //HACK
    private bool isPatronDrinking;
    // Use this for initialization
    void start () { 
        thisSeatIs = seatState.RESPAWNING;
        drinkState = orderingState.WAITING;
        isTimeHalted = false;
        isPatronDrinking = false;
	}

    private void Update()
    {
        if (!isPatronDrinking)
        {
            if (thisSeatIs == seatState.EMPTY || thisSeatIs == seatState.FULL) // if this causes problems, seperate.
                decrementSeatTimer();
        }

        else
        {
            decrementDrinkTimer();
        }

        //if (thisSeatIs == seatState.FULL) // remove this if problems.
        //    decrementSeatTimer();

    }

    public void patronTakesASeat(Patron seatedPatron)
    {
        this.gameObject.GetComponent<BoxCollider2D>().enabled = true;
        this.thisSeatIs = seatState.FULL;
        patron = seatedPatron;
        this.gameObject.GetComponent<SpriteRenderer>().sprite = aM.HowTheyLook(patron.sayClass());
        setTimer(patron.getPatience());
    }

    public void setTimer(float setTime)
    {
        countDown = setTime;
    }

    public void patronStartsDrinking(float drinksDensity)
    {
        isPatronDrinking = true;
        drinkCountDown = drinksDensity;
        drinkState = orderingState.DRINKING;
        thisPatronsMug.showMug(drinksDensity);
    }

    public void emptySeat()
    {
        this.GetComponent<BoxCollider2D>().enabled = false;
        this.GetComponent<SpriteRenderer>().sprite = null;
        this.patron = null;
        this.thisSeatIs = seatState.EMPTY;
    }

    public seatState checkSeats()
    {
        return this.thisSeatIs;
    }

    public orderingState checkIfStillDrinking()
    {
        return this.drinkState;
    }

    private void decrementDrinkTimer()
    {
        if (!isTimeHalted)
        {
            if (drinkCountDown > 0)
            {
                drinkCountDown -= Time.deltaTime;
            }
            else
            {
                isPatronDrinking = false;
                drinkState = orderingState.WAITING;
                thisPatronsMug.hideMug();
                Debug.Log("End of drink Hit");
            }
        }
    }

    private void decrementSeatTimer()
    {
        if (!isTimeHalted) // HACK
        {
            if (countDown > 0)
            {
                countDown -= Time.deltaTime;
            }
            else if (thisSeatIs == seatState.EMPTY)
            {
                thisSeatIs = seatState.RESPAWNING;
            }
            else if (thisSeatIs == seatState.FULL)
            {
                thisSeatIs = seatState.LEAVING;
            }
        } 
   }

    public void isTimerPaused(bool yesNo)
    {
        isTimeHalted = yesNo;
        thisPatronsMug.isMugPaused(yesNo);
    }

}
