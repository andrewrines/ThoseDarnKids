﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class QuestManager : MonoBehaviour
{

     
    private Quest questHaggledOver; 
    private byte questToRemove;
    private byte questSlotToAccess;
    private int indexingNumberOfInvintoryQuestToShare;
   [SerializeField] Button[] questButtons = new Button[5];
    [SerializeField] List<Quest> questInvintory;
    private List<byte> spacesOccupied;
    private List<Quest> questsOnTheBoard;
    [SerializeField] Text descriptionText;
    private QuestLoader ql;
    //[SerializeField] Transform parent;

   

	void Start ()
    {
        ql = new QuestLoader();
        ql.JsonQuestInit();
       
        questToRemove = 0;
        indexingNumberOfInvintoryQuestToShare = 0;
        spacesOccupied = new List<byte>();
        questsOnTheBoard = new List<Quest>();
        
        //PostToBoard();
    }

    public void PostToBoard()  // Ill need to clean this up onece I get it working.
    {
        Debug.Log(questInvintory.Count);
        if (questButtons[questSlotToAccess].GetComponent<Quest>().getQuestName() != " " && questInvintory.Count > 0)
        {
            foreach (Quest q in questsOnTheBoard)
            {
                if (q.getQuestName() == questButtons[questSlotToAccess].GetComponent<Quest>().getQuestName())
                {
                    questInvintory.Add(q);
                    break;
                }
            }
            questToRemove = questSlotToAccess;
            removeTakenQuest();
        }


        Quest theQuestOnTheButton = questButtons[questSlotToAccess].GetComponent<Quest>();
        theQuestOnTheButton.assignQuestName(questInvintory[indexingNumberOfInvintoryQuestToShare].getQuestName());
        theQuestOnTheButton.assignQuestGiver(questInvintory[indexingNumberOfInvintoryQuestToShare].getQuestGiver());
        theQuestOnTheButton.assignQuestDescript(questInvintory[indexingNumberOfInvintoryQuestToShare].getQuestDescription());
        theQuestOnTheButton.assignTrials(questInvintory[indexingNumberOfInvintoryQuestToShare].getTrials());
        questButtons[questSlotToAccess].GetComponentInChildren<Text>().text = theQuestOnTheButton.getQuestName();
        spacesOccupied.Add(questSlotToAccess);
        questsOnTheBoard.Add(questInvintory[indexingNumberOfInvintoryQuestToShare]);
       // questList[0];
        questInvintory.RemoveAt(indexingNumberOfInvintoryQuestToShare);
        indexingNumberOfInvintoryQuestToShare = 0;
        //numberOfQuestsOnBoard++;
        //shiftQuestsOnBoard();
        
        //if (numberOfQuestsOnBoard < questButtons.Length)
        //{
        //   parent = transform;
        //    questsOnBoard[numberOfQuestsOnBoard] = ql.questCreator();
        //    numberOfQuestsOnBoard++;
        //    shiftQuestsOnBoard();
        //}
        //else
           
        
    }

    public void AddRumorToQuestList()
    {
        questInvintory.Add(ql.questCreator());
    }

    public Quest chooseAQuestFromBoard()
    {
        if (questToRemove == 0)
        {
            questToRemove = spacesOccupied[Random.Range(0, spacesOccupied.Count)];
            questHaggledOver = questButtons[questToRemove].GetComponent<Quest>();

        }
        return questHaggledOver;
    }

    public int getNumberOfQuestsInInvintory()
    {
        return questInvintory.Count;
    }

    public int getQuestInInvintoryIndexer()
    {
        return indexingNumberOfInvintoryQuestToShare;
    }


   public int getNumberofQuests()
    {
        return spacesOccupied.Count;
    }

    public void removeTakenQuest()
    {


        for (int i = 0; i < questsOnTheBoard.Count; i++)
        {
            if (questsOnTheBoard[i].getQuestName() == questButtons[questToRemove].GetComponent<Quest>().getQuestName())
            {
                questsOnTheBoard.RemoveAt(i);
                break;
            }
        }

        questButtons[questToRemove].GetComponentInChildren<Text>().text = " ";
        questButtons[questToRemove].GetComponent<Quest>().assignQuestName(" ");
        questButtons[questToRemove].GetComponent<Quest>().assignQuestDescript(" ");
        questButtons[questToRemove].GetComponent<Quest>().assignQuestGiver(" ");
       // questButtons[questToRemove].GetComponent<Quest>().clearAllTrials();
        spacesOccupied.Remove(questToRemove);
        questToRemove = 0;

    }

  

    //public void listQuests()
    //{
    //    foreach (Quest q in questInvintory)
    //    {
    //        Debug.Log(q.getQuestName());
    //    }
    //}

    

    public void CleanUpBoardAtEndOfDay()
    {
        spacesOccupied.Clear();
        foreach (Button b in questButtons)
        { 
        b.GetComponentInChildren<Text>().text = " ";
        b.GetComponent<Quest>().assignQuestName(" ");
         b.GetComponent<Quest>().assignQuestDescript(" ");
        b.GetComponent<Quest>().assignQuestGiver(" ");
            //b.GetComponent<Quest>().clearAllTrials();
        }
        
        foreach (Quest q in questsOnTheBoard)
        {
            questInvintory.Add(q);
           
        }
        questsOnTheBoard.Clear();
       

    }

    public Quest shareAnInvintoryQuest()
    {
        return questInvintory[indexingNumberOfInvintoryQuestToShare]; 
    }

    public Quest shareABoardQuest(byte numberToInquire)
    {
        return questButtons[numberToInquire].GetComponent<Quest>();
    }

    public void changeQuestSlotToAccess(byte QuestSlotToAcess)
    {
        questSlotToAccess = QuestSlotToAcess;
    }

    public void incrementInvintoryQuestToShare()
    {
        if (indexingNumberOfInvintoryQuestToShare < questInvintory.Count -1)
        indexingNumberOfInvintoryQuestToShare++;
        else
        {
            indexingNumberOfInvintoryQuestToShare = 0;
        }

        
    }

    public void DecrementInvintoryQuestToShare()
    {
        if (indexingNumberOfInvintoryQuestToShare > 0)
            indexingNumberOfInvintoryQuestToShare--;
        
            else
        {
            indexingNumberOfInvintoryQuestToShare = questInvintory.Count -1;
        }

       Debug.Log(indexingNumberOfInvintoryQuestToShare);
    }
}


