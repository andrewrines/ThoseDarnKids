﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class HaggleManager : MonoBehaviour {

    private void Start()
    {
        
    }


    //public void debate( Patron personGoingOnQuest) 
    //{
    //    determineHagglePrice(personGoingOnQuest);
    //   // uiManager.openHaggleUI(incomingQuest.getQuestName(), incomingQuest.getQuestDescription());
    //}

     public void determineHagglePrice(Patron personGoingOnQuest)// helper function for math
    {
        int price = RollFor(500, 1000);  //TODO, give each quest a level 0-6;after i get this working. 
        price += (RollFor(0, 200) * personGoingOnQuest.sayLevel());
        Debug.Log("Gold" + price);
        // fun Ideas for Bards and theives charging more.
        personGoingOnQuest.changeThreshold(price);
        personGoingOnQuest.changeMaximumGoldWanted(hiBallPrice(price));
    }

    private int hiBallPrice(int desiredPrice)
    {
        desiredPrice += RollFor(0, 250);
        return desiredPrice;
    }

    public void negotiateNewPrice(Patron personGoingOnQuest)
    {
        int newPrice = RollFor(0, 250);
       personGoingOnQuest.changeThreshold(personGoingOnQuest.getGoldThreshold() + newPrice);
        personGoingOnQuest.changeMaximumGoldWanted(personGoingOnQuest.getmaximumGoldWanted() + newPrice + hiBallPrice(0));
    }


    private int RollFor(int min, int max) // should throw this in a util... DREAMS
    {
        return Random.Range(min, max + 1);
    }

  
}
