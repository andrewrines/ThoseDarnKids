﻿//using UnityEngine;
//using System.Collections;
//using UnityEngine.UI;

//public class MixingColors : MonoBehaviour {

//    Color[] colorsBasedOnIngredent = new Color[6];
//    public Color Red;
//    public Color Orange;
//    public Color Yellow;
//    public Color Green;
//    public Color Blue;
//    public Color Purple;
//    Image thisImage;
//    Color colorToCraft;

//    public void Awake()
//    {
//        colorsBasedOnIngredent[0] = Red;
//        colorsBasedOnIngredent[1] = Orange;
//        colorsBasedOnIngredent[2] = Yellow;
//        colorsBasedOnIngredent[3] = Green;
//        colorsBasedOnIngredent[4] = Blue;
//        colorsBasedOnIngredent[5] = Purple;
//        thisImage = this.gameObject.GetComponent<Image>();
//    }

//    public void addColor(byte colorToAdd)
//    {

//        colorToCraft += new Color(colorsBasedOnIngredent[colorToAdd].r, colorsBasedOnIngredent[colorToAdd].g, colorsBasedOnIngredent[colorToAdd].b);
        
//        thisImage.color = new
//        Debug.Log(thisImage.color);
//    }
//}
