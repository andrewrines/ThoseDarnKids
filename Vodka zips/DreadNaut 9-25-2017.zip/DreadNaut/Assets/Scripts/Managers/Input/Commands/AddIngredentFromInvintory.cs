﻿using UnityEngine;
using System.Collections;

public class AddIngredentFromInvintory : CommandWithUndo
{

    byte slotToFind;
    
    public AddIngredentFromInvintory(byte invintorySlot) : base()
    {
        slotToFind = invintorySlot;
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.MakeDrink(slotToFind);
        }
        base.Execute(Bar);
    }
}
