﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Location : MonoBehaviour
{
    [SerializeField] List<LocationAndRoad> locations;
    List<Quest> questsAtLocation = new List<Quest>();

    public enum LocationIdentifier { TERABITHIA, MIDDLE_EARTH, HOGWARTS, HYRULE, HALFBLOOD, NARNIA, SHIRE, MOOMIN_VALLEY, WONDERLAND, LABYRINTH, DINOTOPIA }
    [SerializeField] LocationIdentifier NameOfLocation;

    public int QuestCountAtLocation { get { return questsAtLocation.Count; } }  //NOTE: Slot 0 should always be reserved for "no quest."  There should be one more slot than there are quests at this location
    public string Name { get { return NameOfLocation.ToString(); } }

    //List<Patron> patronsAtLocation = new List<Patron>();

    [System.Serializable]
    struct LocationAndRoad //workaround: Unity cannot display dictionaries to the editor
    {
        public Location location;   //should probably be called "ConnectedLocations", but I'm afraid of having to drag everything back in again.
        public Road roadConnection;
    }


    public bool IsAdjacentToLocation(Location desiredLocation)
    {
        for (int i = 0; i < locations.Count; i++)
        {
            if (locations[i].location == desiredLocation)
                return true;
        }

        return false;
    }

    public void AddNewQuestToThisLocation(Quest questToAdd)
    {
        questsAtLocation.Add(questToAdd);
    }

    //public Quest findQuestAtThisLocationByName(string desiredQuestName)
    //{
    //    for (int i = 0; i < questsAtLocation.Count; i++)
    //    {
    //        if (questsAtLocation[i].QuestName == desiredQuestName)
    //            return questsAtLocation[i];
    //    }

    //    return null;
    //}

    public Quest findQuestAtThisLocationByIndex(int desiredQuestIndex)
    {
        try
        {
            return questsAtLocation[desiredQuestIndex];
        }
        catch
        {
            Debug.Log("The Quest at index " + desiredQuestIndex + " could not be found at location " + this + " (Index out of range)");
            return null;
        }
    }

    public Road FindRoadConnectedBetweenLocations(Location otherLocation)
    {
        for (int i = 0; i < locations.Count; i++)
        {
            if (locations[i].location == otherLocation)
                return locations[i].roadConnection;
        }

        return null;
    }
}
