﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapManager : MonoBehaviour //This doesn't have to be a Monobehaviour.  Update code to improve this!
{
    enum MapState { INACTIVE, CONVERTING_RUMOR_TO_QUEST, SETTING_ADVENTURE_LOCATION, CHOOSING_QUEST }
    MapState currentMapState = MapState.INACTIVE;

    [SerializeField] Location startingLocation; //the location of the bar (every patron will start off here)
    [SerializeField] List<LocationAndKey> allLocations;

    [SerializeField] QuestInfoPanel questInfoPanel;
    [SerializeField] Color colorWhenSelectedForAdventure;
    [SerializeField] Color colorWhenNotSelectedForAdventure;
    [SerializeField] RectTransform MapImage;

    private List<Patron> idleAdventurers = new List<Patron>();  // Added NC 9/24
    public List<Patron> IdleAdventurers { get { return idleAdventurers; } }


    Location currentLocation = null;

    [System.Serializable]
    struct LocationAndKey
    {
        public Location location;
        public Location.LocationIdentifier key;
    }

    List<Adventure> allCurrentAdventures = new List<Adventure>();   //A list of all currently active adventures
    Adventure AdventureUnderConstruction;

    /// <summary>
    /// Sets a quest to a location by name of the quest.  The quest's name must match the name given in the inspector!
    /// </summary>
    /// <param name="targetQuest"></param>
    /// <returns>Returns true if the quest was added to the location successfully</returns>
    //public bool SetQuestToLocation(Quest targetQuest)
    //{
    //    for (int i = 0; i < allLocations.Count; i++)
    //    {
    //        if (allLocations[i].key == targetQuest.QuestLocation)
    //        {
    //            allLocations[i].location.AddNewQuestToThisLocation(targetQuest);
    //            return true;
    //        }
    //    }

    //    Debug.Log("The quest '" + targetQuest.QuestName + "' could not find location '" + targetQuest.QuestLocation + "'");
    //    return false;
    //}

    public void CreateNewAdventure(Patron patronOnAdventure)    //THIS IS CALLED FROM OUTSIDE THE MAP SYSTEM.  This should start the chain of events needed to construct an adventure.
    {
        currentLocation = startingLocation;
        MapImage.gameObject.SetActive(true);
        if (AdventureUnderConstruction != null) { AdventureUnderConstruction.ClearAdventure(); } //wipe the temporary adventure, just to be safe
        AdventureUnderConstruction = new Adventure(patronOnAdventure, startingLocation, colorWhenSelectedForAdventure, colorWhenNotSelectedForAdventure);

        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;

      
    }

    public bool SetQuestToLocation(Quest targetQuest)
    {
        for (int i = 0; i < allLocations.Count; i++)
        {
            if (allLocations[i].key.ToString() == targetQuest.QuestLocation)
            {
                allLocations[i].location.AddNewQuestToThisLocation(targetQuest);
                return true;
            }
        }

        Debug.Log("The quest '" + targetQuest.QuestName + "' could not find location '" + targetQuest.QuestLocation + "'");
        return false;
    }

    public void AdvanceAllPatronsOnAdventures()
    {
        for (int i = 0; i < allCurrentAdventures.Count; i++) 
        {
            //move the patron
            allCurrentAdventures[i].advanceToNextLocation(); //a.advanceToNextLocation();
            // sends our patron back when adventure is done // NC 9/24
            if (allCurrentAdventures[i].isAdventureOver)
            {
                idleAdventurers.Add(allCurrentAdventures[i].PatronOnAdventure);
                allCurrentAdventures[i].PatronOnAdventure.currentActivity = Patron.whatDoTheyWantToDo.TURNIN;
                allCurrentAdventures.RemoveAt(i);
                i--;
            }
           
            //attempt the quest
        }
    }


    public void AddLocationToAdventure(Location clickedLocation)    //Called when the player clicks on a location- the button on the quest info panel (while creating an adventure)
    {
        if (currentLocation.IsAdjacentToLocation(clickedLocation) && !AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation) && currentMapState != MapState.CHOOSING_QUEST)
        {
            Road r = currentLocation.FindRoadConnectedBetweenLocations(clickedLocation);

            currentLocation = clickedLocation;

            AdventureUnderConstruction.SetNodeLocation(clickedLocation, r);
            ShowQuestInfoPanel();
            currentMapState = MapState.CHOOSING_QUEST;
        }
        else if (AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation))
        {
            AdventureUnderConstruction.RemoveAllNodesPastGivenNodeLocation(clickedLocation);
            currentLocation = clickedLocation;
        }

        //When the player clicks 'Add Location', the panel closes and the player can click on another location
    }

    public void AddQuestToAdventure() //Called when the player clicks the "Choose quest" add quest button (while creating an adventure)
    {
        AdventureUnderConstruction.SetNodeQuest(questInfoPanel.GetQuestFromLocation());
        AdventureUnderConstruction.ConfirmNewNode();
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        questInfoPanel.HideSelf();
    }

    public void FinishBuildingAdventure()   //Called when the player clicks the "Confirm Adventure" button (while creating an adventure)
    {
        allCurrentAdventures.Add(AdventureUnderConstruction);

       // AdventureUnderConstruction.ClearAdventure(); // checking
        // Debug.Log(AdventureUnderConstruction.About());
        //AdventureUnderConstruction.ClearAdventure();    //This may not be needed since the "CreateNewAdventure" takes care of this
        //MapImage.gameObject.SetActive(false);
        //questInfoPanel.gameObject.SetActive(false);
    }

    public void closeAdventureMap()   //Called when the player clicks the "Cancel Adventure" button (while creating an adventure)
    {
      //AdventureUnderConstruction.ClearAdventure();    //This may not be needed since the "CreateNewAdventure" takes care of this
        MapImage.gameObject.SetActive(false);
        questInfoPanel.gameObject.SetActive(false);
    }
    

    public void ShowQuestInfoPanel()
    {
        questInfoPanel.gameObject.SetActive(true);
        questInfoPanel.InitializeQuestInfoPanel(currentLocation);
    }


    public void clearAllIdleAdventurers() // NC added 9/24
    {
        idleAdventurers.Clear();
    }

    

    //public void HideQuestInfoPanel()
    //{
    //    questInfoPanel.HideSelf();
    //}



    //public void AddQuestToAdventure(UnityEngine.UI.Text questName) //Called when the player clicks the "Add quest" add quest button (while creating an adventure)
    //{
    //    AdventureUnderConstruction.SetNodeQuest(
    //        currentLocation.findQuestAtThisLocationByName(questName.text)   //Set the adventure node's quest equal to the quest indicated by the button's name
    //        );
    //}





    /* NOTE:
     * I feel like I should use the state pattern?
     *      -> When the player clicks on a location, they should ONLY be able to interact with the "select a quest at this location" panel
     */

}
