﻿using UnityEngine;
using System.Collections;

public class FillableMug : MonoBehaviour {

    // this class will be used for all the mix master magic that goes one with the bar. 
    Drink drinkInMug = new Drink();
    public Drink DrinkInMug {get{ return drinkInMug; } }

	
}
