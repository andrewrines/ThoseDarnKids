﻿using UnityEngine;
using System.Collections;

public class CloseBattleReport : CommandWithUndo
{



    public CloseBattleReport() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.turnPageInBattleReport();
        }
        base.Execute(Bar);
    }
}
