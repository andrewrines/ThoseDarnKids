﻿using UnityEngine;
using System.Collections;

public class ScanForPatron : CommandWithUndo
{

    Seat seatedPatron;
    public ScanForPatron(Seat SeatedPatron) : base()
    {
        seatedPatron = SeatedPatron;
    }

    public override void Execute(BarManager Bar)
    {

        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.MouseOverPatron(seatedPatron);
        }
        base.Execute(Bar);
    }
}
