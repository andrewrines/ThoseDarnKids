﻿using UnityEngine;
using System.Collections;

public class SwitchToShopScreen : CommandWithUndo
{



    public SwitchToShopScreen() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.FlipToShopPage();
        }
        base.Execute(Bar);
    }
}
