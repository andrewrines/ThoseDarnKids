﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EndOfDayManager : MonoBehaviour {

    public GameObject endOfDayScreen;
    public GameObject menuBoard; // this will be the list of names and things that travels between pages.
    public GameObject endStateSelector;
    private List<Patron> allPatronsTheBartenderKnows = new List<Patron>();
    public List<Patron> AllPatronsTheBartenderKnows {get { return allPatronsTheBartenderKnows; } set { allPatronsTheBartenderKnows = value; } }

    private List<Rumor> rumorsKnownAbout = new List<Rumor>();
    public List<Rumor> RumorsKnownAbout { get { return rumorsKnownAbout; } } // set { rumorsKnownAbout = value; } }

    public WarRoomState warRoomState;
    public PatronScreenOpened patronState;
    public ShopState shopState;


    IEndOfDayStates patronScreenOpened;
    IEndOfDayStates warRoomScreenOpened;
    IEndOfDayStates shopScreenOpened;

    IEndOfDayStates currentManagementState;


    public void Start()
    {
        patronScreenOpened = patronState;
        warRoomScreenOpened = warRoomState;
        shopScreenOpened = shopState;
    }

    public void addRumor(Rumor rumorToAdd)
    {
        rumorsKnownAbout.Add(rumorToAdd);
    }

    public void pullUpEndOfDayScreen()
    {
        endOfDayScreen.SetActive(true);
        menuBoard.SetActive(true);
        endStateSelector.SetActive(true);
        currentManagementState = patronScreenOpened;
        currentManagementState.ShowPresetAssets();
    }

 

    public void setManagerState(IEndOfDayStates newEndOfDayState)
    {
        currentManagementState = newEndOfDayState;
    }

    public void ShowPresetAssets()
    {
        currentManagementState.ShowPresetAssets();
    }
    #region CommandPatternHooks
    public void FlipToPatronPage()
    {
        currentManagementState.PatronMenuOpen();
    }


    public void FlipToRumorPage()
    {
        currentManagementState.RumorMenuOpen();
    }

    public void FlipToShopPage()
    {
        currentManagementState.StoreMenuOpen();
    }

    public void ScrollUp()
    {
        currentManagementState.ScrollUp();
    }

    public void ScrollDown()
    {
        currentManagementState.ScrollDown();
    }

    public void ShowStatsOnPage(byte index)
    {
       currentManagementState.ShowStatsOnPage(index);
    }

    public void ShowQuestOnPage(Quest quest)
    {
        currentManagementState.ShowQuestOnPage(quest); 
    }

    public void AddQuestToMap() 
    {
       currentManagementState.AddQuestToMap();
    }

    public void BackOutOfQuestRumor()
    {
        currentManagementState.BackOutOfQuestRumor();
    }

    public void turnPageLeftInQuestAtLocation()
    {
        currentManagementState.turnPageLeftInQuestAtLocation();
    }

    public void turnPageRightInQuestAtLocation()
    {
        currentManagementState.turnPageRightInQuestAtLocation();
    }

    #endregion

    public void closeEndOfDayScreen()
    {
        if (currentManagementState != null)
        {
            currentManagementState.HidePresetAssets();
            endOfDayScreen.SetActive(false);
            menuBoard.SetActive(false);
            endStateSelector.SetActive(false);
        }
    }


    public IEndOfDayStates openPatronScreen()
    {
        return patronScreenOpened;
    }


    public IEndOfDayStates openRumorScreen()
    {
        return warRoomScreenOpened;
    }

    public IEndOfDayStates openShopScreen()
    {
        return shopScreenOpened;
    }

    public void passTimeForQuests()
    {
        warRoomState.updateActiveQuests(); // HAAAAAACK The trouble is that i am calling this directly, I would rather this class have the list of all active quests BUT their is no way to remove the flags at the location that way... After toy and game fair. 
    }

    public void sendBackTimeOutQuestWithCrier(Quest timedOutQuest)
    {

        for (int i = 0; i < allPatronsTheBartenderKnows.Count; i++)
        {
            if (!allPatronsTheBartenderKnows[i].IsOnQuest)
            {
                allPatronsTheBartenderKnows[i].QuestsToCompleete.Add(timedOutQuest);
                allPatronsTheBartenderKnows[i].currentActivity = Patron.whatDoTheyWantToDo.TURNIN;
                break;
            }
        }
    }


}
