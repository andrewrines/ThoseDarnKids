﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InvintorySlot : MonoBehaviour {

   // public ApperanceManager apperanceManger;
    private Ingredent itemToDisplay;
    
    Text numberOfItemsRemaining;

  

    public Ingredent getItemToDisplay()
    {
        return itemToDisplay;
    }

    public void setItemToDisplay(Ingredent ItemNeeded)
    {
        itemToDisplay = ItemNeeded; 
    }

    public void ShowNumberRemaining()
    {
        numberOfItemsRemaining = gameObject.GetComponentInChildren<Text>();
        numberOfItemsRemaining.text = itemToDisplay.NumberLeft.ToString();
    }

    public void ShowWhatThisIngredentLooksLike()
    {
        // no longer needed as we have taps to show that;
       // this.gameObject.GetComponent<Image>().sprite = itemToDisplay.displayArt();//ApperanceManager.instance.whatDoesTheIngredentLookLike(itemToDisplay.ThisIngredentsColor);//apperanceManger.whatDoesTheIngredentLookLike(itemToDisplay.ThisIngredentsColor);
    }


    

   



   
        
    
}
