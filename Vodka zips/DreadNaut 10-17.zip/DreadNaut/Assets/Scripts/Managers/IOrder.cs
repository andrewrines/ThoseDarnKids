﻿using UnityEngine;
using System.Collections;
using System;

public interface IOrder {

    string describeOrder();
    bool checkAccuracy(Drink drinkToCheck);
}

public class OrderByName : IOrder
{
    private Drink drinkDesired;

    public OrderByName(Drink DrinkDesired)
    {
        drinkDesired = DrinkDesired;
    }

    public bool checkAccuracy(Drink drinkToCheck)
    {
       for (int i = 0; i < drinkToCheck.DrinkIngredents.Length; i++)
        {
            if (drinkToCheck.DrinkIngredents[i] != drinkDesired.DrinkIngredents[i])
                return false;
        }
        return true;
    }

    public string describeOrder()
    {
        return " a " + drinkDesired.DrinkName;
    }
}

public class OrderByFlavor : IOrder
{
    Drink.flavor desiredFlavor;
    
    public OrderByFlavor(Drink.flavor DesiredFlavor)
    {
        desiredFlavor = DesiredFlavor;
    }

    public bool checkAccuracy(Drink drinkToCheck)
    {
        return (drinkToCheck.ThisDrinksFlavor == desiredFlavor);
    }

    public string describeOrder()
    {
        return " a " + desiredFlavor.ToString() + " drink";
    }

    
}

public class OrderByIngredent : IOrder
{
    Ingredent.ingredentColor ingredentToInclude;
    
    public OrderByIngredent()
    {
        ingredentToInclude = (Ingredent.ingredentColor)UnityEngine.Random.Range((int)Ingredent.ingredentColor.RED, (int)Ingredent.ingredentColor.LENGTH);
    }

    public bool checkAccuracy(Drink drinkToCheck)
    {
        return (drinkToCheck.DrinkIngredents[(int)ingredentToInclude] != 0);
    }

    public string describeOrder()
    {
        return " a drink that has " + ingredentToInclude; 
    }
}

public class OrderByLackOfIngredent : IOrder
{
    Ingredent.ingredentColor ingredentToAvoid;

    public OrderByLackOfIngredent()
    {
        ingredentToAvoid = (Ingredent.ingredentColor)UnityEngine.Random.Range((int)Ingredent.ingredentColor.RED, (int)Ingredent.ingredentColor.LENGTH);
    }

    public bool checkAccuracy(Drink drinkToCheck)
    {
        return (drinkToCheck.DrinkIngredents[(int)ingredentToAvoid] == 0);
    }

    public string describeOrder()
    {
        return " a drink without " + ingredentToAvoid;
    }
}