﻿using UnityEngine;
using System.Collections;

public class OpenQuestChoiceFromRumor : CommandWithUndo // Trial to see if we can remove this later 10/11 we may be able to as we do node checks to find quests
{

    //byte slotToFind;

    //public OpenQuestChoiceFromRumor(byte invintorySlot) : base()
    //{
    //    slotToFind = invintorySlot;
    //}

    //public override void Execute(BarManager Bar)
    //{
    //    var target = Bar.GetComponent<BarManager>();
    //    if (target is BarManager)
    //    {
    //        target.endOfDayManagement.ShowQuestOnPage(slotToFind);
    //    }
    //    base.Execute(Bar);
    //}
}
