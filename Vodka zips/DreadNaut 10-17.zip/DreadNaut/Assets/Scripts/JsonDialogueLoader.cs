﻿using UnityEngine;
using System.Collections;
using System.IO;

public class JsonDialogueLoader {

    private static JsonDialogueLoader instance = null;
    private static readonly object padloc = new object();

    public enum responceType {GREET,TALK, RUMOR, DRINK, ABOUTDRUNK, DRUNK, ADVENTURE, DECLINE, ACCEPT, EXIT, ORDER, SPECIALORDER, NONALCOHOLORDER , TRIUMPH, FAIL};
    //{ GREET, TALK, ADVENTURE, DECLINE, DRINK, ACCEPT, RUMOR, EXIT, DRUNK, ABOUTDRUNK };
    string path;
    string jsonString;
    JSONObject dioToReturn;


    public static JsonDialogueLoader Instance
    {
        get
        {
            lock (padloc)
            {

                if (instance == null)
                {
                    instance = new JsonDialogueLoader();
                    instance.JsonDialogueInit();

                }
                return instance;
            }
        }
    }




    public void JsonDialogueInit()
    {
        path = Application.streamingAssetsPath + "/JsonFiles/Dialog.json";
        jsonString = File.ReadAllText(path);
        dioToReturn = new JSONObject(jsonString);
    }

    public string dioOut(responceType type, Patron.disposition patronsDisposition)
    {
        // Debug.Log(jsonString);
        string dioToSend = dioToReturn[(int)type][(int)patronsDisposition][Random.Range(0,dioToReturn[(int)type][(int)patronsDisposition].Count)].str; // possibly the worst? Ill see if I can optimize this at some point. Kinda a mess to read too.
        return dioToSend;
        //Debug.Log();
        //Debug.Log(dioToReturn.ResponceType.Length);
    }
}


