﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;
using System.Collections.Generic;

public class WarRoomState : MonoBehaviour, IMapStates ,IEndOfDayStates
{
    public MapManager mapManager;
    public EndOfDayManager endOfDayManager;
    public Button[] buttonsWithRumorsOnThem = new Button[6];
    
    public Image[] rewardSlots = new Image[5];
    public Text[] howMuchLootText = new Text[5];
    public Button scrollUpButton;
    public Button scrollDownButton;


    public GameObject questPannel;
    public Text questName;
    public Text questDescription;
    public Text DaysOnQuest; // to be repurposed
    public Text RewardsFromQuest; // possibly an image of the things to win? 
    public Text questSelectionPageNumbers;
    public Button turnQuestAtLocationLeftButton;
    public Button turnQuestAtLocationRightButton;

    private int indexedRumorNumber;
    private int topOfTheListIndexNumber;
    private int bottomOfTheListIndexNumber;
    byte numberOfButtonsTodisplay;

    byte numberOfRewards;

    Quest questToChoose;  // quests to choose list of quests when the guy goes through and gets a refrence of all the possible quests at this location. 
    List<Quest> QuestsToChooseAtLocation = new List<Quest>();
    byte indexedQuestButtonNumber;

    Location highlightedLocation;
    List<Quest> questChoices = new List<Quest>(); // may remove latter and replace with asking specifically for the rumors quests
    

    public void closeMapProps()
    {
        foreach (Button b in buttonsWithRumorsOnThem)
        {
            b.GetComponentInChildren<Text>().text = " ";
            b.gameObject.SetActive(false);
        }
        scrollUpButton.gameObject.SetActive(false);
        scrollDownButton.gameObject.SetActive(false);
        removeAllSelectionFlags();
        BackOutOfQuestRumor();
    }

    public void HideQuestInfoPanel()
    {
        throw new NotImplementedException();
    }

    public void nodeClicked(Location nodesLocation)
    {
        Debug.Log("Location" + nodesLocation.Name);
        indexedQuestButtonNumber = 0;
        for (int i = 0; i < questChoices.Count; i++)
        {
            if (questChoices[i].QuestLocation == nodesLocation.Name)
            {
                QuestsToChooseAtLocation.Add(questChoices[i]);
                ShowQuestOnPage(QuestsToChooseAtLocation[indexedQuestButtonNumber]);
                highlightedLocation = nodesLocation;
            }
        } 
    }


    public void openMapProps()
    {
        endOfDayManager.setManagerState(this); // ehhhh i dont super love the state telling itself to change. 
        topOfTheListIndexNumber = 0;

        numberOfButtonsTodisplay = (byte)buttonsWithRumorsOnThem.Length;

        if (endOfDayManager.RumorsKnownAbout.Count < buttonsWithRumorsOnThem.Length)
        {
            numberOfButtonsTodisplay = (byte)endOfDayManager.RumorsKnownAbout.Count;
        }

        for (byte i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithRumorsOnThem[i].gameObject.SetActive(true);
        }

        for (byte j = numberOfButtonsTodisplay; j < buttonsWithRumorsOnThem.Length; j++)
        {
            buttonsWithRumorsOnThem[j].gameObject.SetActive(false);
        }

        bottomOfTheListIndexNumber = topOfTheListIndexNumber + buttonsWithRumorsOnThem.Length;

        labelButtons();

        if (numberOfButtonsTodisplay > 0)
        {
            scrollUpButton.gameObject.SetActive(true);
            scrollDownButton.gameObject.SetActive(true);
            ShowStatsOnPage(0);
        }

    }

    public void ShowQuestInfoPanel()
    {
        throw new NotImplementedException();
    }

    public void FinishTaskOnMap()
    {

    }

   public void GetRefrenceOfMapManager(MapManager constructMapManager)
    {
        mapManager = constructMapManager;
    }

   private void labelButtons()
    {
        for (int i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithRumorsOnThem[i].GetComponentInChildren<Text>().text = endOfDayManager.RumorsKnownAbout[i + topOfTheListIndexNumber].RumorName;
        }
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from Rumor");
    }

    public void RumorMenuOpen()
    {

    }

    public void ShowPresetAssets()
    {
        mapManager.openFromEndOfDay();
        closeAllrewardIcons();
    }

    public void HidePresetAssets()
    {
        mapManager.closeMapProps();
    }



    public void ScrollUp()
    {
        if (topOfTheListIndexNumber > 0)
        {
            topOfTheListIndexNumber--;
            bottomOfTheListIndexNumber--;
            labelButtons();
        }
    }
    public void ScrollDown()
    {
        if (bottomOfTheListIndexNumber < endOfDayManager.RumorsKnownAbout.Count)
        {
            topOfTheListIndexNumber++;
            bottomOfTheListIndexNumber++;
            labelButtons();
        }
    }

    public void ShowStatsOnPage(byte whichRumorToIndex)
    {
        removeAllSelectionFlags();
        BackOutOfQuestRumor();
        indexedRumorNumber = whichRumorToIndex + topOfTheListIndexNumber;
        grayOutSelectedAdventure();
        foreach (Quest q in endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor)
        {
            mapManager.SetPotentialQuestFlag(q);
            questChoices.Add(q);
        }

    }


    private void grayOutSelectedAdventure()
    {
        int whichRumorToGray = indexedRumorNumber - topOfTheListIndexNumber;
        for (int i = 0; i < buttonsWithRumorsOnThem.Length; i++)
        {
            buttonsWithRumorsOnThem[i].GetComponent<Image>().color = Color.white;
        }

        buttonsWithRumorsOnThem[whichRumorToGray].GetComponent<Image>().color = Color.gray;

    }


   



    public void ShowQuestOnPage(Quest questToShow)
    {
        // Quest questToAskAbout = endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[index]; // attempts to cash
        closeAllrewardIcons(); // refreshes our reward icons each time the pannel is opened.
        questToChoose = questToShow;
        numberOfRewards = 0;
        
        //indexedQuestNumber = index;
        questPannel.SetActive(true);
        questName.text = questToChoose.QuestName;
        questDescription.text = questToChoose.QuestDescription;


        foreach (StoreableItem s in questToChoose.RewardsFromQuest)// endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[index].RewardsFromQuest) 
        {
            rewardSlots[numberOfRewards].gameObject.SetActive(true);
            rewardSlots[numberOfRewards].sprite = s.displayArt(); // I don't know If I made things better or worse, yes this is way more oop, but I fear performance drops, need to ask my team if it's going to slow. 
            howMuchLootText[numberOfRewards].text = s.NumberLeft.ToString();
            numberOfRewards++;
        }

        activateQuestScrollButtons();
        activateQuestPageNumber();
    }

    private void activateQuestScrollButtons()
    {
        if (QuestsToChooseAtLocation.Count > 1)
        {
            turnQuestAtLocationLeftButton.gameObject.SetActive(true);
            turnQuestAtLocationRightButton.gameObject.SetActive(true);
        }

        else
        {
            turnQuestAtLocationLeftButton.gameObject.SetActive(false);
            turnQuestAtLocationRightButton.gameObject.SetActive(false);
        }

    }

    private void activateQuestPageNumber()
    {
      questSelectionPageNumbers.text = (indexedQuestButtonNumber + 1) + " / " + QuestsToChooseAtLocation.Count;
    }

    public void AddQuestToAdventureBook()
    {
        BackOutOfQuestRumor();
        removeAllSelectionFlags();
        highlightedLocation.AddNewQuestToThisLocation(questToChoose);
        endOfDayManager.RumorsKnownAbout.RemoveAt(indexedRumorNumber);
        ShowPresetAssets();
       
    }

    public void BackOutOfQuestRumor()
    {
        questPannel.SetActive(false);
        QuestsToChooseAtLocation.Clear();
    }

    private void closeAllrewardIcons()
    {
        foreach (Image i in rewardSlots)
        {
            i.gameObject.SetActive(false);
        }
    }

    private void removeAllSelectionFlags()
    {
        foreach (Quest q in questChoices)
        {
            mapManager.removePotentialQuestFlag(q);
        }

        questChoices.Clear();
    }

    public void turnPageLeftInQuestAtLocation()
    {
        if(indexedQuestButtonNumber > 0)
        {
            indexedQuestButtonNumber--;
            ShowQuestOnPage(QuestsToChooseAtLocation[indexedQuestButtonNumber]);
        }
    }

    public void turnPageRightInQuestAtLocation()
    {
        if (indexedQuestButtonNumber < QuestsToChooseAtLocation.Count -1)
        {
            indexedQuestButtonNumber++;
            ShowQuestOnPage(QuestsToChooseAtLocation[indexedQuestButtonNumber]);
        }
    }
}
