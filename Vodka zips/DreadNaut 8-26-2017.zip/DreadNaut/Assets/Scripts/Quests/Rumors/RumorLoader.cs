﻿using UnityEngine;
using System.Collections;
using System.IO;

public class RumorLoader
{

    string path;
    string jsonString;
    JSONObject rumorToCraft;
    enum rumorParserHelper { NAME,DESCRIPTION,QUESTS }; // a more visual way to see the construction of the rumor


    public void JsonRumorInit()
    {
        path = Application.dataPath + "/JsonFiles/RumorsInGame.json";
        jsonString = File.ReadAllText(path);
        rumorToCraft = new JSONObject(jsonString);


    }

    public Rumor rumorCreator(byte levelOfRumor)
    {
        
        Rumor rumorToReturn = new Rumor(); // constructor with params or no params, That is the question. 
        int rumorIndexer = Random.Range(0, rumorToCraft[levelOfRumor].Count);   // chooses which rumor from selected level cap to send out. 

        rumorToReturn.RumorName = rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.NAME].str; // trying this out to make creation a little more readable; 
        rumorToReturn.RumorDescription = rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.DESCRIPTION].str;

        for (int i = 0; i < rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.QUESTS].Count; i++) // adds the names of the quests we would like to attach to this rumor, these will be found in RUMORQUESTCOMBINER.
        { 
            rumorToReturn.addElementToQuestsToFind(rumorToCraft[levelOfRumor][rumorIndexer][(int)rumorParserHelper.QUESTS][i].str); 
         }

        return rumorToReturn;
    }
}
