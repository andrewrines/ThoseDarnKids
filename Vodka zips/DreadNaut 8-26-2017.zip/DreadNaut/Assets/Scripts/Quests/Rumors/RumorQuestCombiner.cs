﻿using UnityEngine;
using System.Collections;

public class RumorQuestCombiner 
{
    private RumorLoader rumorLoader;
    private QuestLoader questLoader;

    public void init()
    {
        rumorLoader = new RumorLoader();
        rumorLoader.JsonRumorInit();
        questLoader = new QuestLoader(); 
        questLoader.JsonQuestInit();
    }
   
    public Rumor findRumorToAdd(byte levelOfPatron) // for now it just returns, later it will use the quest loader to attach quests OOOOOORRRRR... possibly only creates the quest when the player clicks on the thing
    {
        Rumor RumorToReturn = new Rumor();
        RumorToReturn = rumorLoader.rumorCreator(levelOfPatron);
        questAdder(RumorToReturn);
        return RumorToReturn;
    }

    public void questAdder(Rumor rumorToReturn)
    {
        foreach (string s in rumorToReturn.QuestsToFind)
        {
            rumorToReturn.addElementToQuests(questLoader.questCreator(s));
        }
    }

}

