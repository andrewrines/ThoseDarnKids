﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PatronManager {

    public const byte chanceOfQuesterInMorning = 8; // wierd algorithums, think  chance out of 20 
    public const byte chanceOfRumorInMorning = 9;
    public const byte chanceOfQuesterInNoon = 10;
    public const byte chanceOfRumorInNoon = 5;
    public const byte chanceOfQuesterInNight = 2;
    public const byte chanceOfRumorInNight = 6;

    private TimeOfDayManager.TimeOfDay timeOfDayForPatronManager;
    public TimeOfDayManager.TimeOfDay TimeOfDayForPatronManager { get { return timeOfDayForPatronManager; } set { timeOfDayForPatronManager = value; } }

    private byte[] chancesOfQuestersThroughoutDay = new byte[4];
    private byte[] chancesOfRumorsThroughtDay = new byte[4];
   
    public List<Patron> Regulars = new List<Patron>();

    public void init()
    {
        chancesOfQuestersThroughoutDay[0] = chanceOfQuesterInMorning;
        chancesOfQuestersThroughoutDay[1] = chanceOfQuesterInNoon;
        chancesOfQuestersThroughoutDay[2] = chanceOfQuesterInNight;
        chancesOfQuestersThroughoutDay[3] = chanceOfQuesterInMorning; // keeps probablity the same even if their is a time spawn fall through

        chancesOfRumorsThroughtDay[0] = chanceOfRumorInMorning;
        chancesOfRumorsThroughtDay[1] = chanceOfRumorInNoon;
        chancesOfRumorsThroughtDay[2] = chanceOfRumorInNight;
        chancesOfRumorsThroughtDay[3] = chanceOfQuesterInMorning; 

        loadRegulars();
    }

    private void loadRegulars()
    {
        for (int i = 0; i < 8; i++)
        {
           Patron patronToLoad = patronLoader.Instance.spawnNewPatron();
            Regulars.Add(patronToLoad);
        }
    } 

    public Patron DrawAPatron()
    {
        if (Regulars.Count != 0)
        {
            int patronIndexer = Random.Range(0, Regulars.Count);
            Patron patronToReturn = Regulars[patronIndexer];
            Regulars.RemoveAt(patronIndexer);
            resetDefaults(patronToReturn);
            patronToReturn.Patience = assignTimetoWaitInBar(patronToReturn.thisPatronsPatienceLevel);
            patronToReturn.decideOnWhatTheyWantToDrink();
            if (patronToReturn.currentActivity != Patron.whatDoTheyWantToDo.TURNIN)
            {
                patronToReturn.currentActivity = chooseCurrentActivity();
            }
            //if (!patronToReturn.ReturningFromAQuest)
            //{
            //    patronToReturn.WantsToGoOnAdventure = DoTheyWantToAdventure();
            //    if (!patronToReturn.WantsToGoOnAdventure)
            //    {
            //        patronToReturn.HasRumorToShare = DoTheyHaveRumor();
            //    }
            //}
           // Debug.Log("FromPatronManager" + patronToReturn.DrinkThePatronWants.listIngredentsInDrink());
            return patronToReturn;
        }
        else
        {
            Debug.Log("No More Patrons In Line");
            return null;
        }
    }

    public void resetDefaults(Patron patronToReset)
    {
        // patronToReset.HasRumorToShare = false;
        //  patronToReset.WantsToGoOnAdventure = false;
        if (patronToReset.currentActivity != Patron.whatDoTheyWantToDo.TURNIN)
        patronToReset.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
        //drinks had
        // drunkeness;
    }

    public void putAPatronBack(Patron returningPatron)
    {
        Regulars.Add(returningPatron);
    }

    private float assignTimetoWaitInBar(Patron.patienceLevels PatronPatience)
    {
        if(PatronPatience == Patron.patienceLevels.LOW)
        {
            return Random.Range(8, 10); // 8 - 10
        }

       else if (PatronPatience == Patron.patienceLevels.MID)
        {
            return Random.Range(10, 15); // 10 - 15
        }

       else if (PatronPatience == Patron.patienceLevels.HIGH)
        {
            return Random.Range(15, 20); // 15 - 20
        }
        else
        {
            Debug.Log("Patience fall Through");
            return Random.Range(8, 12);
        }

    }

    public Patron.whatDoTheyWantToDo chooseCurrentActivity()
    {
        
        byte RollForActivity = (byte)Random.Range(1, 21);
        string DEBUGSTRING = "RollForActivity " + RollForActivity + " TIME OF DAY for patorn manager " + timeOfDayForPatronManager;
        if (RollForActivity <= chancesOfRumorsThroughtDay[(int)timeOfDayForPatronManager])
        {
            Debug.Log(DEBUGSTRING + " Rumor");
            return Patron.whatDoTheyWantToDo.RUMOR;
        }

        else if (RollForActivity <= (chancesOfRumorsThroughtDay[(int)timeOfDayForPatronManager] + chancesOfQuestersThroughoutDay[(int)timeOfDayForPatronManager]))
        {
            Debug.Log(DEBUGSTRING + " Adventure");
            return Patron.whatDoTheyWantToDo.ADVENTURE;
        }

        else
        {
            Debug.Log(DEBUGSTRING + " Drink");
            return Patron.whatDoTheyWantToDo.DRINK;
        }

    }

   
}
