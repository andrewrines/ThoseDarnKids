﻿using UnityEngine;
using System.Collections;

public class BarManager : MonoBehaviour {
    IBarManagerState noPatronHighlighted;
    IBarManagerState patronHighlighted;
    IBarManagerState patronClicked;
    IBarManagerState barPaused;

    IBarManagerState barManagerState;

    private PatronManager Pmanager;
    private AdventureManager adventureManager;
    private RumorQuestCombiner rumorQuestCombiner;
    public BookOfQuests bookOfQuests;
    public TimeOfDayManager TimeManager;
    public InventoryManager inventoryManager;
    public EndOfDayManager endOfDayManagement;
    public Seat[] Seats = new Seat[3];
    public Drink drinkToServe;
    public BattleReportManager battleReportManager;
    private Seat selectedSeat;
    public Seat SelectedSeat { get { return selectedSeat; } set { selectedSeat = value; } }
    TimeOfDayManager.TimeOfDay barTimeTracker;



    void Start()
    {
       
        Pmanager = new PatronManager();
        Pmanager.init(); // loadpatrons
        rumorQuestCombiner = new RumorQuestCombiner();
        rumorQuestCombiner.init();
        adventureManager = new AdventureManager();
        adventureManager.initAdventureManager();

    }

    void Update()
    {    
        for (int i = 0; i < Seats.Length; i++)
        {
            if (Seats[i].IsReadyForRespawn == true)
            {
                replaceBarPeople(i);
            }
           else if (Seats[i].IsNeedClear == true)
            {
                Pmanager.putAPatronBack(Seats[i].patron); // here if trouble happens, seperating the two so I can reuse clearASeat() in our send a guy out methoid, making it safe for end of day and 
                clearASeat(Seats[i]);
            }
        }

        checkTimeOfDay();
    }

    private void replaceBarPeople(int personToReplace)
    {
       if (TimeManager.CurrentTimeOfDay != TimeOfDayManager.TimeOfDay.CLOSED)
        Seats[personToReplace].FillSeat(Pmanager.DrawAPatron());
    }

    public void clearASeat(Seat seatToClear)
    {
       // Pmanager.putAPatronBack(seatToClear.patron);
        seatToClear.patron = null;
         seatToClear.EmptySeat();
       
        if (TimeManager.CurrentTimeOfDay == TimeOfDayManager.TimeOfDay.CLOSED)
        {
            checkIfBarIsEmpty();
            seatToClear.IsTimerPaused = true;  // HACK
        }
      
         seatToClear.setSeatTimer(TimeManager.patronOutOfSeatTimeBasedOnTimeOfDay());

    }

    private void checkTimeOfDay() 
    {
        if (barTimeTracker != TimeManager.CurrentTimeOfDay)
        {
            if (TimeManager.CurrentTimeOfDay == TimeOfDayManager.TimeOfDay.CLOSED)
            {
                checkIfBarIsEmpty();
            }
            Pmanager.TimeOfDayForPatronManager = TimeManager.CurrentTimeOfDay;
            barTimeTracker = TimeManager.CurrentTimeOfDay;
            
        }
    }

    private void checkIfBarIsEmpty()
    {
        bool isBarEmpty = true; 
        foreach (Seat s in Seats)
        {
            if (s.patron != null)
            {
                isBarEmpty = false;
                break;
            }
        }

        if (isBarEmpty)
        {
            AquirePatronManagerInformationForEndOfDayManager(); // I should make an end of the day function at some point , tells the end of day manager our regulars list. 
            throwAwayDrink(); // throws away current drink, possibly refunds ingredents? need to ask design when the great big drink patch comes in. 
            endOfDayManagement.pullUpEndOfDayScreen(); // pulls up end of day screen
            transferAllTakenQuestsToAdventureManager(); // checks the book for marked for removal quests, then transfers them over to the adventure manager. 
           // isTimePaused(true); // here
            Debug.Log("Our bar is empty, Pulling Up Manager");

        }
    }


    public BarManager()
    {
        noPatronHighlighted = new NoPatronHighlighted(this);
        patronHighlighted = new PatronHighlighted(this);
        patronClicked = new PatronClicked(this);
        barPaused = new BarPaused(this);

        barManagerState = noPatronHighlighted;
    }

    public void setBarState(IBarManagerState newBarManagerState)
    {
        barManagerState = newBarManagerState;
    }

    public void ClearPatronHighlight()
    {
       
        barManagerState.ClearPatronHighlight();
    }

    public void MouseOverPatron(Seat pickedSeat)
    {
        //selectedSeat = pickedSeat;
        //Debug.Log(selectedSeat.patron.Name);
        barManagerState.MouseOverPatron(pickedSeat); // blank
    }

    public void ClickPatron()
    {
        barManagerState.ClickPatron();
    }

    public void MakeDrink(byte itemSlotToUse)
    {
        barManagerState.MakeDrink(itemSlotToUse);
    }

    public void sellDrink()
    {
        int goldToPay;
        Debug.Log(selectedSeat.patron.compareDrinks(drinkToServe));
       switch (selectedSeat.patron.compareDrinks(drinkToServe))
        {
            case Patron.OpinionOnDrink.PERFECT:
                goldToPay = 15;
                break;

            case Patron.OpinionOnDrink.GREAT:
                goldToPay = 12;
                break;

            case Patron.OpinionOnDrink.GOOD:
                goldToPay = 9;
                break;

            case Patron.OpinionOnDrink.SOSO:
                goldToPay = 6;
                break;

            case Patron.OpinionOnDrink.BAD:
                goldToPay = 3;
                break;

            case Patron.OpinionOnDrink.AWFUL:
                goldToPay = 0;
                break;

            default:
                {
                    Debug.Log("WARNING price fall through");
                    goldToPay = 0;
                    break;
                }

        }

        inventoryManager.addGold(goldToPay);
     
        
    }

    public void serveDrink()
    {
        sellDrink();
        SelectedSeat.ConsumeBeverage(drinkToServe);
        drinkToServe.clearIngredentsInDrink();
        checkIfPatronSharesRumor();
    }

    public void checkIfPatronSharesRumor()  // Added 7/19/17 not sure if this is any good. Checks to see if the patron spills the beans, if so, a quest is added to the rumor mill and it tells the seat to play a specal diolouge from a special function, and that the guy no longer has a rumor
    {
        if (selectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.RUMOR)
        {
            byte chanceOfSharedRumor = (byte)Random.Range(1, 3);  // not final on algorithum. 
            if (chanceOfSharedRumor == 2)
            {
                //board adds rumor to rumor mill
                selectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
                selectedSeat.PatronSharesARumor(); // uses the new added function to give the player a specefic diolouge about quests, may have a paramiter at some point to give name of quest or a few details. 
                //questManager.AddRumorToQuestList();
                endOfDayManagement.addRumor(rumorQuestCombiner.findRumorToAdd(selectedSeat.patron.Level)); // OK so my thought was that since the game doesnet need to know about rumors until the end of the day, why not just hand the rumors one at a time to the end of day manager. 
                Debug.Log("RumorShared");
            }
        }
    }

    public void throwAwayDrink()
    {
        drinkToServe.clearIngredentsInDrink();
        drinkToServe.gameObject.SetActive(false);
        setBarState(noPatronHighlighted);
    }

    public void startNextDay()
    {
        TimeManager.startNewDay();
        isTimePaused(false);
        endOfDayManagement.closeEndOfDayScreen();
        bookOfQuests.PagesInTheBookOfQuests = endOfDayManagement.QuestsToSendToTheBook; // passes the list of quests form the end of day manager to the book of quests;
        adventureManager.passTime(); // all quests in the adventure manager advance one day forward, if last day, patrons test against quest.  
        passAllFinishedPatronsToPatronManager();  // all idle adventurers return to regulars for further instuction
    }

   
    #region swapCommands
    public IBarManagerState getYesHighlight()
    {
        return patronHighlighted;
    }

    public IBarManagerState getNoHighlight()
    {
        return noPatronHighlighted;
    }

    public IBarManagerState getYesClick()
    {
        return patronClicked;
    }

    public IBarManagerState barIsPaused()
    {
        return barPaused;
    }

    #endregion

    public void AquirePatronManagerInformationForEndOfDayManager() // I don't know if this is right, It asks the patronManager to directly give the list of patrons to the end of the day manager. 
    {
        endOfDayManagement.PatronsInRegulars = Pmanager.Regulars;
    }

    public void acceptQuestInBookOfQuests()
    {
        bookOfQuests.sendPatronOnQuest(); // assigns patron to list of patrons in selected quest  //selectedSeat.patron
        bookOfQuests.markQuestForRemoval(); // marks book quest to be removed at the end of the day. 
        clearASeat(selectedSeat);
        closeBookOfQuests(); // closes the book
        inventoryManager.payGold(bookOfQuests.CostOfQuest);
        Debug.Log(Pmanager.Regulars.Count);
    }
  

    public void closeBookOfQuests()
    {
        isTimePaused(false);
        bookOfQuests.closeBookOfQuests();
        setBarState(noPatronHighlighted);
    }

    public void turnPageInBattleReport()
    {
        battleReportManager.flipPageInBattleReport();
        switch (battleReportManager.currentPageOfReport)
        {
            case BattleReportManager.ReportPages.REWARDS:
                {
                    foreach (StoreableItem s in battleReportManager.RewardsToRedeem)
                    {
                        Debug.Log(battleReportManager.RewardsToRedeem.Count);
                        inventoryManager.addItemToInvintory(s);
                    }
                    break;
                }

                case BattleReportManager.ReportPages.LEVEL:
                {
                    break;
                }

            case BattleReportManager.ReportPages.CLOSED:
                {
                    isTimePaused(false);
                    setBarState(noPatronHighlighted);
                    break;
                }
        }

       
    }

    public void passAllFinishedPatronsToPatronManager()
    {
        
        foreach (Patron p in adventureManager.IdleAdventurers)
        {
            Pmanager.Regulars.Add(p);
            Debug.Log("Passing patron now");
        }
        adventureManager.clearAllIdleAdventurers();
    }

    private void transferAllTakenQuestsToAdventureManager()
    {
        foreach (Quest q in bookOfQuests.PagesInTheBookOfQuests)
        {
            if (q.RemoveQuestFromBookAtEndOfDay)
            {
                adventureManager.QuestsInProgress.Add(q);
            }
        }
        bookOfQuests.removeAllTakenQuests();
    }

    public void isTimePaused(bool yesNo)
    {
        foreach (Seat s in Seats)
        {
            s.IsTimerPaused = yesNo;
            s.patronsMug.IsPaused = yesNo;
        }
        TimeManager.IsTimePaused = yesNo;
    }

    //public void AquireQuestInformationForEndOfDayManager() // may not need, I am more infavor of adding each rumor to the end of day individually when the game needs them rather than in one large list.
    //{
    //  endOfDayManagement.RumorsKnownAbout = questManager.QuestInvintory;
    //}

    // Use this for initialization


    // Update is called once per frame


}
