﻿using UnityEngine;
using System.Collections;

public class IncrementQuestBookPage : CommandWithUndo
{



    public IncrementQuestBookPage() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.bookOfQuests.flipPageRight();
        }
        base.Execute(Bar);
    }
}
