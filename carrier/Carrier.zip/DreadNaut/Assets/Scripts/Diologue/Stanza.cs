﻿using UnityEngine;
using System.Collections;

public class Stanza 
{
    string identifier;
    string characterDiolouge;
    //string stanzasToRemove;
    //string stanzasToAdd;
    //string discussionsToAdd;
    bool isUnlockedStanza { get; set; }
    // do we have unockers in here?

    public Stanza(string characterDiolouge, string identifier, bool isUnlockedStanza)  // string stanzasToRemove, string stanzasToAdd, string discussionsToAdd,
    {
        this.characterDiolouge = characterDiolouge;
        //this.stanzasToRemove = stanzasToRemove;
        //this.stanzasToAdd = stanzasToAdd;
        //this.discussionsToAdd = discussionsToAdd;
        this.identifier = identifier;
        this.isUnlockedStanza = isUnlockedStanza;
    }

    public string getIdentifier()
    {
        return identifier;
    }


    public string stanzaSays()
    {
        return characterDiolouge;
    }



}

