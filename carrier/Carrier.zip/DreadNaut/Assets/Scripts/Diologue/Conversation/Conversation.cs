﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Conversation
{

    public Conversation(string nameOfConversation, bool _isOneShot)
    {
        nameOfThisConversation = nameOfConversation;
        isOneShot = _isOneShot;
        isConversationOver = false;
    }
    //stores stanzas
    List<string> stanzasInConversation = new List<string>(); // keeping it strings for now, not sure if we need stanzas to do something special.

    // index of conversation
    byte stanzaNumber;
    public byte DEBUGstanzaNumber { get { return stanzaNumber; } }

    //Check if conversation is over
    private bool isConversationOver;
    public bool IsConversationOver{get { return isConversationOver; }}

    // a conversation should have a string identifier if we need to force pull it up.
    // such as for rumor related. 
    private string nameOfThisConversation;
    public string NameOfThisConversation { get { return nameOfThisConversation; } }


    // who does this Conversation belong to?
    
        //Responce: The way I have this set up should be able to determine this.


    // is this a core conversation or are we unlocking this as some point.

    // Does this go away after used
    private bool isOneShot;
    public bool IsOneShot { get { return isOneShot; } }

    // shares a string
    public string dioOut()
    {
        return stanzasInConversation[stanzaNumber];
    }

    // increment stanza
    public void incrementStanza()
    {
        stanzaNumber++;
        checkIfConversationIsOver();
    }

    private void checkIfConversationIsOver()
    {
        if (stanzaNumber == stanzasInConversation.Count)
        {
            isConversationOver = true;
        }
    }
    
    // Load strings
    public void addStanza(string stanzaToLoad)
    {
        stanzasInConversation.Add(stanzaToLoad);
    }

    public void resetConversation()
    {
        stanzaNumber = 0;
        isConversationOver = false;
    }
}

