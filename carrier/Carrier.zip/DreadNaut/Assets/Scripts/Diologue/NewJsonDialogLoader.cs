﻿using UnityEngine;
using System.Collections;
using System.IO;

public class NewJsonDialogLoader
{
    string path;
    string jsonString;
    JSONObject conversationToAssemble;

    public void initNewJsonDialogLoader()
    {
        path = Application.streamingAssetsPath + "/JsonFiles/Conversation.json";
        jsonString = File.ReadAllText(path);
        conversationToAssemble = new JSONObject(jsonString);
    }

    //public DioWarhouse populateWarehouse() // really want to create an abstract loader object ... Kinda need to, once I get this whole dio thing working.
    //{
    ////    for (byte i= 0; i < conversationToAssemble.Count; i++)
    ////    {
    ////        var  = conversationToAssemble[i].keys;
    ////        foreach (string s in rumorLevel)
    ////        {

    ////            Rumor rumorToStore = rumorCreator(level, s);

    ////            if (level < rumorToCraft.Count - 1)
    ////                rumorWarehouse.storeRumor(level, rumorToStore);

    ////            else
    ////                rumorWarehouse.storeUnlockable(s, rumorToStore);
    ////        }
    ////    }
    ////}

    ////    return rumorWarehouse;
    //}



}

