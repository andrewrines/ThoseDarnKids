﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Conversation
{
    List<Stanza> stanzasInConversation = new List<Stanza>();

    public Conversation(List<Stanza> stanzasInConversation)
    {
        this.stanzasInConversation = stanzasInConversation;
    }

    public void addNewStanzaAt(Stanza stanzaToAdd, byte index)
    {
        
    }
    
    public void removeStanza(Stanza stanzaToRemove)
    {
        stanzasInConversation.Remove(stanzaToRemove);
    }

    public string getDioFromStanzaAt(byte index)
    {
        return stanzasInConversation[index].stanzaSays();
    }

}

