﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DioWarhouse
{
    //singleton;
    List<Conversation>[] charactersConversations;
    NewJsonDialogLoader DialogLoader;
    byte stanzaIterator;

    public void initDioWarehouse(byte numberOfPatronsInTheGame)
    {
        charactersConversations = new List<Conversation>[numberOfPatronsInTheGame];

        for (int i = 0; i < numberOfPatronsInTheGame; i++)
        {
            // warehouse, give me a list of conversations. 
            // charactersConversations[i] = newDioLoader.getConversationsForCharacter;
        }
    }

    public string getDioOutBasedOnID(byte patronID)
    {
        return charactersConversations[patronID][0].getDioFromStanzaAt(stanzaIterator);
    }
}

