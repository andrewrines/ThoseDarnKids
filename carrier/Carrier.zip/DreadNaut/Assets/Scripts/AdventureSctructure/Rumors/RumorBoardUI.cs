﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class RumorBoardUI : MonoBehaviour {

    [SerializeField]
    Text RumorName;

    [SerializeField]
    Text RumorDescription;

    [SerializeField]
    QuestOptionUI[] questOptionsForRumor;

    // we want to activate
    public void activatePatronRumorBoard()
    {
        this.gameObject.SetActive(true);
    }

    // we want to deActivate
    public void deActivatePatronRumorBoard()
    {
        this.gameObject.SetActive(false);
        deactivateQuestOptions();
    }

    private void deactivateQuestOptions()
    {
        for (int i = 0; i < questOptionsForRumor.Length; i++)
        {
            questOptionsForRumor[i].deactivateQuestOption();
        }
    }

    //We want to display the rumor passed to us from the rumor manager. This includes a name, a description, and it's respective quest options
    public void labelPatronRumorBoard(Rumor rumorToLabelBoardWith)
    {
        RumorName.text = rumorToLabelBoardWith.RumorName;
        RumorDescription.text = rumorToLabelBoardWith.RumorDescription; 
        for (int i = 0; i < rumorToLabelBoardWith.QuestForThisRumor.Count; i++)
        {
            questOptionsForRumor[i].activateQuestOption();
            questOptionsForRumor[i].QuestContainedInOption = rumorToLabelBoardWith.QuestForThisRumor[i];
        }
    }

    public Quest selectQuestFromOptions(byte indexer)
    {
        return questOptionsForRumor[indexer].QuestContainedInOption;
    }


    // We want to turn on as many QuestOptionUI as there are options for the quest;

    // Once selected, we want to return a quest to the rumor manager. 




	
}
