﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RumorWarehouse
{
   // List<Rumor> commonKnowlage = new List<Rumor>();
    List<Rumor>[] rumorsByCharacter;
    Dictionary<string, Rumor> unlockableRumors = new Dictionary<string, Rumor>();
    QuestLoader questLoader = new QuestLoader(); 


    public void initRumorWarehouse()
    {
        questLoader.JsonQuestInit();
    }

    public void initRumorsByCharacterArray(int charactersInGame)
    {
        rumorsByCharacter = new List<Rumor>[charactersInGame];
       
        for (int i = 0; i < rumorsByCharacter.Length; i++)
        {
            rumorsByCharacter[i] = new List<Rumor>();
        }
    }

    public void storeRumor(int characterID, Rumor rumorToStore)
    {

        rumorToStore.QuestForThisRumor.Clear();

        //if (level > rumorsByCharacter.Length)
        //{
        //    //commonKnowlage.Add(rumorToStore);
        //}
       // else
        rumorsByCharacter[characterID].Add(rumorToStore);
    }

    public void storeUnlockable(string nameOfUnlockableRumor, Rumor rumorToStore)
    {
        unlockableRumors.Add(nameOfUnlockableRumor, rumorToStore);
    }

    public Rumor giveRandomRumorBasedOnCharacter(byte characterID)
    {
        Rumor rumorToReturn;

            int randy = Random.Range(0, rumorsByCharacter[characterID].Count);
            rumorToReturn = rumorsByCharacter[characterID][randy];
            rumorsByCharacter[characterID].RemoveAt(randy);

        if (rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.FETCH)
        {
            Rumor rumorToStoreAgain = new Rumor(rumorToReturn.RumorName, rumorToReturn.RumorDescription, rumorToReturn.OwnersID, rumorToReturn.RepeatableType, rumorToReturn.QuestsToFind);
            storeRumor(rumorToStoreAgain.OwnersID,rumorToStoreAgain);
        }

        rumorToReturn = attachQuestsToRumor(rumorToReturn, characterID);
        //foreach (string questName in rumorToReturn.QuestsToFind)
        //{
        //    Quest questToAdd = new Quest();
        //    questToAdd = questLoader.createQuestByName(questName);
        //    questToAdd.RumorID = rumorToReturn.RumorName;
        //    questToAdd.OwningCharactersID = characterID;
        //    questToAdd.RumorRepeatType = rumorToReturn.RepeatableType;
        //    rumorToReturn.QuestForThisRumor.Add(questToAdd);
        //}
        return rumorToReturn;
    }

    public Rumor unlockSpecificRumorBasedOnName(string name)
    {
        Rumor RumorToAssign = unlockableRumors[name];
        attachQuestsToRumor(RumorToAssign, RumorToAssign.OwnersID);
        //Rumor RumorToAdd = new Rumor(RumorToAssign.RumorName, RumorToAssign.RumorDescription, RumorToAssign.OwnersID, RumorToAssign.RepeatableType, RumorToAssign.QuestsToFind);
        return RumorToAssign;
       // rumorsByCharacter[RumorToAdd.OwnersID].Add(RumorToAdd);

       // commonKnowlage.Add(RumorToAdd);
        //Debug.Log("Regarding unlockable quests" + commonKnowlage.Count);
    }

    public int getNumberOfRumorsRemainingInCharacter(byte patronID)
    {
        return rumorsByCharacter[patronID].Count;
    }

    private Rumor attachQuestsToRumor(Rumor rumorToModify, byte characterID)
    {
        foreach (string questName in rumorToModify.QuestsToFind)
        {
            Quest questToAdd = new Quest();
            questToAdd = questLoader.createQuestByName(questName);
            questToAdd.RumorID = rumorToModify.RumorName;
            questToAdd.OwningCharactersID = characterID;
            questToAdd.RumorRepeatType = rumorToModify.RepeatableType;
            rumorToModify.QuestForThisRumor.Add(questToAdd);
        }
        return rumorToModify;
    }
}
