﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RumorManager : MonoBehaviour
{
    List<Rumor> activeRumors = new List<Rumor>();

    RumorWarehouse rumorWarehouse;
    RumorLoader rLoader = new RumorLoader();

    public void initRumorWarehouse()
    {
        rLoader.JsonRumorInit();
        rumorWarehouse = rLoader.populateWarehouse();
        rumorWarehouse.initRumorWarehouse();
    }

    public Rumor getRandomRumorFromWarehouseByCharacter(byte patronID)
    {
        Rumor rumorToReturn = rumorWarehouse.giveRandomRumorBasedOnCharacter(patronID);
        if (rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.REPEATABLE || rumorToReturn.RepeatableType == RumorLoader.RepeatableTypes.STORY)
        {
            activeRumors.Add(rumorToReturn);
        }
        return rumorToReturn;
    }

    public Rumor unlockRumor(string questToUnlock)
    {
       return rumorWarehouse.unlockSpecificRumorBasedOnName(questToUnlock);
    }

    public void storeRumor(string rumorID, bool storeAgain)
    {
        Debug.Log("HIT ON " + rumorID);
        for (int i = 0; i < activeRumors.Count; i++)
        {
            if (activeRumors[i].RumorName == rumorID)
            {
                Debug.Log("We Found a match!");
                Debug.Log(storeAgain);
                if (storeAgain)
                {
                    rumorWarehouse.storeRumor(activeRumors[i].OwnersID, activeRumors[i]);
                    Debug.Log("Sending quest Back!");
                }
                activeRumors.RemoveAt(i);
                break;
            }
        }

    }

    public int getNumberOfRumorsLeftInCharacter(byte patronID)
    {
       return rumorWarehouse.getNumberOfRumorsRemainingInCharacter(patronID);
    }
}

