﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Rumor
{

    public Rumor(string name, string description, byte level, RumorLoader.RepeatableTypes rep, List<string> inQuestsToFind  )
    {
        rumorName = name;
        rumorDescription = description;
        rumorLevel = level;
        repeatableType = rep;
        questsToFind = inQuestsToFind;
    }
    private string rumorName;
    public string RumorName { get { return rumorName; } }

    private string rumorDescription;
    public string RumorDescription { get { return rumorDescription; } }

    private string patronWhoGaveRumor;
    public string PatronWhoGaveRumor { get { return patronWhoGaveRumor; }  }

    private byte rumorLevel;
    public byte RumorLevel { get { return rumorLevel; }  }

    private RumorLoader.RepeatableTypes repeatableType;
    public RumorLoader.RepeatableTypes RepeatableType { get { return repeatableType; } }

    private List<string> questsToFind = new List<string>();
    public List<string> QuestsToFind { get { return questsToFind; }  }

    private List<Quest> questsForThisRumor = new List<Quest>();
    public List<Quest> QuestForThisRumor { get { return questsForThisRumor; }  }

}
