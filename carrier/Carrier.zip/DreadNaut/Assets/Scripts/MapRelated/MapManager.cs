﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapManager : MonoBehaviour //This doesn't have to be a Monobehaviour.  Update code to improve this!
{

    IMapStates deployState;
    IMapStates warRoomState;

    IMapStates mapMode;

    [SerializeField] List<LocationAndKey> allLocations;

    [SerializeField] QuestInfoPanel questInfoPanel;
    public QuestInfoPanel getQuestInfoPanel { get { return questInfoPanel; } }
   
    [SerializeField] RectTransform MapImage;

    [SerializeField]
    MapVisualEffects mapVisualEffectScript;
    public MapVisualEffects MapVisualEffectScript { get { return mapVisualEffectScript; } }

    private Patron patronToGoOnAdventure;
    public Patron PatronToGoOnAdventure { get { return patronToGoOnAdventure; } }

    public WarRoomState warRoomStateScript;
    public DeployState deployStateScript;

    private List<Patron> questingPatrons = new List<Patron>();
    public List<Patron> QuestingPatrons { get { return questingPatrons; } }
   // List<Adventure> allCurrentAdventures = new List<Adventure>();   //A list of all currently active adventures

    [System.Serializable]
    struct LocationAndKey
    {
        public Location location;
        public Location.LocationIdentifier key;
    }

    /// <summary>
    /// Sets a quest to a location by name of the quest.  The quest's name must match the name given in the inspector!
    /// </summary>
    /// <param name="targetQuest"></param>
    /// <returns>Returns true if the quest was added to the location successfully</returns>
    /// 

    public void openFromEndOfDay()
    {
        if (warRoomState == null)
        {
            initWarRoomState();
        }
        mapMode = warRoomState;
        MapImage.gameObject.SetActive(true);
        mapMode.openMapProps();
    }

    public void mapOpenFromBar(Patron inPatronOnAdventure)    //THIS IS CALLED FROM OUTSIDE THE MAP SYSTEM.  This should start the chain of events needed to construct an adventure.
    {
        if (deployState == null)
        {
            initDeployState();
        }
        mapMode = deployState;
        patronToGoOnAdventure = inPatronOnAdventure;
        MapImage.gameObject.SetActive(true);
        mapMode.openMapProps();
        SoundManager.Instance.AddCommand("OpenMap");
    }

    public void closeMapProps()
    {
        MapImage.gameObject.SetActive(false);
        mapMode.closeMapProps();
    }

    public void nodeClicked(Location nodesLocation) 
    {
        mapMode.nodeClicked(nodesLocation);
    }

    public void ShowQuestInfoPanel()
    {
        mapMode.ShowQuestInfoPanel();
    }

    public void HideQuestInfoPanel()
    {
        mapMode.HideQuestInfoPanel();
    }

    public void FinishTaskOnMap()
    {
        mapMode.FinishTaskOnMap();
    }

    public void unlockLocation(string nameOfTargetLocation)
    {
        findLocationFromDictionary(nameOfTargetLocation).unlockLocation();
    }

    public void setQuestAtItsLocation(Quest targetQuest)
    {
        findLocationFromDictionary(targetQuest).AddNewQuestToThisLocation(targetQuest);
    }

    private void removeQuestFromLocation(Quest targetQuest)
    {
        findLocationFromDictionary(targetQuest).removeQuestFromLocation(targetQuest);
    }

    public void DEBUGlockAllLocations()
    {
        foreach  (LocationAndKey LAK in allLocations)
        {
            LAK.location.lockLocation();
        }
    }

    public void DEBUGUnlockAllLocations()
    {
        foreach (LocationAndKey LAK in allLocations)
        {
            LAK.location.unlockLocation();
        }
    }

    public void TimeProgressesForQuests()
    {
        foreach (Patron p in questingPatrons)
        {
            patronAttemptsQuestTrials(p);
            p.IsOnQuest = false;
            p.currentActivity = Patron.whatDoTheyWantToDo.TURNIN;
        }
    }

    //public void addAdventureToAllAdventures(Adventure adventureToAdd)
    //{
    //     allCurrentAdventures.Add(adventureToAdd);
    //}

    private Location findLocationFromDictionary(Quest q)
    {
        for (int i = 0; i < allLocations.Count; i++)
        {
            if (allLocations[i].key.ToString() == q.QuestLocation)
            {
                return allLocations[i].location;
            }
        }

        Debug.Log("Could Not find location" + q.QuestLocation);
        return null;
    }

    private Location findLocationFromDictionary(string locationName)
    {
        for (int i = 0; i < allLocations.Count; i++)
        {
            if (allLocations[i].key.ToString() == locationName)
            {
                return allLocations[i].location;
            }
        }

        Debug.Log("Could Not find location" + locationName);
        return null;
    }

    private void initWarRoomState()
    {
        warRoomState = warRoomStateScript;//new WarRoomState(this);
    }

    private void initDeployState()
    {
        deployState = deployStateScript;
    }

    public bool areThereAnyAdventuresForPatrons()
    {
        foreach (LocationAndKey LAK in allLocations)
        {
            if (LAK.location.QuestCountAtLocation > 0)
                return true;
        }
        return false;
    }

    private void patronAttemptsQuestTrials(Patron patronToAtemptTrials)
    {
        for (int i = 0; i < patronToAtemptTrials.QuestToCompleete.TrialsOfTheQuest.Count; i++)
        {
            QuestLoader.Trial trialToTest = patronToAtemptTrials.QuestToCompleete.TrialsOfTheQuest[i];
            byte patronsRoll = patronToAtemptTrials.rollPatronStat(trialToTest.challengeType);
            trialToTest.challengeRaiting = (sbyte)(trialToTest.challengeRaiting - patronsRoll);
            if (trialToTest.challengeRaiting <= 0) { trialToTest.challengeRaiting = 0; Debug.Log(patronToAtemptTrials.Name + "Passed"); }
            else
            {
                patronToAtemptTrials.fatiguePatron(trialToTest.challengeType, (byte)(trialToTest.challengeRaiting - patronsRoll));
                if (patronToAtemptTrials.IsExhausted)
                {
                    patronToAtemptTrials.QuestToCompleete.incrementAttemptsOnQuest();
                    patronToAtemptTrials.QuestToCompleete.checkIfAnyMoreTries();
                    break;
                }
            }
        }
        // If our patron makes it through all of the trials and is not exhausted, the quest is passed
        if (!patronToAtemptTrials.IsExhausted)
        {
            patronToAtemptTrials.QuestToCompleete.setToPass();
        }
        removeQuestFromLocation(patronToAtemptTrials.QuestToCompleete);
    }

    public void sendPatronOnQuest(Patron patronToAdd)
    {
        questingPatrons.Add(patronToAdd);
    }

    public void removePatronFromQuestingList(Patron p)
    {
        questingPatrons.Remove(p);
    }

    public void listAllLeftInAdventurers()
    {
        foreach (Patron p in questingPatrons)
        {
            Debug.Log(p.Name);
        }
    }

    /* NOTE:
     * I feel like I should use the state pattern?
     *      -> When the player clicks on a location, they should ONLY be able to interact with the "select a quest at this location" panel
     */

}
