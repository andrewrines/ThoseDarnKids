﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GamePiecePool : MonoBehaviour {

    [SerializeField]
    GamePiece gamePiecePrefab;

    Queue<GamePiece> gamePieces = new Queue<GamePiece>();


    public GamePiece drawGamePieceFromPool()
    {
        GamePiece gamePieceToReturn = null;
        bool isVacantPieceFound = false;
       foreach (GamePiece gp in gamePieces)
        {
            if (!gp.isActiveAndEnabled)
            {
                gamePieceToReturn = gp;
                isVacantPieceFound = true;
                break;
            }
        }

       if (!isVacantPieceFound)
        {
            gamePieceToReturn = addNewPieceToPool();
        }
        gamePieceToReturn.activateGamePiece();
        return gamePieceToReturn;
    }

    private GamePiece addNewPieceToPool()
    {
        GamePiece gp = Instantiate(gamePiecePrefab);
        gp.deactivateGamePiece();
        gamePieces.Enqueue(gp);
        return gp;
    }
}
