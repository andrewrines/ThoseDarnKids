﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class DeployState : MonoBehaviour, IMapStates
{

    enum MapState { INACTIVE, CONVERTING_RUMOR_TO_QUEST, SETTING_ADVENTURE_LOCATION, CHOOSING_QUEST }
    MapState currentMapState = MapState.INACTIVE;

    [SerializeField]
    Region startingRegion; //the location of the bar (every patron will start off here) // not sure we need this anymore, as locations are no longer linked. 

    [SerializeField]
    Color colorWhenSelectedForAdventure;
    [SerializeField]
    Color colorWhenNotSelectedForAdventure;

    [SerializeField]
    PatronCheatSheet patronCheatSheet;

    [SerializeField]
    RectTransform DependentUI;  //Condensed all the buttons and stuff into one parent object

    [SerializeField]            
    Text AdventureCostDisplay;

    [SerializeField]
    Text AdventureCostDisplayShadow;

    [SerializeField]
    GamePiecePool gamePiecePool;

    public MapManager mapManager;
    Region selectedRegion = null;

    
    //Adventure AdventureUnderConstruction;
   // public int getAdventureCost { get { return AdventureUnderConstruction.Cost; } }

    public DeployState(MapManager mapsly)
    {
        mapManager = mapsly;
    }

    public void closeMapProps()
    {
        patronCheatSheet.deactivatePatronCheatSheet();
        HideQuestInfoPanel();
        DependentUI.gameObject.SetActive(false);
        //AdventureUnderConstruction.ClearAdventure();
        mapManager.MapVisualEffectScript.ZoomMapOutOfRegion(selectedRegion); // just incase, I encounted a strange zoom in bug.
        UpdateAdventureCostDisplayText();
    }

    public void regionClicked(Region clickedRegion)
    {
        //if (currentLocation.IsAdjacentToLocation(clickedLocation) && !AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation) && clickedLocation != startingLocation && currentMapState != MapState.CHOOSING_QUEST) // && clickedLocation != startingLocation added 
       // {
            //Road r = currentLocation.FindRoadConnectedBetweenLocations(clickedLocation);

            selectedRegion = clickedRegion;
            //AdventureUnderConstruction.SetNodeLocation(clickedLocation, r);
            mapManager.MapVisualEffectScript.ZoomMapInToRegion(selectedRegion); 
            currentMapState = MapState.CHOOSING_QUEST;
            ShowQuestInfoPanel();
       // }
        //else if (AdventureUnderConstruction.IsLocationAlreadyInAdventure(clickedLocation))
        //{
        //    AdventureUnderConstruction.RemoveAllNodesPastGivenNodeLocation(clickedLocation);
        //    currentLocation = clickedLocation;
        //}
        UpdateAdventureCostDisplayText();
    }

    public void openMapProps()
    {
        //currentLocation = startingLocation;
        //if (AdventureUnderConstruction != null) { AdventureUnderConstruction.ClearAdventure(); } //wipe the temporary adventure, just to be safe
        //{
        //    Debug.Log(gamePiecePool);
        //    AdventureUnderConstruction = new Adventure(mapManager.PatronToGoOnAdventure, startingLocation, colorWhenSelectedForAdventure, colorWhenNotSelectedForAdventure, gamePiecePool.drawGamePieceFromPool());
        //}
        patronCheatSheet.activatePatronCheatSheet();
        patronCheatSheet.displayStats(mapManager.PatronToGoOnAdventure);
        currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
        DependentUI.gameObject.SetActive(true);
        UpdateAdventureCostDisplayText();
    }

    //public void assignPatronToQuest() 
    //{
    //    //AdventureUnderConstruction.SetNodeQuest(mapManager.getQuestInfoPanel.GetQuestFromLocation());
    //    //AdventureUnderConstruction.ConfirmNewNode();
       
    //    mapManager.MapVisualEffectScript.ZoomMapOutOfLocation(selectedLocation); 
    //    currentMapState = MapState.SETTING_ADVENTURE_LOCATION;
    //    HideQuestInfoPanel();
    //    UpdateAdventureCostDisplayText();
    //}


    public void ShowQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(true);
        mapManager.getQuestInfoPanel.InitializeQuestInfoPanel(selectedRegion);
    }

    public void HideQuestInfoPanel()
    {
        mapManager.getQuestInfoPanel.gameObject.SetActive(false);
    }

    public void FinishTaskOnMap() //Called when the player clicks the "Choose quest" add quest button;
    {
            mapManager.PatronToGoOnAdventure.QuestToCompleete = mapManager.getQuestInfoPanel.GetQuestFromLocation();
            mapManager.sendPatronOnQuest(mapManager.PatronToGoOnAdventure);
            mapManager.getQuestInfoPanel.GetQuestFromLocation().incrementNumberOfPatronsOnQuest();
    }

    public void GetRefrenceOfMapManager(MapManager constructMapManager)
    {
       // mapManager = constructMapManager;
    }

    void UpdateAdventureCostDisplayText()
    {

        // Print cost of quest based on designer's ideas


        //AdventureCostDisplay.text = "Cost: " + AdventureUnderConstruction.Cost;
        //AdventureCostDisplayShadow.text = "Cost: " + AdventureUnderConstruction.Cost;
    }

}

