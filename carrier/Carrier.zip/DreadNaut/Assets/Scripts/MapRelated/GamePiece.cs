﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GamePiece : MonoBehaviour {

    //Location previousLocation;
    Region currentLocation;


    private void Update()
    {

    }

    public void activateGamePiece()
    {
        this.gameObject.SetActive(true);
    }

    public void deactivateGamePiece()
    {
        this.gameObject.SetActive(false);
    }

    public void setGamePieceApperance(byte patronIdNumber)
    {
        this.gameObject.GetComponent<Image>().sprite = ApperanceManager.instance.ThisPatronsToken(patronIdNumber);
    }

    public void showPieceAtCurrentLocation()
    {
        this.gameObject.transform.SetParent(currentLocation.transform);
        this.gameObject.transform.position = currentLocation.transform.position;
    }

    public void findNextLocation(Region newLocation)
    {
        currentLocation = newLocation;
        showPieceAtCurrentLocation();
    }

    public void setPieceAtLocation(Region locationToSetPieceAt)
    {
        currentLocation = locationToSetPieceAt;
        showPieceAtCurrentLocation();
    }

    #region TransformStuffForLater
    //public void setPieceBackAtPreviousLocation()
    //{
    //    this.transform.position = previousLocation.transform.position;
    //    //movePiece = false;
    //}

    //public void moveToLocationsTransformOnMap() put this on hold for now.
    //{
    //    movePiece = true;
    //}
    // to go in update
    //if (movePiece)
    //{
    //    Debug.Log(previousLocation);
    //    Debug.Log(currentLocation);
    //    this.transform.position = Vector3.Lerp(previousLocation.transform.position, currentLocation.transform.position, transitionSpeed);

    //}
    #endregion
}
