﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class ShopState : MonoBehaviour, IEndOfDayStates
{

    public Button[] purchaseButtons = new Button[3];

    private IPurchaseable[] invintoryForTheDay = new IPurchaseable[3];
    // public Image[] IconsOfThingsYouCanBuy = new Image[3];

    private byte shopPageIndexer;

    public EndOfDayManager endOfDayManager;

    public Sprite backDropForShop;

    [SerializeField]
    Text NameOfThingToBuy;

    [SerializeField]
    Text descriptionOfThingToBuy;

    [SerializeField]
    Text CostOfThingToBuy;

    [SerializeField]
    Image ImageOfThingToBuy;

    [SerializeField]
    Button purchaseButton;

    public void HidePresetAssets()
    {
        NameOfThingToBuy.gameObject.SetActive(false);
        descriptionOfThingToBuy.gameObject.SetActive(false);
        CostOfThingToBuy.gameObject.SetActive(false);
        ImageOfThingToBuy.gameObject.SetActive(false);
        purchaseButton.gameObject.SetActive(false);
        deactivateShop();
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from store");
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openRumorScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from store");
    }

    public void StoreMenuOpen()
    {

    }

    public void ScrollDown()
    {
       
    }

    public void ScrollUp()
    {
    }

    public void ShowPresetAssets()
    {
        NameOfThingToBuy.gameObject.SetActive(true);
        descriptionOfThingToBuy.gameObject.SetActive(true);
        CostOfThingToBuy.gameObject.SetActive(true);
        ImageOfThingToBuy.gameObject.SetActive(true);
        purchaseButton.gameObject.SetActive(true);
        endOfDayManager.backDropForEndOfDayManager.sprite = backDropForShop;
        activateShop();
        ShowStatsOnPage(0);
    }


    public void ShowStatsOnPage(byte index)
    {
        NameOfThingToBuy.text = invintoryForTheDay[index].getName();
        descriptionOfThingToBuy.text = invintoryForTheDay[index].getDescription();
        CostOfThingToBuy.text = "COST: " + invintoryForTheDay[index].getPrice().ToString();
        shopPageIndexer = index;
        if (invintoryForTheDay[index].isSoldOut())
        {
            ImageOfThingToBuy.sprite = ApperanceManager.instance.getSoldOut();
            purchaseButton.GetComponentInChildren<Text>().text = "SOLD OUT";
            purchaseButton.enabled = false;
        }
        else
        {
            ImageOfThingToBuy.sprite = ApperanceManager.instance.getTapImage(invintoryForTheDay[index].getImageIdentifier());
            purchaseButton.GetComponentInChildren<Text>().text = "Purchase Item";
            purchaseButton.enabled = true;
        }
    }


    public void formatButtonsForThisPage()
    {

    }

    public void purchaseThisItem()
    {
        invintoryForTheDay[shopPageIndexer].purchaseItem();
        invintoryForTheDay[shopPageIndexer].setSoldOut();
        ShowStatsOnPage(shopPageIndexer);
    }

    public byte getIdentifier()
    {
        return shopPageIndexer;  // HACK
    }

    private void activateShop()
    {
        for (int i = 0; i < purchaseButtons.Length; i++)
        {
            purchaseButtons[i].gameObject.SetActive(true);
            purchaseButtons[i].GetComponentInChildren<Text>().text = invintoryForTheDay[i].getName();
        }
    }

    private void deactivateShop()
    {
        for (int i = 0; i < purchaseButtons.Length; i++)
        {
            purchaseButtons[i].gameObject.SetActive(false);
        }
    }



    public int getPriceOfHilightedObject()
    {
        return invintoryForTheDay[shopPageIndexer].getPrice();
    }

    public void setInventoryForEndOfTheDay(IPurchaseable[] inComminginvintoryForTheDay)
    {
        for (int i = 0; i < invintoryForTheDay.Length; i++)
        {
            invintoryForTheDay[i] = inComminginvintoryForTheDay[i];
        }
    }



}
