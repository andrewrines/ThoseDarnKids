﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;
using System.Collections.Generic;

public class WarRoomState : MonoBehaviour, IMapStates ,IEndOfDayStates
{
    public MapManager mapManager;
    public EndOfDayManager endOfDayManager;

    [SerializeField]
    RectTransform DependentUI;

    public void openMapProps()
    { 

    }

    public void closeMapProps()
    {

    }

    public void nodeClicked(Location nodesLocation)
    {
        Debug.Log("This is: " + nodesLocation.name);
        Debug.Log("Patrons at this location" + nodesLocation.giveNamesOfPatronsAtThisLocation());
        Debug.Log("Active quests at this location" + nodesLocation.giveNamesOfQuestsAtThisLocation());
    }

    public void ShowQuestInfoPanel()
    {
        // Show the panel for what this location is and who is there;
        throw new NotImplementedException();
    }

    public void HideQuestInfoPanel()
    {
        // Hide the panel for what this location is and who is there;
        throw new NotImplementedException();
    }

    public void FinishTaskOnMap()
    {
        // No real tasks yet, I was thinking Hide questInfo panel is called from this
        throw new NotImplementedException();
    }

    public void GetRefrenceOfMapManager(MapManager refrence)
    {
       // mapManager = refrence;
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from rumor");
    }

    public void StoreMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openShopScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from rumor");
    }

    public void RumorMenuOpen()
    {

    }

    public void ShowPresetAssets()
    {
        mapManager.openFromEndOfDay(); // throw new NotImplementedException();
    }

    public void HidePresetAssets()
    {
        mapManager.closeMapProps();
    }

    public void ScrollUp()
    {
        //throw new NotImplementedException();
    }

    public void ScrollDown()
    {
        //throw new NotImplementedException();
    }

    public void ShowStatsOnPage(byte index)
    {
       // throw new NotImplementedException();
    }

    public void formatButtonsForThisPage()
    {
        //throw new NotImplementedException();
    }
}
