﻿using UnityEngine;
using System.Collections;

public class TapSystem : MonoBehaviour {

    // currently moves our tap up and down, Ideally, I would like this to be the home of the functionality to switch taps too.

    [SerializeField]
    float howLongIsPan;

    [SerializeField]
    float howFarToGoUpScreen;


    private float desiredPositionOnScreen;

   // private Vector3 desiredLocation;
    
   // private Vector3 velocity;


    public void Start()
    {
        hideTapSystem();
    }
        
     void Update()
    {
        this.transform.position = Vector3.Lerp(this.transform.position, new Vector3(this.transform.position.x, (desiredPositionOnScreen * Screen.height), this.transform.position.z), howLongIsPan);
    }

    public void hideTapSystem()
    {
        desiredPositionOnScreen = -howFarToGoUpScreen;
    }

    public void showTapSystem()
    {
        desiredPositionOnScreen = howFarToGoUpScreen;
    }
}
