﻿using UnityEngine;
using System.Collections;

public class Day1Task3 : TutorialTask
{
    public Day1Task3(Tutorial tutorial) : base (tutorial)
    {
        tutorial.forcePatronIntoBarToSitAt("Deirdre Downton", 1);
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Goldfire");
        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.INCORRECT_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.MIXUP_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.CORRECT_DRINK_SEVED, ServeCorrectDrink);
    }

    void ServeCorrectDrink()
    {
        tutorial.unPauseSeatAtIndex(1);
        tutorial.forcePatronOutOfBarAtSeat(1);

        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.PATRON_LEFT, WaitForDeidreToLeave);
    }
    void WaitForDeidreToLeave()
    {
        tutorial.SetCurrentTask(new Day1Task4(tutorial));
    }

    void ServeIncorrectDrink()
    {
        tutorial.forceSpecificReactionFromSpecificPatron(JsonDialogueLoader.responceType.ABOUTTOLEAVE, 0, "Deidre Downton");
        tutorial.pauseSeatAtIndex(1);
        tutorial.resetOrderAtSpecificSeat(1);
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Goldfire");
    }
}
