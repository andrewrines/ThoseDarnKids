﻿using UnityEngine;
using System.Collections;

public class Day1Task4 : TutorialTask
{
    public Day1Task4(Tutorial tutorial) : base(tutorial)
    {
        tutorial.forcePatronIntoBarToSitAt("Artie", 1);
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Flare");
        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.INCORRECT_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.MIXUP_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.CORRECT_DRINK_SEVED, ServeCorrectDrink);
    }
    void ServeCorrectDrink()
    {
        tutorial.unPauseSeatAtIndex(1);
        tutorial.forcePatronOutOfBarAtSeat(1);
        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.PATRON_LEFT, WaitForFade);
        
    }

    void WaitForFade()
    {
        tutorial.forceEndOfDay();
        tutorial.unregisterBarmanager();
        tutorial.unregisterSelfFromMediator();
        tutorial.endTutorial();
       // tutorial.SetCurrentTask(null);
        // tutorial.SetCurrentTask(new Day1Task4(tutorial));
    }

    void ServeIncorrectDrink()
    {
        tutorial.forceSpecificReactionFromSpecificPatron(JsonDialogueLoader.responceType.ABOUTTOLEAVE, 0, "Artie");
        tutorial.pauseSeatAtIndex(1);
        tutorial.resetOrderAtSpecificSeat(1);
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Flare");
    }
}
