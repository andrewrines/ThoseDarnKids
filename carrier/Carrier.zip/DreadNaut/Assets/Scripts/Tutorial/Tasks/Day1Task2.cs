﻿using UnityEngine;
using System.Collections;

public class Day1Task2 : TutorialTask
{
    public Day1Task2(Tutorial tutorial) : base(tutorial)
    {
        //have Horace ask for a drink
        //tutorial.forceUnlockPatronOfName("Old Man Horace");
        tutorial.forcePatronIntoBarToSitAt("Old Man Horace", 1);
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Solarburst");
        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.INCORRECT_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.MIXUP_DRINK_SERVED, ServeIncorrectDrink);
        TutorialReactions.Add(Mediator.ActionIdentifiers.CORRECT_DRINK_SEVED, ServeCorrectDrink);
    }

    void ServeCorrectDrink()
    {
        tutorial.unPauseSeatAtIndex(1);
        tutorial.forcePatronOutOfBarAtSeat(1);

        TutorialReactions.Clear();
        TutorialReactions.Add(Mediator.ActionIdentifiers.PATRON_LEFT, WaitForHoraceToLeave);
    }
    void WaitForHoraceToLeave()
    {
        tutorial.SetCurrentTask(new Day1Task3(tutorial));
    }


    void ServeIncorrectDrink()
    {
        tutorial.pauseSeatAtIndex(1);
        tutorial.forceSpecificReactionFromSpecificPatron(JsonDialogueLoader.responceType.ABOUTTOLEAVE, 0, "Old Man Horace");
        tutorial.resetOrderAtSpecificSeat(1);
        tutorial.forceSeatToHaveSpecificOrderByName(1, "Solarburst");
        tutorial.forceSeatToHaveSpecificJob(1, Patron.whatDoTheyWantToDo.DRINK);
        Debug.Log( JsonDialogueLoader.Instance.specificDioOutByIndex(JsonDialogueLoader.responceType.ABOUTTOLEAVE, 0, "Old Man Horace"));
    }
}
