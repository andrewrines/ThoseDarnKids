﻿using UnityEngine;
using System.Collections;
using System.IO;

public class ItemParser
{   //IDEA and TODO, merge all loaders into some sort of parent loader class. 

   // string path;
    //string jsonString;
    JSONObject itemToReturn;
    public enum KindOfItem { ING, EQU, PTS, GOLD };


    //public ItemParser()
    //{
    //    //path = Application.streamingAssetsPath + "/JsonFiles/ItemsInGame.json";
    //    jsonString = File.ReadAllText(path);
    //    itemToReturn = new JSONObject(jsonString);
    //}

    public StoreableItem itemFactory(KindOfItem whatItemToFind, string nameOfItemToFind, int ammountOfItem)
    {

        switch (whatItemToFind)
        {
            case KindOfItem.ING:
                {
                    Ingredent ingredentToReturn = new Ingredent(ingredentLookup(nameOfItemToFind));
                    ingredentToReturn.NumberLeft = ammountOfItem;
                    return ingredentToReturn;
                }

            case KindOfItem.GOLD:
                {
                    Currency GoldToReturn = new Currency();
                    GoldToReturn.HowDoesThisItemLook = Currency.whosCurrencyIsThis.GOLD;
                    GoldToReturn.NumberLeft = ammountOfItem;
                    return GoldToReturn;
                }

            case KindOfItem.PTS:
                {
                    Currency PointsToGrant = new Currency();
                    PointsToGrant.HowDoesThisItemLook = currencyLookup(nameOfItemToFind);
                    PointsToGrant.NumberLeft = ammountOfItem;
                    return PointsToGrant;
                }
            //case KindOfItem.EQU:
            //    {
            //        // later when I figgure out items... sorry
            //    }



            default:
                {
                    Debug.Log("Fall through on  prize");
                    Currency GoldToReturn = new Currency();
                    GoldToReturn.HowDoesThisItemLook = Currency.whosCurrencyIsThis.GOLD;
                    GoldToReturn.NumberLeft = ammountOfItem;
                    return GoldToReturn;
                }
        }
    }


    private Ingredent.ingredentColor ingredentLookup(string ingredentColorToFind)
    {
        switch (ingredentColorToFind)
        {
            case "RED":
                return Ingredent.ingredentColor.RED;

            case "YELLOW":
                return Ingredent.ingredentColor.YELLOW;

            case "GREEN":
                return Ingredent.ingredentColor.GREEN;

            case "BLUE":
                return Ingredent.ingredentColor.BLUE;


            default:
                Debug.Log("Fall through on ingredent color prize");
                return Ingredent.ingredentColor.RED;
        }
    }

    private Currency.whosCurrencyIsThis currencyLookup(string factionToFind)
    {
        switch (factionToFind)
        {
            case "AA":
                return Currency.whosCurrencyIsThis.AA;

            case "COLLEGE":
                return Currency.whosCurrencyIsThis.COLLEGE;

            case "CORPOREAL":
                return Currency.whosCurrencyIsThis.CORPOREAL;

            case "EYES":
                return Currency.whosCurrencyIsThis.EYES;


            default:
                Debug.Log("Fall through on Faction pts prize");
                return Currency.whosCurrencyIsThis.GOLD;
        }




    }
}
