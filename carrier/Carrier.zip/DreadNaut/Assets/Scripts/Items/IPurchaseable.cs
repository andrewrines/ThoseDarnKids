﻿

public interface IPurchaseable  {

    void purchaseItem();
    void setPrice(int newPrice);
    int getPrice();
    string getName();
    string getDescription();
    byte getImageIdentifier();
    bool isSoldOut();
    void setSoldOut();
    
}
