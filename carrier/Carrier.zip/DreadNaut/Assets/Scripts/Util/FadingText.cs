﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Text;

public class FadingText : MonoBehaviour { // I want this to be a fadable object too, I jsut an not sure how to get an image to act like a sprite renderer or have fadable object call one or the other. 

    protected Image textBoxToFade;
    public Text dioToFade;
    public Text nameToFade;
    public float timeTillFade;
    private float timeTillFadeCountDown;
    public float howLongIsThisFade;
    protected float fadeCountdown;
    public byte charactersBeforeBreak;
    private Color FullHereColorForBox;
    private Color FullHereColorForText;

    private void Start()
    {
        textBoxToFade = this.gameObject.GetComponent<Image>();
        //textToFade = this.gameObject.GetComponentInChildren<Text>();
        FullHereColorForBox = textBoxToFade.color;
        FullHereColorForText = dioToFade.color;
    }


    // Update is called once per frame
    void Update () {
        tickTimeDown();
	}

    public virtual void sendWhatToSay(string patronsName ,string dioOut)
    {
        textBoxToFade.color = FullHereColorForBox;
        dioToFade.color = FullHereColorForText;
        this.gameObject.SetActive(true);
        dioToFade.text = formatText(dioOut);
        nameToFade.text = patronsName;
        fadeCountdown = howLongIsThisFade;
        timeTillFadeCountDown = timeTillFade;
    }

    public void cutOff(float speedOfSeatFade)
    {
        timeTillFadeCountDown = 0;
        fadeCountdown = speedOfSeatFade; 
    }

    private void tickTimeDown()
    {
        timeTillFadeCountDown -= Time.deltaTime;

        if (timeTillFadeCountDown <= 0)
        {
            runFadeAnimation();
        }
    }

    private void runFadeAnimation()
    {
        textBoxToFade.color -= new Color(0, 0, 0, FullHereColorForBox.a / fadeCountdown) * Time.deltaTime;
        dioToFade.color -= new Color(0, 0, 0, FullHereColorForText.a / fadeCountdown) * Time.deltaTime;

        if (textBoxToFade.color.a <= 0)
        {
            this.gameObject.SetActive(false);
        }
    }

    private string formatText(string textToFormat)  // TODO give public accessTo designer to change how many characters before cut off. // make this a util tool too!
    {
        StringBuilder strBuilder = new StringBuilder(textToFormat);
        int i = 0;
        for (int j = 0; j < textToFormat.Length; j++)
        {
            if (i >= charactersBeforeBreak && strBuilder[j] == ' ')
            {
                strBuilder[j] = '\n';
                i = 0;
            }
            i++;
        }
        textToFormat = strBuilder.ToString();
        return textToFormat;
    }
}
