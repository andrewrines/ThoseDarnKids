﻿using UnityEngine;
using System.Collections;


public class ToastPool : MonoBehaviour { // stole your pool!
    Toast[] toastPool = new Toast[7];
    
    [SerializeField]
    Toast ToastObjectToCreate;


    void Start()
    {
        Init();
    }

    void Init()
    {
        for (int i = 0; i < toastPool.Length; i++)
        {
            toastPool[i] = Instantiate(ToastObjectToCreate);
            toastPool[i].enabled = false;
        }
    }

    public void sendToastFromLocation(Vector3 locationOfToast, string whatToToast)
    {
        Toast toastOut = FindAvailableToastFromPool();
        toastOut.transform.SetParent(this.transform);
        toastOut.sendToast(locationOfToast, whatToToast);

    }

    Toast FindAvailableToastFromPool()
    {
        Toast toastToReturn = FindUnoccupiedToast();
        toastToReturn.enabled = true; 

        return toastToReturn;
    }

    Toast FindUnoccupiedToast()
    {
        for (int i = 0; i < toastPool.Length; i++)
        {
            if (!toastPool[i].enabled)
            {
                return toastPool[i];
            }
        }

        
        return toastPool[0];
    }

}
