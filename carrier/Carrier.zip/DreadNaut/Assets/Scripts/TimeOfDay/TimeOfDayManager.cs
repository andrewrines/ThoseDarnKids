﻿using UnityEngine;
using System.Collections;

public class TimeOfDayManager : MonoBehaviour {

    private int dayNumber;

    public void startNewDay()
    {
        dayNumber++;
        Debug.Log("Day:" + dayNumber);
    }

    //TODO: Write something for time of day background for background changes based on number of patrons in line.

}
