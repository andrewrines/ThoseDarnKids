﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TimeOfDayManager : MonoBehaviour {

    private int dayNumber;

    private float positionForSliderToMoveTo;

    [SerializeField]
    float howLongIsLerp;

    [SerializeField]
    Slider timeOfDaySlider;

    private void Update()
    {
       if (timeOfDaySlider.value < positionForSliderToMoveTo)
        {
            lerpToDesiredPosition();
        }
    }

    public void startNewDay()
    {
        dayNumber++;
        Debug.Log("Day:" + dayNumber);
        resetSunTrack();
    }

    // set patrons in line for this day
    public void getTheNumberOfPatronsForTheDay(byte numberOfPatronsInLine)
    {
        timeOfDaySlider.maxValue = numberOfPatronsInLine;
    }
    // Get an update whenever one of these patrons is drawn from regulars increment currentDaysProgression
    public void progressSundownMeter()
    {
        positionForSliderToMoveTo++;
    }

    // lerp to new location;
    private void lerpToDesiredPosition()
    {
        timeOfDaySlider.value += (positionForSliderToMoveTo / howLongIsLerp) * Time.deltaTime;
    }

    // reset sun tracker
    private void resetSunTrack()
    {
        timeOfDaySlider.value = 0; // I kinda want this to lerp as well, would need a bool or something to tell the function to go backward
        positionForSliderToMoveTo = 0;
    }

    // alter color of bar






}
