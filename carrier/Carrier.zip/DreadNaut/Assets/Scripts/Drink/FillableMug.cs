﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;

public class FillableMug : MonoBehaviour 
{
    // this class will be used for all the mix master magic that goes one with the bar. 
    Drink drinkInMug = new Drink();

    public Drink DrinkInMug { get { return drinkInMug; } }

    public static FillableMug currentMugBeingFilled;

    Vector2  cupHomePilePosition;


    public void sendCupToPile() // we may not even need this! Cool huh?
    {
        Debug.Log("Sending cup back to the pile" + cupHomePilePosition);
        currentMugBeingFilled = null;
        GetComponent<CanvasGroup>().blocksRaycasts = true;
        transform.parent = null;
        this.gameObject.SetActive(false);
    }

    #region dragFunctions
    // we may be able to get rid of this at some point. 
    //public void StartDragging()
    //{
    //    Debug.Log("startDrag");
    //    currentMugBeingDragged = this;
    //    startPosition = transform.position;
    //    startParent = transform.parent;
    //    GetComponent<CanvasGroup>().blocksRaycasts = false;
    //}

    //public void OnBeginDrag(PointerEventData eventData)
    //{
    //    StartDragging();
    //}

    //public void OnDrag(PointerEventData eventData)
    //{
    //    transform.position = Input.mousePosition;
    //}

    //public void OnEndDrag()
    //{
    //    Debug.Log("EndDrag");
    //    currentMugBeingDragged = null;
    //    GetComponent<CanvasGroup>().blocksRaycasts = true;

    //    if (transform.parent == startParent)
    //    {
    //        transform.position = startPosition;
    //        Debug.Log(startPosition);
    //    }
    //}

    //public void getCupPileParent(Transform cupPileTransform)
    //{
    //    if (cupPileParent == null)
    //    {
    //        Debug.Log("Figguring out where the pile transform parent is");
    //        cupPileParent = cupPileTransform;
    //    }
    //}

    //public void getCupPileParentPosition(Vector2 cupPilePosition)
    //{
    //    if (cupPilePosition == null)
    //    {
    //        Debug.Log("Figguring out where the pile position is");
    //        cupHomePilePosition = cupPilePosition;
    //    }
    //}
    #endregion



}
