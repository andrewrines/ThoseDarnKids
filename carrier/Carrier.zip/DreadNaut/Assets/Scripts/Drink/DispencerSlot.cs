﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;

public class DispencerSlot : MonoBehaviour//, IDropHandler
{
    public FillableMug mugInSlot    //I may want to change this getter
    {
        get
        {
            if (transform.childCount > 0)
                return transform.GetChild(0).GetComponent<FillableMug>();
            else
                return null;
        }
    }

    //public void OnDrop()  //PointerEventData eventData
    //{
    //    //If there isn't already a mug in this slot, set the mug here
    //    if (!mugInSlot)
    //    {
    //       // FillableMug.currentMugBeingDragged.transform.SetParent(transform);
    //        //FillableMug.currentMugBeingDragged.transform.position = transform.position;
    //        SoundManager.Instance.AddCommand("MoveMug");
    //    }
    //}
}
