﻿using UnityEngine;
using System.Collections;
using System.Text;
using UnityEngine.UI;

public class Seat : ABSTFadableObject
{
    #region fields
    public Patron patron;
    public Mug patronsMug;
    public IconPack patronWantsIcons;

    [SerializeField]
     FadingText fadingText;

    [SerializeField]
    float timeToFadeInOut;

    private SpriteRenderer patronArt;
    private float waitTimer;
    #endregion

    #region properties
    bool isReadyForRespawn;
    public bool IsReadyForRespawn { get { return isReadyForRespawn; } set { isReadyForRespawn = value; } }

    bool canDrink;
    public bool CanDrink { get { return canDrink; } set { canDrink = value; } }

    bool isNeedClear;
    public bool IsNeedClear { get { return isNeedClear; } set { isNeedClear = value; } }

    float drinkTimer;
    public float DrinkTimer { set { drinkTimer = value; } }

    bool isTimerPaused;
    public bool IsTimerPaused { set { isTimerPaused = value; } }
    #endregion

    #region ISeatStates
    ISeatStates noOneSeated;
    ISeatStates patronSeated;
    ISeatStates patronOrdered;
    ISeatStates patronIsDrinking;
    ISeatStates patronWantsAdventure;
    ISeatStates patronReturningFromAdventure;

    ISeatStates seatState;

    #endregion


    private void Start()
    {
        noOneSeated = new NoOneSeated(this);
        patronSeated= new PatronSeated(this);
        patronOrdered = new PatronOrdered(this);
        patronIsDrinking = new PatronIsDrinking(this);
        patronWantsAdventure = new PatronWantsAdventure(this);
        patronReturningFromAdventure = new PatronReturningFromAdventure(this);
   
        seatState = noOneSeated;
        isTimerPaused = false;
        this.GetComponent<BoxCollider2D>().enabled = false;

        patronWantsIcons.initIconsToDisplay();
        patronWantsIcons.initFadeTime(timeToFadeInOut);

        patronsMug.initMug();

        patronArt = this.GetComponent<SpriteRenderer>(); 
        assignObjectToFade(patronArt);
        setFadeTime(timeToFadeInOut);
    }

    private void Update()
    {
        if (currentAnimationState == animationStates.ENTER)
        {
            runEnterAnimation();
        }

        if (currentAnimationState == animationStates.EXIT)
        {
            runExitAnimation();
        }

        if (currentAnimationState == animationStates.EXITEND)
        {
            startSeatCoolDown();
        }

        if (seatState == patronIsDrinking)
        {
            drinkCountdown();
        }
        else
            respawnCountdown();
    }

    public void setSeatState(ISeatStates newSeatState)
    {
        seatState = newSeatState;
    }

    public void FillSeat(Patron patronToSit)
    {
        canDrink = true;
        seatState.FillSeat(patronToSit);
        startEnterAnimation();

        switch (patron.currentActivity)
          {
            case Patron.whatDoTheyWantToDo.RUMOR:
                {
                    patronWantsIcons.patronWantsToTellYouSomething(); //shows an icon for I have a rumor, the rumory bits are actually handled in bar manager because it knows what a quest manager is.
                    patronWantsIcons.startEnterAnimation();
                    break;
                }

            case Patron.whatDoTheyWantToDo.TURNIN:
                {
                    seatState.PatronReturnsFromQuest();
                    patronWantsIcons.patronIsReturningFromQuest();
                    patronWantsIcons.startEnterAnimation();
                    break;
                }

            case Patron.whatDoTheyWantToDo.ADVENTURE:
                {
                    seatState.PatronWantsToGoOnAdventure(); // Sets the state to I WANT TO ADVENTURE, locking it out of ordering drinks
                    patronWantsIcons.PatronWantsToGoOnAnAdventure(); // displays icon for I want to adventure. 
                    patronWantsIcons.startEnterAnimation();
                    break;
                }
          }
    }

    public void ConsumeBeverage(Drink drinkToConsume)
    {
        seatState.ConsumeBeverage(drinkToConsume);

    }

     public void PatronSharesARumor()
    {
        seatState.PatronSharesARumor();
    }


    #region SwapFunctions

    public ISeatStates ClearSeat()
    {
        Debug.Log( patron.Name + "Seat Should be clear");
        patron = null;
        isNeedClear = true;
        return noOneSeated;
    }


    public ISeatStates SeatIsFilled()
    {
        return patronSeated;
    }

    public ISeatStates orderHasBeenTaken()
    {
        return patronOrdered;
    }

    public ISeatStates patronIsdrinking()
    {
        return patronIsDrinking;
    }

    public ISeatStates patronWouldLikeToGoOnAdventure()
    {
        return patronWantsAdventure;
    }

    public ISeatStates patronIsReturningFromAdventure()
    {
        return patronReturningFromAdventure;
    }

    #endregion

    #region TimerRelated
    public void setSeatTimer(float timeToSet)
    {
        waitTimer = timeToSet;
    }

    public void drinkCountdown()
    {
        if (!isTimerPaused)
        {
            drinkTimer -= Time.deltaTime;
            if (drinkTimer <= 0)
            {
                patronPreparesToLeave();
            }
        }
    }

    public void respawnCountdown()
    {
        if (!isTimerPaused)  
       {
           if (waitTimer > 0)
          {
               waitTimer -= Time.deltaTime;
           }
           else if (seatState == noOneSeated)
          {
            isReadyForRespawn = true;
          }
        }
    }

    public void startSeatCoolDown()
    {
        setSeatTimer(5);
        setSeatState(ClearSeat());
        currentAnimationState = animationStates.NONE;
    }

    public void pauseThisSeat(bool yesNo)
    {
        this.isTimerPaused = yesNo;
        this.pauseAnimation(yesNo);
        this.patronsMug.pauseAnimation(yesNo);
        this.patronWantsIcons.pauseAnimation(yesNo);
    }
    #endregion

    #region Speach Related

    public void TalkWithPatron()
    {
        seatState.TalkWithPatron();
    }

    public void patronSays(string thingToSay)
    {
       fadingText.sendWhatToSay(patron.Name + " : " , thingToSay);
    }

    public void cutOffPatronsSentence()
    {
        fadingText.cutOff(0);
    }


    #endregion

    public void patronPreparesToLeave()
    {
        startExitAnimation();
        this.GetComponent<BoxCollider2D>().enabled = false;
        patronWantsIcons.startExitAnimation();
        patronsMug.fadeMug(timeToFadeInOut);
        fadingText.cutOff(timeToFadeInOut);
    }


}

