﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class patronLoader
{
    private string FallThroughHelper;  // used to help me find JSON typos

   private enum jsonHelper {NAME,TOLERANCE,STATS,BS1,BS2,BS3, BIO };      
    private string path;
    private string jsonString;
   private JSONObject patronToParse;
   private List<byte> indexingNumbers;
    private byte numberOfPatronsInGame;
   
    
    //private Patron patronGuy;

    //public static patronLoader Instance
    //{
    //    get
    //    {
    //        lock (padloc)
    //        {

    //            if (instance == null)
    //            {
    //                instance = new patronLoader();
    //               instance.loadTools();

    //            }
    //            return instance;
    //        }
    //    }
    //}

    public void loadTools()
    {
        indexingNumbers = new List<byte>();

        path = Application.streamingAssetsPath + "/JsonFiles/CharactersInGame.json";   
        jsonString = File.ReadAllText(path);
        patronToParse = new JSONObject(jsonString);
        loadIndexer((byte)patronToParse[0].Count);
        numberOfPatronsInGame = (byte)patronToParse[0].Count;
    }

    private void loadIndexer(byte indexerSize)
    {
        for (byte i = 0; i < indexerSize; i++)
        {
            indexingNumbers.Add(i);
        }
    }

    public Patron spawnRandomPatron()
    {
        int indexNumberToShareAndRemove = Random.Range(0, indexingNumbers.Count);
        byte numberToindex = indexingNumbers[indexNumberToShareAndRemove];
        indexingNumbers.RemoveAt(indexNumberToShareAndRemove);
        Patron patronToReturn = spawnPatron(0,numberToindex, numberToindex);
        return patronToReturn;
        
    }


    public Patron unlockSpecificPatron(string name)
    {
        var keyFinder = patronToParse[0].keys;
        byte index = 0;
        byte ID;
        Patron patronToReturn; 
        foreach (string o in keyFinder)
        {
            if (o == name)
            {
                break;
            }
            index++;
        }

        ID = (byte)(index);
        patronToReturn = spawnPatron(0, index, ID);
        return patronToReturn;
    }

    private Patron spawnPatron(byte lockLevel, byte patronIndex, byte patronID) // I dont know about this... parsing stuff. Not sure if its a pain or if its good. 
    {
        JSONObject randomlyCraftedPatron = patronToParse[lockLevel][patronIndex];
        string craftedName = randomlyCraftedPatron[(int)jsonHelper.NAME].str;
        FallThroughHelper = craftedName;
        packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]);
        Patron.drinkLevel CraftedDrinkLevel = ToleranceParser(randomlyCraftedPatron[(int)jsonHelper.TOLERANCE].str);
        string craftedBIO = @randomlyCraftedPatron[(int)jsonHelper.BIO].str;
        Patron patronToReturn = new Patron(craftedName, 0, CraftedDrinkLevel, packageStats(randomlyCraftedPatron[(int)jsonHelper.STATS]), craftedBIO);
        patronToReturn.ID = patronID;
        return patronToReturn;

    }


    private Patron.drinkLevel ToleranceParser(string levelToParse)
    {


        switch (levelToParse.ToLower())
        {

            case "low":
                {
                    return Patron.drinkLevel.LOW;
                }
            case "mid":
                {
                    return Patron.drinkLevel.MID;
                }
            case "high":
                {
                    return Patron.drinkLevel.HIGH;
                }
            case "none":
                {
                    return Patron.drinkLevel.NONE;
                }
            default:
                {
                    Debug.Log("Drink level Fall through:" + FallThroughHelper);
                    return Patron.drinkLevel.NONE;
                }
        }
    }

    private sbyte[] packageStats(JSONObject statsToPackage)  // don't know if this is confusing, basicly I just wanted to pass all of the stats as an array and not by themselves. 
    {
        sbyte[] craftedStates = new sbyte[4];// Tell me if it is and ill fix it. 
        for (int j= 0; j < statsToPackage.Count; j++)
        {
            craftedStates[j] = (sbyte)statsToPackage[j].i;
        }
        return craftedStates;
    }

    public byte getNumberOfPatronsInGame()
    {
        return numberOfPatronsInGame;
    }
}
