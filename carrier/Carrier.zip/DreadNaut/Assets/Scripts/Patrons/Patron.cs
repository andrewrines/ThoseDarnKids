﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Patron {

    private bool isExhausted;
    public bool IsExhausted { get { return isExhausted; } }

    private bool isOnQuest;
    public bool IsOnQuest { get { return isOnQuest; } set { isOnQuest = value; } }

    public bool IsUnlocked { get; private set; }

    private Quest questToCompleete;
    public Quest QuestToCompleete { get { return questToCompleete; } set { questToCompleete = value; } }

    private byte id;
    public byte ID { get { return id; } set { id = value; } }

    public enum Aligence { COLLEGE, CORPOREAL, AA, EYES, NONE };
    public Aligence thisPatronsAligence;

    public enum drinkLevel { NONE, LOW, MID, HIGH };
    public drinkLevel thisPatronsTolerance;

    public enum StatTypes { STRONG, SMART, SNEAK, SWAY, LENGTH}

    public enum whatDoTheyWantToDo {DRINK, RUMOR, ADVENTURE, TURNIN, CONVERSE}
    public whatDoTheyWantToDo currentActivity; 

   

    private string name;
    public string Name { get { return name; } set { name = value; } }

    private byte level;
    public byte Level { get { return level; } set { level = value; } }

    private int experiencePoints;
    public int ExperiencePoints { get { return experiencePoints; } }

    private int experiencePointsGainedOnThisQuest;
    public int ExperiencePointsGainedOnThisQuest { get { return experiencePointsGainedOnThisQuest; } set { experiencePointsGainedOnThisQuest = value; } }

    private int experienceThresholdToNextLevel = 50;
    public int ExperienceThresholdToNextLevel {get { return experienceThresholdToNextLevel; } }

    private IOrder orderThePatronWants;
    public IOrder OrderThePatronWants {get { return orderThePatronWants; } set { orderThePatronWants = value; } }

    private sbyte[] patronsBaseStats;
    public sbyte[] PatronsBaseStats { get { return patronsBaseStats; } }

    private sbyte[] patronsFatigueStats;
    public sbyte[] PatronsFatigueStats { get { return patronsFatigueStats; } }

    private string bio;
    public string Bio { get { return bio; } }

    private Conversation currentConversation;
    public Conversation CurrentConversation { get; set; }
    


    public Patron(string newName, byte newLevel, drinkLevel newDrinkLevel, sbyte[] newStats, string bioIn)
    {
        name = newName;
        level = newLevel;
        thisPatronsTolerance = newDrinkLevel;
        patronsBaseStats = newStats;
        patronsFatigueStats = new sbyte[4];
        bio = bioIn;
        resetAllPatronStat();
    }


    public byte rollPatronStat(StatTypes statToRoll) // TODO make copy of array for fatigue values, decrement accordingly
    {
        byte patronsRoll = (byte)Random.Range(1, patronsFatigueStats[(int)statToRoll]+1); // +1 is because range is exclusive 
        return patronsRoll; 
    }

    public void fatiguePatron(StatTypes statToFatigue, byte byWhatValue) // Woah!!! Taking heavy fire here!
    {
        Debug.Log("stat was" + patronsFatigueStats[(int)statToFatigue]);
        patronsFatigueStats[(int)statToFatigue]  = (sbyte)(patronsFatigueStats[(int)statToFatigue] - byWhatValue);
        Debug.Log("stat is currently " + patronsFatigueStats[(int)statToFatigue]);
        if (patronsFatigueStats[(int)statToFatigue] <= 0)
        {
            isExhausted = true;
        }
    }

    public void resetAllPatronStat() // when the patron gets back to the bar, we recover all their stats
    {
        for(int i = 0; i < patronsFatigueStats.Length; i++)
        {
            patronsFatigueStats[i] = patronsBaseStats[i];
        }
        isExhausted = false; 
    }

   

    public void gainEXP()   //int howMuchExpToGain
    {
        experiencePoints += experiencePointsGainedOnThisQuest;
        if (experiencePoints >= experienceThresholdToNextLevel)
        {
            levelUp();
        }
        experiencePointsGainedOnThisQuest = 0;
    }

    private void levelUp()
    {
        experiencePoints -= experienceThresholdToNextLevel;
        // increase stats
        level++; // cap at level 6 or whatever the designers want. 
        experienceThresholdToNextLevel = (level +1) * 50; // sets the bar higher for next time!
    }

   public void confirmUnlock()
    {
        IsUnlocked = true;
    }
}


