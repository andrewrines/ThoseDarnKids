﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Collections.Generic;

public class ConversationLoader
{
    enum ConversationParserHelper {NAME,ONESHOT,UNLOCKEDFROMSTART,STANZA }
    string path;
    string jsonString;
    JSONObject conversationToAssemble;

    public void initConversationLoaderLoader()
    {
        path = Application.streamingAssetsPath + "/JsonFiles/Conversations.json";
        jsonString = File.ReadAllText(path);
        conversationToAssemble = new JSONObject(jsonString);
    }

    public List<Conversation> loadPatronConversationsBasedOnId(byte patronID)
    {
        List<Conversation> conversationsToReturn = new List<Conversation>();
        for(int i = 0; i < conversationToAssemble[patronID].Count; i++)
        {
            if (conversationToAssemble[patronID][i][(int)ConversationParserHelper.UNLOCKEDFROMSTART].b == true)
            {
                Conversation conversationToAdd = conversationConstructor(conversationToAssemble[patronID][i]);
                conversationsToReturn.Add(conversationToAdd);
            }
        }
        return conversationsToReturn;
    }

    public Conversation getSpecificLockedConversation(byte patronID, string nameOfConversation)
    {
        Conversation conversationToReturn = conversationConstructor(conversationToAssemble[patronID][nameOfConversation]);
        if (conversationToReturn == null) {
            Debug.Log("Warning, could not find conversation named" + nameOfConversation + " Defaulting to basic chatter");
            return conversationConstructor(conversationToAssemble[patronID][0]);
        }

        else
            return conversationToReturn;
    }

    private Conversation conversationConstructor(JSONObject conversationToConstruct)
    {
        Conversation conversationToReturn = new Conversation(conversationToConstruct[(int)ConversationParserHelper.NAME].str, conversationToConstruct[(int)ConversationParserHelper.ONESHOT].b);
        for (int i = 0; i < conversationToConstruct[(int)ConversationParserHelper.STANZA].Count; i++)
        {
            conversationToReturn.addStanza(conversationToConstruct[(int)ConversationParserHelper.STANZA][i].str);
        }

        return conversationToReturn;
    }

    public sbyte findIndexOfName(string patronName)
    {
        for( sbyte i = 0; i < conversationToAssemble.Count; i++)
        {
            if (conversationToAssemble.keys[i] == patronName)
            {
                return i;
            }
        }

        return -1; 
    }


}

