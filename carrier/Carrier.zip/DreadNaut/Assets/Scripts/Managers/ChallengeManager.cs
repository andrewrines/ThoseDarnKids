﻿using UnityEngine;
using System.Collections;

public class ChallengeManager  {

    // should handle all our quests, the passage of time on them and should hand back patrons when a patron is done on 
    //their quest
	public void PatronAttemptsTheirQuest(Patron patronToAttemptQuest)
    {

    }
}
