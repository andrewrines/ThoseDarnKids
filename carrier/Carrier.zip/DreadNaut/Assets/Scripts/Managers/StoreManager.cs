﻿using UnityEngine;
using System.Collections;

public class StoreManager : MonoBehaviour {

    public Dispencer[] dispencersToBuy = new Dispencer[3];
    private IPurchaseable[] invintoryForTheDay = new IPurchaseable[3];

    public int getPrice(byte dispencersIndexNumber)
    {
        return dispencersToBuy[dispencersIndexNumber].getPrice();
    }

    public void purchaseItem(byte dispencersIndexNumber)
    {
        dispencersToBuy[dispencersIndexNumber].purchaseItem();
    }

    private void chooseInvintoryForTheDay() // Originally a work around for unity not knowing what the EFF Interfaces are. This is just placeholder but We can do something neat with this, we can have it load any Ipurchaseable into its invintory for the day.
    {
        for (int i = 0; i < invintoryForTheDay.Length; i++)
        {
            invintoryForTheDay[i] = dispencersToBuy[i];
        }
    }

    public IPurchaseable[] giveInvintoryForTheDay()
    {
        chooseInvintoryForTheDay();
        return invintoryForTheDay;
    }
}
