﻿using UnityEngine;
using System.Collections;

public class BarManager : MonoBehaviour {
    
    #region Props
    // A prop is a dependancie called from the inspector, click and drag to slot
    public Seat[] Seats = new Seat[3];
    private Seat selectedSeat;
    public Seat SelectedSeat { get { return selectedSeat; } set { selectedSeat = value; } }

    public RumorBoardUI rumorBoard;

    public TapSystem theBarsTaps;
     

    #endregion

    #region ManagerDependancies
    //If it has the word manager in it, chances are it will end up here public at top, in order of accessability
    public MapManager mapManager;
    public TimeOfDayManager TimeManager;
    public InventoryManager inventoryManager;
    public EndOfDayManager endOfDayManagement;
    public OrderManager orderManager;
    public BattleReportManager battleReportManager;
    public ToastPool toastDispencer;
    public StoreManager storeManager;

    private PatronManager Pmanager;
    RumorManager rumorManager;
    #endregion


    #region IBarManagerStates
    IBarManagerState patronHighlighted;
    IBarManagerState patronClicked;
    IBarManagerState barPaused;
    IBarManagerState barManagerState;
    #endregion

    //Fields should we need em.
    private sbyte seatIndexer; // which seat are we interacting with. 

    void Start()
    {
        rumorManager = new RumorManager();
        rumorManager.initRumorWarehouse();
        Pmanager = new PatronManager();
        Pmanager.init();
        startNextDay();
        orderManager.init();
        orderManager.unlockNewDrinksBasedOnIngredents(Ingredent.ingredentColor.RED);
        orderManager.unlockNewDrinksBasedOnIngredents(Ingredent.ingredentColor.YELLOW);
        orderManager.unlockNewDrinksBasedOnIngredents(Ingredent.ingredentColor.GREEN);
        orderManager.unlockNewDrinksBasedOnIngredents(Ingredent.ingredentColor.BLUE);
        //mapManager.DEBUGlockAllLocations();
        mapManager.DEBUGUnlockAllLocations();
        //mapManager.unlockLocation("HOME");
        //mapManager.unlockLocation("BOROUGH");
        //mapManager.unlockLocation("LOWTOWN");
        seatIndexer = 1;
        changeSelectedSeat();
    }

    void Update()
    {    
        for (int i = 0; i < Seats.Length; i++)
        {
            if (Seats[i].ThisSeatsRespawnState == Seat.seatRespawnState.NEEDSRESPAWN) //Seats[i].IsReadyForRespawn == true
            {
                replaceBarPeople(i);
            }
           else if (Seats[i].ThisSeatsRespawnState == Seat.seatRespawnState.NEEDSCLEAR) //Seats[i].IsNeedClear == true
            { 
                clearASeat(Seats[i]);
            }

        }

    }

    private void replaceBarPeople(int personToReplace)
    {
        if (Pmanager.PatronsForTheDay.Count > 0)
        {
            Patron p = Pmanager.drawAPatron();
            p.OrderThePatronWants = orderManager.makeAnOrder();
            Seats[personToReplace].FillSeat(p);
        }
    }

    public void clearASeat(Seat seatToClear) // this may need a better name. 
    {
        seatToClear.ThisSeatsRespawnState = Seat.seatRespawnState.EMPTY;
        TimeManager.progressSundownMeter();
        if (Pmanager.PatronsForTheDay.Count == 0)
        {
            checkIfBarIsEmpty();
            seatToClear.IsTimerPaused = true;  // HACK
        }

    }


    private void checkIfBarIsEmpty()
    {
        bool isBarEmpty = true;
        foreach (Seat s in Seats)
        {
            if (s.patron != null) // checks if our animation is done before ending the day   s.patron!=null gets it working, but transitions are a bit tooo fast! s.currentAnimationState != Seat.animationStates.NONE
            {
                isBarEmpty = false;
                break;
            }      
        }

        if (isBarEmpty)
        {
            endTheDay();
        }
       
    }


    public BarManager()
    {

        patronHighlighted = new PatronHighlighted(this);
        patronClicked = new PatronClicked(this);
        barPaused = new BarPaused(this);

        barManagerState = patronHighlighted;
    }

    public void setBarState(IBarManagerState newBarManagerState)
    {
        barManagerState = newBarManagerState;
    }


    public void MouseOverPatron(Seat pickedSeat)
    {
        barManagerState.MouseOverPatron(pickedSeat); 
    }

    public void ClickPatron()
    {
        barManagerState.ClickPatron();

    }

    //public void MouseHasBeenReleased()
    //{
    //    barManagerState.releaseMouse();
    //    //if (FillableMug.currentMugBeingDragged != null) // kinda duct tape, ensures that there is a mug being draged in order to drop it.
    //    //{
    //    //    Debug.Log("on end drag has been reached");
    //    //   FillableMug.currentMugBeingDragged.OnEndDrag();

    //    //}
    //}

    public void changeSelectedSeat()
    {
        theBarsTaps.hideTapSystem();
        selectedSeat = Seats[seatIndexer];
        moveCameraToNewLocation(selectedSeat.transform.position);
    }


    public void MakeDrink(byte itemSlotToUse, Drink targetDrink)
    {
        barManagerState.MakeDrink(itemSlotToUse, targetDrink);
        SoundManager.Instance.AddCommand("AddIngredent");
    }

    public void sellDrink()
    {
        OrderManager.orderAccuracy accuracyOfDrink = orderManager.determineDrinkPrice(selectedSeat.patron.OrderThePatronWants, FillableMug.currentMugBeingFilled.DrinkInMug);
        int moneyEarnedFromDrink = 0; 

        switch(accuracyOfDrink)
        {
            case OrderManager.orderAccuracy.CORRECT:
                {
                    moneyEarnedFromDrink = FillableMug.currentMugBeingFilled.DrinkInMug.CorrectPrice;
                    shareRumor();
                    SoundManager.Instance.AddCommand("Pay");
                    break;
                }

            case OrderManager.orderAccuracy.MIXUP:
                {
                    moneyEarnedFromDrink = FillableMug.currentMugBeingFilled.DrinkInMug.MixUpPrice;
                    checkIfPatronSharesRumor();
                    SoundManager.Instance.AddCommand("Mix Up");
                    break;
                }

            case OrderManager.orderAccuracy.NONE:
                {
                    SoundManager.Instance.AddCommand("No");
                    break;
                }
        }
            Pmanager.putAPatronBack(selectedSeat.patron); // need to find a new home for this, Not sure where. Need to see what team wants, if we have termination nodes or something
            inventoryManager.addGold(moneyEarnedFromDrink); // looking for an after action take methoid or state. 
            
    }

    public void serveDrink()
    {
        if (FillableMug.currentMugBeingFilled != null)
        {
            sellDrink();
            SelectedSeat.ConsumeBeverage(FillableMug.currentMugBeingFilled.DrinkInMug);
            FillableMug.currentMugBeingFilled.DrinkInMug.clearIngredentsInDrink();
            theBarsTaps.hideTapSystem();
        }

    }

    public void checkIfPatronSharesRumor()  // Added 7/19/17 not sure if this is any good. Checks to see if the patron spills the beans, if so, a quest is added to the rumor mill and it tells the seat to play a specal diolouge from a special function, and that the guy no longer has a rumor
    {
            byte chanceOfSharedRumor = (byte)Random.Range(1, 3);  // not final on algorithum. 
            if (chanceOfSharedRumor == 2)
            {
                shareRumor();
            }
    }

    private void shareRumor()
    {
        if (selectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.RUMOR)
        {
            selectedSeat.PatronSharesARumor(); // uses the new added function to give the player a specefic diolouge about quests, may have a paramiter at some point to give name of quest or a few details. 
            Rumor rumorToShare = rumorManager.getRandomRumorFromWarehouseByLevel(selectedSeat.patron.Level);
            rumorBoard.labelPatronRumorBoard(rumorToShare);
            rumorBoard.activatePatronRumorBoard();
            setBarState(barIsPaused()); // may need a new barstate for this guy. 
            isTimePaused(true);
        }
    }
    
    public void addQuestToWorldMap(byte indexer)
    {
        Quest questToSet = rumorBoard.selectQuestFromOptions(indexer);
        mapManager.setQuestAtItsRegion(questToSet);
        setBarState(getYesHighlight());
        isTimePaused(false);
        rumorBoard.deActivatePatronRumorBoard();
    }

    public void recycleDrink()
    {
        inventoryManager.refundIngredents(FillableMug.currentMugBeingFilled.DrinkInMug);
        FillableMug.currentMugBeingFilled.DrinkInMug.clearIngredentsInDrink();
    }

    public void startNextDay()
    {
        TimeManager.startNewDay();
        isTimePaused(false);
        endOfDayManagement.closeEndOfDayScreen();
        mapManager.TimeProgressesForQuests(); 
        passAllFinishedPatronsToPatronManager();  // all idle adventurers return to regulars for further instuction
        checkIfAdventurersShouldSpawn(); 
        Pmanager.preparePatronsForDay();
        TimeManager.getTheNumberOfPatronsForTheDay((byte)Pmanager.PatronsForTheDay.Count);
    }

   
    #region swapCommands
    public IBarManagerState getYesHighlight()
    {
        return patronHighlighted;
    }


    public IBarManagerState getYesClick()
    {
        return patronClicked;
    }

    public IBarManagerState barIsPaused()
    {
        return barPaused;
    }

    #endregion

    private void endTheDay()
    {
        AquirePatronManagerInformationForEndOfDayManager(); 
        recycleDrink(); // throws away current drink, possibly refunds ingredents? need to ask design when the great big drink patch comes in. 
        endOfDayManagement.setInventoryForEndOfTheDayShop(storeManager.giveInvintoryForTheDay());
        endOfDayManagement.passTimeForQuests(); // passes time on our quests, removes quests who's time has expired.
        endOfDayManagement.pullUpEndOfDayScreen(); // pulls up end of day screen
        Debug.Log("Our bar is empty, Pulling Up Manager");
    }

    public void AquirePatronManagerInformationForEndOfDayManager() // I don't know if this is right, It asks the patronManager to directly give the list of patrons to the end of the day manager. 
    {
        endOfDayManagement.AllPatronsTheBartenderKnows = Pmanager.AllKnownPatrons;
    }

    public void acceptAdventure()
    {

       // if (inventoryManager.Gold - mapManager.deployStateScript.getAdventureCost >= 0) 
        //{
           // inventoryManager.payGold(mapManager.deployStateScript.getAdventureCost);  

            SelectedSeat.TalkWithPatron(); // hacky, tells our patron to deliver text after being sent out, I would rather see this in IbarStateManager, but it has to go here, because map obstructs text box. 
            selectedSeat.patron.IsOnQuest = true;
            mapManager.FinishTaskOnMap();
            SelectedSeat.patronPreparesToLeave();
            closeAdventureMap(); // closes the book
       // }
                           
    }
  
    public void closeAdventureMap()
    {
        isTimePaused(false);
        mapManager.closeMapProps();
        barManagerState.panOut(); // I don't love this, I gave each bar state a pan in and a pan out, I feel this forces functionality. There are better ways im sure, but there are also worse,,, Ill add 5 tech points and sit in the cornner
        setBarState(getYesHighlight());
       
    }


    public void turnPageInBattleReport()
    {
        battleReportManager.flipPageInBattleReport();
        switch (battleReportManager.currentPageOfReport)
        {
            case BattleReportManager.ReportPages.REWARDS:
                {

                    foreach (StoreableItem s in battleReportManager.RewardsToRedeem)
                    {
                        inventoryManager.addItemToInvintory(s);
                    }

                    foreach (Unlocker u in battleReportManager.UnlockersToRedeem)
                    {
                        switch (u.WhatDoesThisUnlock)
                        {
                            
                            case Unlocker.WhatUnlocks.PATRON:
                                {
                                    Pmanager.unlockNewPatronAndAdd(u.NameOfThingToUnlock);
                                    break;
                                }

                            case Unlocker.WhatUnlocks.RUMOR:
                                {
                                    rumorManager.unlockRumor(u.NameOfThingToUnlock);
                                    break;
                                 }

                            case Unlocker.WhatUnlocks.LOCATION:
                                 {
                                    mapManager.unlockRegion(u.NameOfThingToUnlock);
                                    break;
                                }
                        }
                    }
                    break;
                }

                case BattleReportManager.ReportPages.LEVEL:
                {
                    break;
                }

            case BattleReportManager.ReportPages.CLOSED:
                {
                    foreach (Quest q in battleReportManager.QuestsToCheckForRepeat)
                    {
                        Debug.Log("From Bar manager Does quest repeat?" + q.StoreRumorAgain);
                        rumorManager.storeRumor(q.RumorID, q.StoreRumorAgain);
                    }
                    isTimePaused(false);
                    battleReportManager.clearQuestRepeatList();
                    setBarState(getYesHighlight());
                    break;
                }
        }     
    }

    public void purchaseItemFromShop()
    {
        if (endOfDayManagement.getPriceofThing() < inventoryManager.Gold)  // Hack, used to check gold from currently equipped buttion, I think this should be handled in the storemanager instead. 
        {
            inventoryManager.payGold(endOfDayManagement.getPriceofThing());
            endOfDayManagement.purchaseThing();
            // increase price of all dispencers
            orderManager.unlockNewDrinksBasedOnIngredents(storeManager.dispencersToBuy[endOfDayManagement.getIdentifier()].getThisDispencersColor()); // HACK
        }

        // tell the player that they don't have the money
    }


    public void passAllFinishedPatronsToPatronManager()
    {
        for (byte i = 0; i < mapManager.QuestingPatrons.Count; i++)
        {
            if (!mapManager.QuestingPatrons[i].IsOnQuest)
            {
                Pmanager.putAPatronBack(mapManager.QuestingPatrons[i]);
                mapManager.removePatronFromQuestingList(mapManager.QuestingPatrons[i]);
                i--;
            }
        }
    }

    public void isTimePaused(bool yesNo)
    {
        foreach (Seat s in Seats)
        {
            s.pauseThisSeat(yesNo);
        }
    }

    public void panBarLeft()
    {
        seatIndexer--;
        if (seatIndexer < 0) { seatIndexer = 0; }
            selectedSeat.cutOffPatronsSentence();
            changeSelectedSeat();
            // patron barks a hello
    }

    public void panBarRight()
    {
        seatIndexer++;
        if (seatIndexer > Seats.Length -1) { seatIndexer = (sbyte)(Seats.Length - 1); }
        selectedSeat.cutOffPatronsSentence();
        changeSelectedSeat();
    }

    private void moveCameraToNewLocation(Vector3 selectedSeatsLocation)
    {
        Camera.main.GetComponent<CameraManager>().PanToLocation(selectedSeatsLocation);
    }
    private void checkIfAdventurersShouldSpawn()
    {
        Pmanager.CanWeSpawnAdventurers = mapManager.areThereAnyAdventuresForPatrons();
    }

 


    

}
