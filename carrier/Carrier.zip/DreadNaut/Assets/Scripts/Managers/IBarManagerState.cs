﻿using UnityEngine;
using System.Collections;
using System;

public interface IBarManagerState  {

    void ClickPatron();
    void MakeDrink(byte slotToUse, Drink targetDrink);
    void PauseBar();
    void panIn();
    void panOut();
}



public class PatronHighlighted : IBarManagerState
{

    BarManager barManager;

    public PatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }

    public void ClickPatron()
    {
       // TODO: Our conversations need to reset themselves after compleetion

        switch (barManager.SelectedSeat.patron.currentActivity)
        {
            case Patron.whatDoTheyWantToDo.TURNIN:
                {
                    barManager.battleReportManager.ReadBattleReport(barManager.SelectedSeat.patron);
                    barManager.SelectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
                    barManager.SelectedSeat.patron.QuestToCompleete = null;
                    barManager.setBarState(barManager.barIsPaused());
                    barManager.SelectedSeat.TalkWithPatron();
                    break;
                }

            case Patron.whatDoTheyWantToDo.ADVENTURE:
                {
                    panIn();
                    barManager.mapManager.mapOpenFromBar(barManager.SelectedSeat.patron);
                    barManager.setBarState(barManager.barIsPaused());
                    break;
                }

            case Patron.whatDoTheyWantToDo.CONVERSE:
                {
                    barManager.SelectedSeat.patron.CurrentConversation = barManager.conversationWarehouse.getRandomConversationBasedOnPatronID(barManager.SelectedSeat.patron.ID);
                    barManager.setBarState(barManager.patronIsConversing());
                    barManager.SelectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
                    barManager.SelectedSeat.TalkWithPatron();
                    break;
                }

            case Patron.whatDoTheyWantToDo.DRINK:
                {
                    barManager.SelectedSeat.TalkWithPatron();

                    if (barManager.SelectedSeat.CanDrink)
                    {
                        barManager.theBarsTaps.showTapSystem();
                    }
                    break;
                }

            case Patron.whatDoTheyWantToDo.RUMOR:
                {
                    if (barManager.rumorManager.getNumberOfRumorsLeftInCharacter(barManager.SelectedSeat.patron.ID) == 0)
                    {
                        barManager.SelectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.CONVERSE;
                        ClickPatron();
                        break;
                    }
                    else
                    {
                        Rumor rumorToShare = barManager.rumorManager.getRandomRumorFromWarehouseByCharacter(barManager.SelectedSeat.patron.ID);
                        barManager.SelectedSeat.patron.CurrentConversation = barManager.conversationWarehouse.getSpecificConversationFromLoader(barManager.SelectedSeat.patron.ID, rumorToShare.RumorName);
                        barManager.rumorBoard.labelPatronRumorBoard(rumorToShare);
                        barManager.setBarState(barManager.patronIsConversing());
                        barManager.SelectedSeat.TalkWithPatron();
                        break;
                    }
                }
        }
        
    }

    public void MakeDrink(byte SlotToUse, Drink targetDrink)
    {
        targetDrink.addIngredentToDrink(barManager.inventoryManager.useIngredentFromInvintory(SlotToUse));
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
      
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

}




    public class BarPaused : IBarManagerState    
{

    BarManager barManager;


    public BarPaused(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {
       
    }

    public void ClickPatron()
    {
      
    }

    public void MakeDrink(byte slotToUse, Drink targetDrink)
    {

    }

    public void PauseBar()
    {
        
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
      //  Camera.main.GetComponent<CameraManager>().ZoomOut();
    }
}


    public class PatronConversing : IBarManagerState
{

    BarManager barManager;

    public PatronConversing(BarManager barsly)
    {
        barManager = barsly;
    }

    public void ClickPatron()
    {
        if (!barManager.SelectedSeat.patron.CurrentConversation.IsConversationOver) { barManager.SelectedSeat.TalkWithPatron(); }
         
        else
        {
            if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.DRINK)
            {
                Debug.Log("Let's make a drink!");
                barManager.theBarsTaps.showTapSystem();
                barManager.SelectedSeat.TalkWithPatron();
                barManager.setBarState(barManager.noOneInteractedWith());
            }

            if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.RUMOR)
            {
                Debug.Log("Let's talk about quests!");
                barManager.rumorBoard.activatePatronRumorBoard();
                barManager.setBarState(barManager.barIsPaused());
            }

            Debug.Log("This is the name of our current conversation" + barManager.SelectedSeat.patron.CurrentConversation.NameOfThisConversation);
        }

    }

    public void MakeDrink(byte SlotToUse, Drink targetDrink)
    {

    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
        //  Camera.main.GetComponent<CameraManager>().ZoomIn( new Vector3(barManager.SelectedSeat.transform.position.x, barManager.SelectedSeat.PatronsHeight, barManager.SelectedSeat.transform.position.z));
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }


}
