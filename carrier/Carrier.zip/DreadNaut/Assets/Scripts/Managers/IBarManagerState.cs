﻿using UnityEngine;
using System.Collections;
using System;

public interface IBarManagerState  {

    void MouseOverPatron(Seat selectedSeat); 
    void ClickPatron();
    void MakeDrink(byte slotToUse, Drink targetDrink);
    void PauseBar();
    void panIn();
    void panOut();
    //void releaseMouse();
}



public class PatronHighlighted : IBarManagerState
{

    BarManager barManager;

    public PatronHighlighted(BarManager barsly)
    {
        barManager = barsly;
    }



    public void MouseOverPatron(Seat selectedSeat)
    {
        
    }

    public void ClickPatron()
    {
        if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.TURNIN)
        {
            barManager.battleReportManager.ReadBattleReport(barManager.SelectedSeat.patron);
            barManager.isTimePaused(true);
            barManager.SelectedSeat.patron.currentActivity = Patron.whatDoTheyWantToDo.DRINK;
            barManager.SelectedSeat.patron.QuestToCompleete = null;
            barManager.setBarState(barManager.barIsPaused()); 
            barManager.SelectedSeat.TalkWithPatron();
        }

       else if (barManager.SelectedSeat.patron.currentActivity == Patron.whatDoTheyWantToDo.ADVENTURE)
        {
            barManager.isTimePaused(true);
            panIn();
           barManager.mapManager.mapOpenFromBar(barManager.SelectedSeat.patron);
            barManager.setBarState(barManager.barIsPaused());
        }

        else
        {
            if (barManager.SelectedSeat.CanDrink) // has to be a better way of doing this
            {
                barManager.theBarsTaps.showTapSystem();
            }

            barManager.setBarState(barManager.getYesHighlight());
            barManager.SelectedSeat.TalkWithPatron();
        }
    }

    public void MakeDrink(byte SlotToUse, Drink targetDrink)
    {
        targetDrink.addIngredentToDrink(barManager.inventoryManager.useIngredentFromInvintory(SlotToUse));
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
       //  Camera.main.GetComponent<CameraManager>().ZoomIn( new Vector3(barManager.SelectedSeat.transform.position.x, barManager.SelectedSeat.PatronsHeight, barManager.SelectedSeat.transform.position.z));
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    //public void releaseMouse()
    //{
    //    if (FillableMug.currentMugBeingFilled != null && barManager.SelectedSeat.IsHasOrdered)
    //    {
    //        barManager.serveDrink();
    //        FillableMug.currentMugBeingFilled.sendCupToPile();
    //    }
    //   // barManager.SelectedSeat.TalkWithPatron();
    //}
}

public class PatronClicked : IBarManagerState
{

    BarManager barManager;
    

    public PatronClicked(BarManager barsly)
    {
        barManager = barsly;

    }


    public void MouseOverPatron(Seat selectedSeat)
    {
       
    }
    public void ClickPatron()
    {
    }

    public void MakeDrink(byte slotToUse, Drink targetDrink)
    {
       
    }

    public void PauseBar()
    {
        barManager.setBarState(barManager.barIsPaused());
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
        throw new NotImplementedException();
    }

    //public void releaseMouse()
    //{

    //}
}

public class BarPaused : IBarManagerState    
{

    BarManager barManager;


    public BarPaused(BarManager barsly)
    {
        barManager = barsly;

    }

    public void ClearPatronHighlight()
    {
       
    }

    public void MouseOverPatron(Seat selectedSeat)
    {
       
    }
    public void ClickPatron()
    {
      
    }

    public void MakeDrink(byte slotToUse, Drink targetDrink)
    {

    }

    public void PauseBar()
    {
        
    }

    public void panIn()
    {
        throw new NotImplementedException();
    }

    public void panOut()
    {
      //  Camera.main.GetComponent<CameraManager>().ZoomOut();
    }


    //public void releaseMouse()
    //{
    //}
}
