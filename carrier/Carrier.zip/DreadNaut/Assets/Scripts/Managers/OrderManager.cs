﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI; 

public class OrderManager : MonoBehaviour {

    private List<Drink> allLockedDrinksInGame = new List<Drink>();
    private DrinkLoader dLoader = new DrinkLoader();


    private List<Drink> allDrinksTheBartenderKnows = new List<Drink>();
    private List<Ingredent.ingredentColor> allUnlockedIngredentColors = new List<Ingredent.ingredentColor>();
    public enum OrderOptions { BYNAME, BYCOLOR, BYWITHOUTCOLOR,BYFLAVOR, LENGTH }

    private string[] drinkNames = new string[16];

    public enum orderAccuracy {NONE,MIXUP, CORRECT};

    [SerializeField]
    Image[] allQuestionMarkBlocks = new Image[16]; // only problem with this is that I need to know order of drinks and load them in in proper order... I need to find a more dynamic way of doing this thing. 

    public void init()
    {
        dLoader.loadTools();
        allLockedDrinksInGame = dLoader.populateDrinkCollection();
        loadDrinkNames();
    }


    private Drink chooseRandomDrink()
    {
       int orderNumber = Random.Range(0, allDrinksTheBartenderKnows.Count);  //drinkCollection

        return allDrinksTheBartenderKnows[orderNumber];   //drinkCollection
    }

    public void unlockNewDrinksBasedOnIngredents(Ingredent.ingredentColor newIngredentColor)
    {
        Debug.Log("Unlocking color" + newIngredentColor.ToString());
        allUnlockedIngredentColors.Add(newIngredentColor);
        checkForNewDrinks();
    }

    private void checkForNewDrinks()
    {
        bool isDrinkAddable;
        bool isIngredentFound;
        for (int j = 0; j < allLockedDrinksInGame.Count; j++)
        {
            isDrinkAddable = true;
   
            for (Ingredent.ingredentColor i = 0; i < Ingredent.ingredentColor.LENGTH; i ++)
            {
                isIngredentFound = false;
                if (allLockedDrinksInGame[j].DrinkIngredents[(byte)i] == 0)
                {
                    continue;
                }
                
                for (int k = 0; k < allUnlockedIngredentColors.Count; k++)
                {
                    if (i == allUnlockedIngredentColors[k])
                    {
                        isIngredentFound = true;
                        break;
                    }

                }

                if (!isIngredentFound)
                {
                    isDrinkAddable = false;
                    break;
                }
               

            }
            if (isDrinkAddable)
            {
                //Debug.Log("FoundDrinkOfName" + allLockedDrinksInGame[j].DrinkName);
                allDrinksTheBartenderKnows.Add(allLockedDrinksInGame[j]);
                hideQuestionMarkOnDrinkChart(allLockedDrinksInGame[j].DrinkName);
                allLockedDrinksInGame.RemoveAt(j);
                j--;
            }
        }
    }

    private void loadDrinkNames() 
    {
        for( int i = 0; i < allLockedDrinksInGame.Count; i++)
        {
            drinkNames[i] = allLockedDrinksInGame[i].DrinkName;
            allQuestionMarkBlocks[i].gameObject.SetActive(true);
        }
    }

    private void hideQuestionMarkOnDrinkChart(string drinkUnlocked)
    {
      for (int i = 0; i < drinkNames.Length; i++)
        {
            if (drinkUnlocked == drinkNames[i])
            {
                allQuestionMarkBlocks[i].gameObject.SetActive(false);
            }
        }
    }


    public orderAccuracy determineDrinkPrice(IOrder PatronOrder, Drink drinkMade) 
    {
        Drink drinkFromDatabase = findDrinkInDataBase(drinkMade);

        if (drinkFromDatabase == null)
        {
            Debug.Log("This drink dosen't even exist");
            SoundManager.Instance.AddCommand("No");
            return orderAccuracy.NONE;
        }

        if (PatronOrder.checkAccuracy(drinkFromDatabase))
        {
            Debug.Log("Correct Drink");
            SoundManager.Instance.AddCommand("Pay");
            drinkMade.CorrectPrice = drinkFromDatabase.CorrectPrice;
            return orderAccuracy.CORRECT;
        }
        else
        {
            Debug.Log("Mix up");
            SoundManager.Instance.AddCommand("Mix Up");
            drinkMade.MixUpPrice = drinkFromDatabase.MixUpPrice;
            return orderAccuracy.MIXUP;
        }

    }

    private Drink findDrinkInDataBase (Drink drinkToFind)
    {
        
        bool canDrinkBeReturned;
        foreach (Drink d in allDrinksTheBartenderKnows)
        {
           canDrinkBeReturned = true;
            if (d.NumberOfIngredentsInDrink != drinkToFind.NumberOfIngredentsInDrink)
            {
                continue;
            }

            else
            {
                for (int i = 0; i < d.DrinkIngredents.Length; i++)
                {
                    if (d.DrinkIngredents[i] != drinkToFind.DrinkIngredents[i])
                    {
                        canDrinkBeReturned = false;
                        break;
                    }
                }
                if (canDrinkBeReturned)
                {
                     return d;
                }
            }
        }

        return null;

    }

    public IOrder makeARandomOrder()
    {
        int randomNumber = Random.Range(0, 5);
        return (makeSpecificOrder((OrderOptions)randomNumber));
    }

    public IOrder makeSpecificOrder(OrderOptions requestedOrder)
    {
        
        switch (requestedOrder)
        {
            case OrderOptions.BYNAME:
                {
                    return new OrderByName(chooseRandomDrink());
                  
                }
            case OrderOptions.BYFLAVOR:
                {
                    return new OrderByFlavor(chooseRandomDrink().ThisDrinksFlavor);
                   
                }
            case OrderOptions.BYCOLOR:
                {
                    return new OrderByIngredent(chooseRandomIngredentFromKnownIngredents());
                 
                }

            case OrderOptions.BYWITHOUTCOLOR:
                {
                    return new OrderByLackOfIngredent();
                   
                }

            default:
                {
                    return new OrderByName(chooseRandomDrink());
                 
                }
        }
    }

    private Ingredent.ingredentColor chooseRandomIngredentFromKnownIngredents()
    {
        int randomNumber = Random.Range(0, allUnlockedIngredentColors.Count);
        return allUnlockedIngredentColors[randomNumber];
    }

    #region drinkAccessors
    
    public Drink getDrinkByName(string nameOfDrinkToFind)
    {
        foreach (Drink D in allDrinksTheBartenderKnows)
        {
            if (D.DrinkName == nameOfDrinkToFind)
            {
                return D;
            }
        }

        return null;
    }
    #endregion
}
