﻿using UnityEngine;
using System.Collections;

public class InputManager : MonoBehaviour {

    CommandWithUndo command;

    public BarManager barManager;

    bool isMouseHeldDown = false; 

    // Update is called once per frame
    void Update()
    {
        command = null;
        scanForMouseDown();
        scanForMouseUp();
    }


    private bool ScanForPatron() 
    {
        Vector2 v = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        Collider2D[] col = Physics2D.OverlapPointAll(v);


        if (col.Length > 0)
        {
            foreach (Collider2D c in col)
            {
                if (c.GetComponent<Seat>() != null)
                {
                    return true;
                }
            }
        }
       return false;
    }

    private void scanForMouseUp()
    {
        if (Input.GetMouseButtonUp(0) && isMouseHeldDown)
        {
            isMouseHeldDown = false;
        }
    }

    private void scanForMouseDown()
    {
        if (Input.GetMouseButtonDown(0) && !isMouseHeldDown)
        {
            isMouseHeldDown = true;
            if (ScanForPatron())
            {
                 command = new ScanForPatron();
                ActivateCommand(command);
            }
        }
    }

    #region QuestChoiceCommands

    public void selectQuestOption0()
    {
        command = new SelectQuestOption(0);
        ActivateCommand(command);
    }

    public void selectQuestOption1()
    {
        command = new SelectQuestOption(1);
        ActivateCommand(command);
    }
    #endregion

    #region DrinkCommands

    public void DispencerButtonPressed(byte inventoryIndex, Drink targetDrink)
    {
        command = new AddIngredentFromInvintory(inventoryIndex, targetDrink);
        ActivateCommand(command);
    }

    public void recycleDrinkButtonClicked()
    {
        command = new RecycleDrink();
        ActivateCommand(command);
    }

    public void serveDrink()
    {
        command = new ServeDrink();
        ActivateCommand(command);
    }

    #endregion


    #region EndOfDayManagementIndexerButtons
    public void endOfDayButton0()
    {
        command = new GetInfoFromEndOfDayButton(0);
        ActivateCommand(command);
    }

    public void endOfDayButton1()
    {
        command = new GetInfoFromEndOfDayButton(1);
        ActivateCommand(command);
    }

    public void endOfDayButton2()
    {
        command = new GetInfoFromEndOfDayButton(2);
        ActivateCommand(command);
    }

    public void endOfDayButton3()
    {
        command = new GetInfoFromEndOfDayButton(3);
        ActivateCommand(command);
    }

    public void endOfDayButton4()
    {
        command = new GetInfoFromEndOfDayButton(4);
        ActivateCommand(command);
    }

    public void endOfDayButton5()
    {
        command = new GetInfoFromEndOfDayButton(5);
        ActivateCommand(command);
    }

    #endregion

    #region questBookHooks
   

    public void decrementQuestBookPage()
    {
        command = new DecrementQuestBookPage();
        ActivateCommand(command);
    }

    public void IncrementQuestBookPage()
    {
        command = new IncrementQuestBookPage();
        ActivateCommand(command);
    }
    #endregion

    public void acceptAdventure()
    {
        command = new AcceptAdventure();
        ActivateCommand(command);
    }


    public void closeAdventureMap()
    {
        command = new CloseAdventureMap();
        ActivateCommand(command);
    }

   

    #region EndOfDayManagementCommands

    public void switchToPatronScreen()
    {
        command = new SwitchToPatronScreen();
        ActivateCommand(command);
    }

    public void switchToRumorScreen()
    {
        command = new SwitchToRumorScreen();
        ActivateCommand(command);
    }

    public void switchToShopScreen()
    {
        command = new SwitchToShopScreen();
        ActivateCommand(command);
    }

    public void scrollUpInEndOfDay()
    {
        command = new ScrollBarUp();
        ActivateCommand(command);
    }

    public void scrollDownInEndOfDay()
    {
        command = new ScrollEndOfDayMenuDown();
        ActivateCommand(command);
    }

    public void startNextDay()
    {
        command = new StartNextDay();
        ActivateCommand(command);
    }
    #endregion

    #region rumorPageQuestButtons

    // Marking these for removal
    public void addQuestToBook()
    {
        command = new AddQuestToBook();
        ActivateCommand(command);
    }

    public void doNoAddQuestToBook()
    {
        command = new DoNotAddQuestToBook();
        ActivateCommand(command);
    }

    public void scrollLeftInQuestsAtLocation()
    {
        command = new ScrollLeftInQuestsAtLocation();
        ActivateCommand(command);
    }

    public void scrollRightInQuestAtLocation()
    {
        command = new ScrollRightInQuestsAtLocation();
        ActivateCommand(command);
    }
    #endregion

    #region StoreButtons

    public void purchaseStoreItem()
    {
        command = new PurchaseItemFromShop();
        ActivateCommand(command);
    }
    #endregion


    public void scrollLeftInBar()
    {
        command = new ScrollLeftInBar();
        ActivateCommand(command);
    }

    public void scrollRightInBar()
    {
        command = new ScrollRightInBar();
        ActivateCommand(command);
    }
    public void closeBattleReport()
    {
        command = new CloseBattleReport();
        ActivateCommand(command);
    }

    private void ActivateCommand(Command command)
    {
        Debug.Log(command);
        command.Execute(barManager);
    }

}
