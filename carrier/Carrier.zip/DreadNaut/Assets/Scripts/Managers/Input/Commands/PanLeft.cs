﻿using UnityEngine;
using System.Collections;

public class PanLeft : CommandWithUndo
{



    public PanLeft() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
       //Camera.main.GetComponent<CameraManager>().panLeft();
    }
}

