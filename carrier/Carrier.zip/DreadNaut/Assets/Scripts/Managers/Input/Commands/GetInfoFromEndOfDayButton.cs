﻿using UnityEngine;
using System.Collections;

public class GetInfoFromEndOfDayButton : CommandWithUndo
{

    byte slotToFind;

    public GetInfoFromEndOfDayButton(byte invintorySlot) : base()
    {
        slotToFind = invintorySlot;
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.ShowStatsOnPage(slotToFind);
        }
        base.Execute(Bar);
    }
}
