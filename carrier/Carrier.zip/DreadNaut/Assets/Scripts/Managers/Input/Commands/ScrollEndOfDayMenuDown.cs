﻿using UnityEngine;
using System.Collections;

public class ScrollEndOfDayMenuDown : CommandWithUndo
{



    public ScrollEndOfDayMenuDown() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.ScrollDown();
        }
        base.Execute(Bar);
    }
}