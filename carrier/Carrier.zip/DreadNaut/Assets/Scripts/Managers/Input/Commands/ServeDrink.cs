﻿using UnityEngine;
using System.Collections;

public class ServeDrink : CommandWithUndo
{


    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
          target.serveDrink();
        }
        base.Execute(Bar);
    }
}

