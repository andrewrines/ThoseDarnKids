﻿using UnityEngine;
using System.Collections;

public class MouseHasBeenReleased : CommandWithUndo
{


public override void Execute(BarManager Bar)
{
    var target = Bar.GetComponent<BarManager>();
    if (target is BarManager)
    {

      // target.MouseHasBeenReleased();
    }
    base.Execute(Bar);
}
}
