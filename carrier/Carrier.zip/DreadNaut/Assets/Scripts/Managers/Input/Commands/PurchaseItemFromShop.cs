﻿using UnityEngine;
using System.Collections;

public class PurchaseItemFromShop : CommandWithUndo
{


    public PurchaseItemFromShop() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        Bar.purchaseItemFromShop();
    }
}

