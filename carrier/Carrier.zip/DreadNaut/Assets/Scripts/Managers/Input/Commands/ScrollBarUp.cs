﻿using UnityEngine;
using System.Collections;

public class ScrollBarUp : CommandWithUndo
{



    public ScrollBarUp() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.ScrollUp();
        }
        base.Execute(Bar);
    }
}

