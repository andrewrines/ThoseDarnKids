﻿using UnityEngine;
using System.Collections;

public class SelectQuestOption : CommandWithUndo {

    byte indexer;
    public SelectQuestOption(byte indexer) : base()
    {
        this.indexer = indexer;
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.addQuestToWorldMap(indexer);
        }
        base.Execute(Bar);
    }
}
