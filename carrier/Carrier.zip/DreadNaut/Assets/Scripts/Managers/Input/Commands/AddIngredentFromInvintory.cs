﻿using UnityEngine;
using System.Collections;

public class AddIngredentFromInvintory : CommandWithUndo
{

    byte slotToFind;
    Drink targetDrink;

    public AddIngredentFromInvintory(byte invintorySlot, Drink _targetDrink) : base()
    {
        slotToFind = invintorySlot;
        targetDrink = _targetDrink;
    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.MakeDrink(slotToFind, targetDrink);
        }
        base.Execute(Bar);
    }
}
