﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Text;

public class BattleReportManager : MonoBehaviour {  // REPEAT TYPE DOSENT WORK FIX NOW!!!

    //public ApperanceManager apperanceManager;
    [SerializeField]
    GameObject BattleReportPannel;
    [SerializeField]
    Text QuestTitleText;
    [SerializeField]
    Text WinOrLose; // to be replaced with art
    [SerializeField]
    Text RecapText;
    [SerializeField]
    Button RedeemRewardsButton;
    public Image[] rewardImage = new Image[5];
    public Text[] howMuchOfRewardText = new Text[5];
    private List<StoreableItem> rewardsToRedeem = new List<StoreableItem>();
    public List<StoreableItem> RewardsToRedeem { get { return rewardsToRedeem; } }
    private List<Unlocker> unlockersToRedeem = new List<Unlocker>();
    public List<Unlocker> UnlockersToRedeem { get { return unlockersToRedeem; } }
    public enum ReportPages {OPEN, SUMMARY, OUTCOME,REWARDS,LEVEL, CLOSED};
    public ReportPages currentPageOfReport;
    private string questTitle;
    private string patronsName;

    private List<Quest> questsToCheckForRepeat = new List<Quest>();
    public List<Quest> QuestsToCheckForRepeat { get { return questsToCheckForRepeat; } }

    private string checkListForOutcomePage; // Kind of a hack; 
    private string expListForOutcomePage; // also kind of a hack; 


     public void ReadBattleReport(Patron patronCarryingPaystub)
    {
        currentPageOfReport = ReportPages.OPEN;
        BattleReportPannel.SetActive(true);
        patronsName = patronCarryingPaystub.Name;
        flipPageInBattleReport();

        for (int i = 0; i < patronCarryingPaystub.QuestsToCompleete.Count; i++)
        {
            if (patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() == Quest.questStatus.PASS)
            {
                foreach (StoreableItem s in patronCarryingPaystub.QuestsToCompleete[i].RewardsFromQuest)
                {
                    rewardsToRedeem.Add(s); // no sorting yet 
                }
                
            }
            checkListForOutcomePage += patronCarryingPaystub.QuestsToCompleete[i].QuestName + " : " + patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() + "\n";

            if (patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() == Quest.questStatus.PASS || patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() == Quest.questStatus.FAIL)
            {
                checkForUnlockables(patronCarryingPaystub.QuestsToCompleete[i]);
                checkIfRumorRepeats(patronCarryingPaystub.QuestsToCompleete[i]);
                patronCarryingPaystub.QuestsToCompleete[i].setToRedeemed();
            }

            if (patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() == Quest.questStatus.PASS || patronCarryingPaystub.QuestsToCompleete[i].getQuestStatus() == Quest.questStatus.REDEEMED) // Super HACK, Ill clean this up after TAGF
            {
                patronCarryingPaystub.ExperiencePointsGainedOnThisQuest = patronCarryingPaystub.QuestsToCompleete[i].ExpToAward;
                expListForOutcomePage += patronCarryingPaystub.QuestsToCompleete[i].QuestName + " : " + patronCarryingPaystub.QuestsToCompleete[i].ExpToAward;
                patronCarryingPaystub.gainEXP();
            }
            else
            {
                expListForOutcomePage += patronCarryingPaystub.QuestsToCompleete[i].QuestName + " : " +  0;
            }

        }
       
    }

    public void flipPageInBattleReport()
    {
        currentPageOfReport++;
        clearAllText();
        switch (currentPageOfReport)
        {
            case ReportPages.SUMMARY:
                {
                    flipTosummaryPage();
                    break;
                }
                
            case ReportPages.OUTCOME:
                {
                    flipToOutcomePage();
                    break;
                }
            case ReportPages.REWARDS:
                {
                    FlipToRewardsPage();
                    break;   
                }


            case ReportPages.LEVEL:
                {
                    clearAllText();
                    FlipToLevelUpPage();
                    break;
                }

            case ReportPages.CLOSED:
                {
                    clearAllText();
                    closeBattleReport();
                    break;
                }
        }
    }

    private void flipTosummaryPage()
    {
        QuestTitleText.text = "Adventure Summary:";
        WinOrLose.text = patronsName + " is back from their adventue.";
    }

    private void flipToOutcomePage()
    {
        QuestTitleText.text = "Quest outcomes:";
        WinOrLose.text = checkListForOutcomePage;
    }

    private void FlipToRewardsPage()
    {
        QuestTitleText.text = "Rewards:";
         byte numberOfRewards = 0;
        foreach (StoreableItem s in rewardsToRedeem)
        {
            rewardImage[numberOfRewards].gameObject.SetActive(true);
            rewardImage[numberOfRewards].sprite = s.displayArt();
            howMuchOfRewardText[numberOfRewards].text = s.NumberLeft.ToString();
            numberOfRewards++;
            if (numberOfRewards > 5 ) // hack to be fixed
            {
                break;
            }
        }
    }

    private void FlipToLevelUpPage()
    {

        QuestTitleText.text = "EXP gained: ";
        WinOrLose.text = expListForOutcomePage + "EXP";

        //if (questToReportOn.SuccessesOnQuest == questToReportOn.TrialsOfTheQuest.Count)
        //{
        //    grantQuestFinishedEXP();
        //}
        //foreach (Patron p in questToReportOn.PatronsOnQuest)
        //{
        //    WinOrLose.text += p.Name + "+" + p.ExperiencePointsGainedOnThisQuest + "\n";
        //    p.gainEXP(); // converts over ExperiencePointsGainedOnThisQuest to real exp!
        //}
        //QuestTitleText.text = questTitle + ": EXP";
    }


    public void closeBattleReport() 
    {
        rewardsToRedeem.Clear();
        unlockersToRedeem.Clear();
        checkListForOutcomePage = " "; // feel this is hacky, when we close the book, it clears the list of quest and results. 
        expListForOutcomePage = " "; // this too, sorry guys, Ill fix this after we share what we got.
        BattleReportPannel.SetActive(false);
    }

    private void clearAllText()// really need to decide what I want to do with the rewards page. 
    {

       WinOrLose.text = " ";
    // RecapText.text = "";

       foreach (Image i in rewardImage)
        {
            i.gameObject.SetActive(false);
        }
    }

    private string formatText(string textToFormat)  // TODO give public accessTo designer to change how many characters before cut off. And make this a util Tool;
    {
        StringBuilder strBuilder = new StringBuilder(textToFormat);
        int i = 0;
        for (int j = 0; j < textToFormat.Length; j++)
        {
            if (i >= 50 && strBuilder[j] == ' ')
            {
                strBuilder[j] = '\n';
                i = 0;
            }
            i++;
        }
        textToFormat = strBuilder.ToString();
        return textToFormat;
    }

    private void checkForUnlockables(Quest compleetedQuest)
    {
        Unlocker.WhenToUnlock unlockState = Unlocker.WhenToUnlock.LOSE;

        if (compleetedQuest.getQuestStatus() == Quest.questStatus.PASS)
        {
            unlockState = Unlocker.WhenToUnlock.WIN;
        }

        for (int i = 0; i < compleetedQuest.ThingsToUnlock.Count; i++) //each (Unlocker u in compleetedQuest)
        {
            Debug.Log("Quest Unlocker:" + compleetedQuest.ThingsToUnlock[i].WhenIsThisUnlocked + " Circumstance:" + unlockState);
            if (compleetedQuest.ThingsToUnlock[i].WhenIsThisUnlocked == unlockState || compleetedQuest.ThingsToUnlock[i].WhenIsThisUnlocked == Unlocker.WhenToUnlock.WINORLOSE)
            {
                unlockersToRedeem.Add(compleetedQuest.ThingsToUnlock[i]);
            }
        }
    }

    private void checkIfRumorRepeats(Quest questToDesolve)
    {
        Debug.Log("Now Checking" + questToDesolve.QuestName);
        if (questToDesolve.getQuestStatus() == Quest.questStatus.FAIL && questToDesolve.RumorRepeatType == RumorLoader.RepeatableTypes.STORY || questToDesolve.RumorRepeatType == RumorLoader.RepeatableTypes.REPEATABLE)
        {
            questToDesolve.StoreRumorAgain = true;
        }
        questsToCheckForRepeat.Add(questToDesolve);
    }

    public void clearQuestRepeatList()
    {
        questsToCheckForRepeat.Clear();
    }


}
