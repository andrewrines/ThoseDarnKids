﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class PatronScreenOpened : MonoBehaviour, IEndOfDayStates
{

    public EndOfDayManager endOfDayManager;

 
    public Button[] buttonsWithPatronsOnThem = new Button[4];
    private Color[] colorsOfStat = new Color[5];
    public Color PoorStat;
    public Color CommonStat;
    public Color GoodStat;
    public Color GreatStat;
    public Color BestStat;
    public Button scrollUpButton;
    public Button scrollDownButton;
    public Text patronNameText;
    public Text patronFactionText;
    public Text patronStatsText;
    public Text patronLevelText;
    public Text patronEXPText;

    public Text onAdventureBlockNameOfPatron;
    public Text patronBioSheet;

    private Vector2 minCoordinatesForText;
    private Vector2 maxCoordinatesForText;
    public Sprite backDropForPatronPage;
    //public Text onAdventureBlockyQuestName;
    //public Text onAdventureBlockQuestTimeLeft;

    public Image patronPortrait;
    public Image patronPictureFrame;
    public Image awayOnQuestSign;
    

    public Image[] patronTokens = new Image[4]; 

    private int topOfTheListIndexNumber;
    private int bottomOfTheListIndexNumber;

    byte numberOfButtonsTodisplay;

    private void Start()
    {
        setStatColors();
        setDefautltTextPositions();
    }

    public void PatronMenuOpen()
    {
       
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openRumorScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from Patron");
    }

    public void StoreMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openShopScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to store from Patron");
    }

    public void ShowPresetAssets()
    {
        endOfDayManager.backDropForEndOfDayManager.sprite = backDropForPatronPage;
        topOfTheListIndexNumber = 0;
        bottomOfTheListIndexNumber = topOfTheListIndexNumber + buttonsWithPatronsOnThem.Length;
        scrollUpButton.gameObject.SetActive(true);
        scrollDownButton.gameObject.SetActive(true); // might need a better place for these, getting a bit crammped
        patronNameText.gameObject.SetActive(true);
        patronFactionText.gameObject.SetActive(true);
        patronStatsText.gameObject.SetActive(true);
        patronPortrait.gameObject.SetActive(true);
        patronPictureFrame.gameObject.SetActive(true);
        patronLevelText.gameObject.SetActive(true);
        patronEXPText.gameObject.SetActive(true);
        patronBioSheet.gameObject.SetActive(true);

        numberOfButtonsTodisplay = (byte)buttonsWithPatronsOnThem.Length; // here
        if (endOfDayManager.AllPatronsTheBartenderKnows.Count < buttonsWithPatronsOnThem.Length)
        {
            numberOfButtonsTodisplay = (byte)endOfDayManager.AllPatronsTheBartenderKnows.Count;
        }

        for (byte i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithPatronsOnThem[i].gameObject.SetActive(true);
        }
        formatButtonsForThisPage();
        labelButtons();
        ShowStatsOnPage(0);

    }

    public void HidePresetAssets()
    {

        foreach (Button b in buttonsWithPatronsOnThem)
        {
            b.GetComponentInChildren<Text>().text = " ";
            b.GetComponent<Image>().color = Color.white;
            b.gameObject.SetActive(false);
        }
        scrollUpButton.gameObject.SetActive(false);
        scrollDownButton.gameObject.SetActive(false);
        patronNameText.gameObject.SetActive(false);
        patronFactionText.gameObject.SetActive(false);
        patronStatsText.gameObject.SetActive(false);
        patronPortrait.gameObject.SetActive(false);
        patronPictureFrame.gameObject.SetActive(false);
        patronLevelText.gameObject.SetActive(false);
        patronEXPText.gameObject.SetActive(false);
        patronBioSheet.gameObject.SetActive(false);
        deFormatButtonsForThisPage();
        turnOffOnQuestTextBoard();
    }

    public void labelButtons()
    {
        for (int i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithPatronsOnThem[i].GetComponentInChildren<Text>().text = endOfDayManager.AllPatronsTheBartenderKnows[i + topOfTheListIndexNumber].Name + "\n LEVEL: " + endOfDayManager.AllPatronsTheBartenderKnows[i + topOfTheListIndexNumber].Level;
            patronTokens[i].sprite = ApperanceManager.instance.ThisPatronsToken(endOfDayManager.AllPatronsTheBartenderKnows[i + topOfTheListIndexNumber].ID);
            if (endOfDayManager.AllPatronsTheBartenderKnows[i + topOfTheListIndexNumber].IsOnQuest)
            {
                buttonsWithPatronsOnThem[i].GetComponent<Image>().color = Color.gray;
            }
            else
            {
                buttonsWithPatronsOnThem[i].GetComponent<Image>().color = Color.white;
            }
        }
    }

   public void ScrollUp()
    {
        if (topOfTheListIndexNumber > 0)
        {
            topOfTheListIndexNumber--;
            bottomOfTheListIndexNumber--;
            labelButtons();
        }
    }
   public void ScrollDown()
    {
        if(bottomOfTheListIndexNumber < endOfDayManager.AllPatronsTheBartenderKnows.Count)
        {
            topOfTheListIndexNumber++;
            bottomOfTheListIndexNumber++;
            labelButtons();
        }
    }

    public void ShowStatsOnPage(byte whichPatronToIndex)
    {
        int i = whichPatronToIndex + topOfTheListIndexNumber;
        Patron patronToInquireAbout = endOfDayManager.AllPatronsTheBartenderKnows[i];
       patronNameText.text = patronToInquireAbout.Name;
        patronFactionText.text = patronToInquireAbout.thisPatronsAligence.ToString();
        patronLevelText.text = "Level: " + patronToInquireAbout.Level;
        patronEXPText.text = "EXP: " + patronToInquireAbout.ExperiencePoints + "/" + patronToInquireAbout.ExperienceThresholdToNextLevel;

        patronStatsText.text = " ";
        for (Patron.StatTypes j = 0; j <= Patron.StatTypes.SWAY; j++ )
        {
            // patronStatsText.text += j + ": " + endOfDayManager.PatronsInRegulars[i].PatronsStats[(byte)j] + "\n";
            patronStatsText.text += j + ": " + StatDescriptorLoader.Instance.statOut(j, patronToInquireAbout.PatronsBaseStats[(byte)j]) + "\n";
            //patronStatsText.color = colorsOfStat[StatDescriptorLoader.Instance.numberModifyer((int)j, endOfDayManager.PatronsInRegulars[i].PatronsStats[(byte)j])]; 
        }

        patronPortrait.sprite = ApperanceManager.instance.HowThisPatronLooks(patronToInquireAbout.ID);

        if (patronToInquireAbout.IsOnQuest)
        {
            setUpAwayOnQuestTextBoard(patronToInquireAbout);
        }
        else
        {
            turnOffOnQuestTextBoard();
        }

        patronBioSheet.text = "Bio: "+ patronToInquireAbout.Bio;
       // patronPortrait.sprite = ApperanceManager.instance.HowPatronLooks(endOfDayManager.PatronsInRegulars[i].thisPatronsJob); //endOfDayManager.apperanceManager.HowPatronLooks(endOfDayManager.PatronsInRegulars[i].thisPatronsJob);
    }

    private void setUpAwayOnQuestTextBoard(Patron patronToTalkAbout)
    {
        awayOnQuestSign.gameObject.SetActive(true);
        onAdventureBlockNameOfPatron.text = patronToTalkAbout.Name + " is out adventuring";
       // TODO, see what design wants with patron away on quest popups; 
    }

    private void turnOffOnQuestTextBoard()
    {
        awayOnQuestSign.gameObject.SetActive(false);
    }

    public void ShowQuestOnPage(Quest quest)
    {

    }


    public void AddQuestToMap()
    {
       
    }

    public void BackOutOfQuestRumor()
    {
        
    }

    public void turnPageLeftInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void turnPageRightInQuestAtLocation()
    {
        throw new NotImplementedException();
    }

    public void formatButtonsForThisPage()
    {
        for (int i = 0; i < numberOfButtonsTodisplay; i++)
        {
            patronTokens[i].enabled = true;
            buttonsWithPatronsOnThem[i].GetComponentInChildren<Text>().GetComponent<RectTransform>().anchorMin = minCoordinatesForText;
            buttonsWithPatronsOnThem[i].GetComponentInChildren<Text>().GetComponent<RectTransform>().anchorMax = maxCoordinatesForText;
        }
    }

    public void deFormatButtonsForThisPage()
    {
        for (int i = 0; i < numberOfButtonsTodisplay; i++)
        {
            patronTokens[i].enabled = false;
        }
    }

    private void setDefautltTextPositions()
    {
        minCoordinatesForText = buttonsWithPatronsOnThem[0].GetComponentInChildren<Text>().GetComponent<RectTransform>().anchorMin;
        maxCoordinatesForText = buttonsWithPatronsOnThem[0].GetComponentInChildren<Text>().GetComponent<RectTransform>().anchorMax;
    }

    private void setStatColors()
    {
        colorsOfStat[0] = new Color(PoorStat.r, PoorStat.g, PoorStat.b);
        colorsOfStat[1] = new Color(CommonStat.r, CommonStat.g, CommonStat.b);
        colorsOfStat[2] = new Color(GoodStat.r, GoodStat.g, GoodStat.b);
        colorsOfStat[3] = new Color(GreatStat.r, GreatStat.g, GreatStat.b);
        colorsOfStat[4] = new Color(BestStat.r, BestStat.g, BestStat.b);
    }
}
