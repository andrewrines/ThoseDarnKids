﻿using UnityEngine;
using System.Collections;

public class StartingCupLocation : DispencerSlot
{
    GameObject[] cupPool = new GameObject[7];

    [SerializeField]
    GameObject CupPrefabToCreate;


    void Start()
    {
        Init();
    }

    void Init()
    {
        for (int i = 0; i < cupPool.Length; i++)
        {
            cupPool[i] = Instantiate(CupPrefabToCreate);
            cupPool[i].SetActive(false);
        }
    }

    //Ideally there'd be a listener.  When a cup has been moved to a different location
    void Update()
    {
        if(!mugInSlot)
        {
            FillableMug.currentMugBeingFilled = FindAvailableCupFromPool(); // Don't know if this is ok, I would rather encapsilate the use of current mug, but logic is
            FillableMug.currentMugBeingFilled.gameObject.SetActive(true); // once a new mug is drawn, it becomes the current mug being filled,
            FillableMug.currentMugBeingFilled.transform.SetParent(this.transform); // some would argue that we dont even need multiple mugs,
            FillableMug.currentMugBeingFilled.transform.position = this.transform.position; // I would be one of them, as a clean up phase, I wanna try getting down to one mug.
 
        }
    }

    FillableMug FindAvailableCupFromPool()
    {
        GameObject c = FindInactiveCup();
        c.SetActive(false);
        FillableMug currMug = c.GetComponent<FillableMug>();

        if (currMug == null) Debug.Log("There is no 'FillableMug' script attached to the cupPrefab!");
        return currMug;
    }

    GameObject FindInactiveCup()
    {
        for (int i = 0; i < cupPool.Length; i++)
        {
            if (!cupPool[i].activeSelf)
            {
                return cupPool[i];
            }
        }

        Debug.Log("There are no more cups available in the 'CupMaker'. Increase the size of the array");
        return null;
    }


}
