﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Patron {



    private bool isExhausted;
    public bool IsExhausted { get { return isExhausted; } }

    private bool isOnQuest;
    public bool IsOnQuest { get { return isOnQuest; } set { isOnQuest = value; } }

    private List<Quest> questsToCompleete = new List<Quest>();
    public List<Quest> QuestsToCompleete { get { return questsToCompleete; } set { questsToCompleete = value; } }

    private byte id;
    public byte ID { get { return id; } set { id = value; } }


    public enum OpinionOnDrink {AWFUL, BAD, SOSO, GOOD, GREAT, PERFECT}
    private OpinionOnDrink thisPatronsOpinion;


    public enum disposition { STALWART, RESERVED, UPBEAT, DARK, ARROGANT };
    public disposition thisPatronsDisposition;

     //public enum job { WARRIOR = 0, ROUGE, WIZARD, BARD }; // TO REMOVE once I leanr what we plan to do with apperances ( how our guys look and how I find how they look);
     //public job thisPatronsJob; 

    public enum Aligence { COLLEGE, CORPOREAL, AA, EVIL, MAFIA, DAREDEVIL, ARCHAEOLOGICAL, NATURE, NEIGHBORHOOD, BREWMASTER, NONE };
    public Aligence thisPatronsAligence;

    public enum drinkLevel { NONE, LOW, MID, HIGH };
    public drinkLevel thisPatronsTolerance;

    public enum StatTypes { STRONG, SMART, SNEAK, SWAY, LENGTH}

    public enum patienceLevels {LOW,MID,HIGH};
    public patienceLevels thisPatronsPatienceLevel;

    public enum whatDoTheyWantToDo {DRINK, RUMOR, ADVENTURE, TURNIN}
    public whatDoTheyWantToDo currentActivity; 

   

    private string name;
    public string Name { get { return name; } set { name = value; } }

    private byte level;
    public byte Level { get { return level; } set { level = value; } }

    private int experiencePoints;
    public int ExperiencePoints { get { return experiencePoints; } }

    private int experiencePointsGainedOnThisQuest;
    public int ExperiencePointsGainedOnThisQuest { get { return experiencePointsGainedOnThisQuest; } set { experiencePointsGainedOnThisQuest = value; } }

    private int experienceThresholdToNextLevel = 50;
    public int ExperienceThresholdToNextLevel {get { return experienceThresholdToNextLevel; } }

    private float patience;
    public float Patience { get { return patience; } set { patience = value; } }

    private IOrder orderThePatronWants;
    public IOrder OrderThePatronWants {get { return orderThePatronWants; } set { orderThePatronWants = value; } }

    //private Drink drinkThePatronWants = new Drink();
    //public Drink DrinkThePatronWants { get { return drinkThePatronWants; } set { drinkThePatronWants = value; } }

    private sbyte[] patronsBaseStats;
    public sbyte[] PatronsBaseStats { get { return patronsBaseStats; } }

    private sbyte[] patronsFatigueStats;
    public sbyte[] PatronsFatigueStats { get { return patronsFatigueStats; } }


    public Patron(string newName, byte newLevel, Aligence newPatronsAligence, drinkLevel newDrinkLevel, sbyte[] newStats, patienceLevels PatronsPatience, disposition newDisposition)
    {
        name = newName;
        level = newLevel;
        thisPatronsDisposition = newDisposition;
        thisPatronsAligence = newPatronsAligence;
        thisPatronsTolerance = newDrinkLevel;
        patronsBaseStats = newStats;
        patronsFatigueStats = new sbyte[4];
        thisPatronsPatienceLevel = PatronsPatience;
        resetAllPatronStat();
    }


    public byte rollPatronStat(StatTypes statToRoll) // TODO make copy of array for fatigue values, decrement accordingly
    {
        byte patronsRoll = (byte)Random.Range(1, patronsFatigueStats[(int)statToRoll]+1); // +1 is because range is exclusive 
        return patronsRoll; 
    }

    public void fatiguePatron(StatTypes statToFatigue, byte byWhatValue) // Woah!!! Taking heavy fire here!
    {
        patronsFatigueStats[(int)statToFatigue]  = (sbyte)(patronsFatigueStats[(int)statToFatigue] - byWhatValue);
        Debug.Log("stat is currently " + patronsFatigueStats[(int)statToFatigue]);
        if (patronsFatigueStats[(int)statToFatigue] <= 0)
        {
            isExhausted = true;
        }
    }

    public void resetAllPatronStat() // when the patron gets back to the bar, we recover all their stats
    {
        for(int i = 0; i < patronsFatigueStats.Length; i++)
        {
            patronsFatigueStats[i] = patronsBaseStats[i];
        }
        isExhausted = false; 
    }

    //public void recoverPatronStat() for later with our villages
    //{

    //}

    public void reSortQuests() // a classic case of nathan C outsmarting himself. 
    {
        if (questsToCompleete.Count > 1)
        {
            
            Quest questToMoveToBottom = questsToCompleete[0];
            questsToCompleete.RemoveAt(0);
            for (int i = 1; i < questsToCompleete.Count; i++)
            {
                questsToCompleete[i - 1] = questsToCompleete[i];
            }
            questsToCompleete.Add(questToMoveToBottom);

        }
    }


   

    public void gainEXP()   //int howMuchExpToGain
    {
        experiencePoints += experiencePointsGainedOnThisQuest;
        if (experiencePoints >= experienceThresholdToNextLevel)
        {
            levelUp();
        }
        experiencePointsGainedOnThisQuest = 0;
    }

    private void levelUp()
    {
        experiencePoints -= experienceThresholdToNextLevel;
        // increase stats
        level++; // cap at level 6 or whatever the designers want. 
        experienceThresholdToNextLevel = (level +1) * 50; // sets the bar higher for next time!
    }

}


