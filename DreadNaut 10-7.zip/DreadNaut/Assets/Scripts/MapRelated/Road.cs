﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Road : MonoBehaviour
{
    //This class will only contain methods for being highlighted or not being highlighted.  I may not even need a class for it, but I am for now
}
