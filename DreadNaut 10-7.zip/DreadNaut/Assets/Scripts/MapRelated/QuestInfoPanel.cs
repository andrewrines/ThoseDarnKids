﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class QuestInfoPanel : MonoBehaviour
{
    [SerializeField] Text QuestNameTextBox;
    [SerializeField] Text QuestDescriptionTextBox;
    [SerializeField] Text NumberOfPatronsOnQuest;
    [SerializeField] RectTransform QuestInfoRightArrow;
    [SerializeField] RectTransform QuestInfoLeftArrow;

    Location targetLocation;
    byte questIndex = 0;
    //public byte currentQuestIndex { get { return questIndex; } }

    public void InitializeQuestInfoPanel(Location _targetLocation)
    {
        targetLocation = _targetLocation;

        QuestInfoRightArrow.gameObject.SetActive(false);
        QuestInfoLeftArrow.gameObject.SetActive(false);


        if (targetLocation.QuestCountAtLocation > 0)          //If there is at least one quest at this location...
        {
            questIndex = 1;
        }
        else
        {
            questIndex = 0;
        }

        DisplayQuestInfo(questIndex);
        UpdateQuestSelectArrows();

        //pull up a panel, showing all the quests at this location
        //Most of the info about the quest should be displayed in this panel.  Maybe it appears to the right of the screen?
        //Should display name, rewards, description, tasks, and faction alignment
        //      /\ AKA: this could be an exact copy of the card used when choosing the quest in the rumor mill /\

        //When the player clicks on a quest, 'highlightedQuest' is set equal to that quest
        //When the player clicks 'Add Quest,' the quest is added 
    }

    public Quest GetQuestFromLocation()
    {
        if (questIndex > 0)
            return targetLocation.findQuestAtThisLocationByIndex(questIndex - 1);   //Index 0 is "no quest", but the list of quests at the location starts counting at 0.  So, subtract one.  There's probably a more intuitive way of doing this

        return null;
    }

    void UpdateQuestSelectArrows()
    {
        QuestInfoLeftArrow.gameObject.SetActive(questIndex - 1 >= 0);                                       //set the left arrow active if there is at least one more element (previous)
        QuestInfoRightArrow.gameObject.SetActive(questIndex + 1 <= targetLocation.QuestCountAtLocation);    //set the right arrow active if there is at least one more elemnt in the list of quests (+1 slot for "no quest")
    }

    public void DisplayQuestInfo(byte index)
    {
        if(index == 0)
        {
            QuestNameTextBox.text = "Pass through " + targetLocation.Name;

            QuestDescriptionTextBox.text = "Not every passing needs a heroic passerby.  Complete no quests at this location.";

            NumberOfPatronsOnQuest.text = " ";
        }
        else
        {
            Quest questInfoToDisplay = targetLocation.findQuestAtThisLocationByIndex(index-1);
            QuestNameTextBox.text = questInfoToDisplay.QuestName;
            QuestDescriptionTextBox.text = questInfoToDisplay.QuestDescription;
            NumberOfPatronsOnQuest.text = questInfoToDisplay.NumberOfPatronsOnQuest + " / " + questInfoToDisplay.MaxNumberOfPatronsOnQuest; 
        }

    }

    public void ShowNextQuest() //Called when the player clicks the right arrow when choosing quests at a location
    {
        questIndex++;
        DisplayQuestInfo(questIndex);

        UpdateQuestSelectArrows();
    }

    public void ShowPreviousQuest() //Called when the player clicks the left arrow when choosing quests at a location
    {
        questIndex--;
        DisplayQuestInfo(questIndex);

        UpdateQuestSelectArrows();
    }


    public void HideSelf()  //Called when the player clicks the "cancel" or the "confirm" buttons on the QuestInfoPanel
    {
        QuestInfoRightArrow.gameObject.SetActive(false);
        QuestInfoLeftArrow.gameObject.SetActive(false);
        gameObject.SetActive(false);
    }
}
