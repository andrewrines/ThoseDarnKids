﻿using UnityEngine;
using System.Collections;

public class SwitchToPatronScreen : CommandWithUndo
{

  

    public SwitchToPatronScreen() : base()
    {

    }

    public override void Execute(BarManager Bar)
    {
        var target = Bar.GetComponent<BarManager>();
        if (target is BarManager)
        {
            target.endOfDayManagement.FlipToPatronPage();
        }
        base.Execute(Bar);
    }
}

