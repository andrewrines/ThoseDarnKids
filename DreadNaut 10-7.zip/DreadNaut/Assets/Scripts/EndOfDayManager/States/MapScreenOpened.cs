﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class MapScreenOpened : MonoBehaviour , IEndOfDayStates {

    public EndOfDayManager endOfDayManager;
    public Image Map;
    

    public void MapMenuOpen()
    {
       
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from Map");
    }

    public void RumorMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState( endOfDayManager.openRumorScreen());
       endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to rumor from Map");
    }

    public void ShowPresetAssets()
    {
        Map.gameObject.SetActive(true);
    }

    public void HidePresetAssets()
    {
        Map.gameObject.SetActive(false);
    }

   public void ScrollUp()
    {

    }

    public void ScrollDown()
    {

    }

    public void ShowStatsOnPage(byte index)
    {

    }

    public void ShowQuestOnPage(byte index)
    {

    }

    public void AddQuestToAdventureBook()
    {

    }

    public void BackOutOfQuestRumor()
    {

    }

}
