﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class RumorScreenOpened : MonoBehaviour, IEndOfDayStates
{
   public MapManager mapManager;
   public EndOfDayManager endOfDayManager;

    public Button[] buttonsWithRumorsOnThem = new Button[6];
    public Button[] questOptionsButtons = new Button[4];
    public Image[] rewardSlots = new Image[5];
    public Text[] howMuchLootText = new Text[5];
    public Button scrollUpButton;
    public Button scrollDownButton;
    public Text rumorNameText;
    public Text rumorDiscriptionText;

    public GameObject questPannel;
    public Text questName;
    public Text questDescription;
    public Text DaysOnQuest; // to be repurposed
    public Text RewardsFromQuest; // possibly an image of the things to win? 

    private int indexedRumorNumber;
    private int topOfTheListIndexNumber;
    private int bottomOfTheListIndexNumber;
    byte numberOfButtonsTodisplay;


    byte numberOfRewards;

    byte indexedQuestNumber;

    public void MapMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openMapScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to MapMenu from Rumor");
    }

    public void PatronMenuOpen()
    {
        HidePresetAssets();
        endOfDayManager.setManagerState(endOfDayManager.openPatronScreen());
        endOfDayManager.ShowPresetAssets();
        Debug.Log("Switching to patron from Rumor");
    }

    public void RumorMenuOpen()
    {
       
    }

    public void ShowPresetAssets()
    {
        topOfTheListIndexNumber = 0;
       rumorNameText.gameObject.SetActive(true);
        rumorDiscriptionText.gameObject.SetActive(true);

        numberOfButtonsTodisplay = (byte)buttonsWithRumorsOnThem.Length;

        if (endOfDayManager.RumorsKnownAbout.Count < buttonsWithRumorsOnThem.Length)
        {
            numberOfButtonsTodisplay = (byte)endOfDayManager.RumorsKnownAbout.Count;
        }

        for (byte i = 0; i < numberOfButtonsTodisplay; i++)
        {
            buttonsWithRumorsOnThem[i].gameObject.SetActive(true);
        }

        for (byte j = numberOfButtonsTodisplay; j < buttonsWithRumorsOnThem.Length; j++)
        {
            buttonsWithRumorsOnThem[j].gameObject.SetActive(false);
        }

        bottomOfTheListIndexNumber = topOfTheListIndexNumber + buttonsWithRumorsOnThem.Length;

        labelButtons();

        if (numberOfButtonsTodisplay > 0)
        {
            scrollUpButton.gameObject.SetActive(true);
            scrollDownButton.gameObject.SetActive(true); 
            ShowStatsOnPage(0);
        }

        else if (numberOfButtonsTodisplay <= 0)
        {
            rumorNameText.text = "You have no more rumors! Talk to your patrons to get some more!";
            rumorDiscriptionText.text = "";
            hideAllQuestButtons();
        }

        closeAllrewardIcons();

        // else load some text saying that you have no rumors
    }

    public void HidePresetAssets()
    {
        foreach (Button b in buttonsWithRumorsOnThem)
        {
            b.GetComponentInChildren<Text>().text = " ";
            b.gameObject.SetActive(false);
        }
        foreach (Button b in questOptionsButtons)
        {
            b.gameObject.SetActive(false);
        }
        scrollUpButton.gameObject.SetActive(false);
        scrollDownButton.gameObject.SetActive(false);
        rumorNameText.gameObject.SetActive(false);
        rumorDiscriptionText.gameObject.SetActive(false);
    }

    public void labelButtons()
    {
        for (int i = 0; i < numberOfButtonsTodisplay ; i++)
        {
            buttonsWithRumorsOnThem[i].GetComponentInChildren<Text>().text = endOfDayManager.RumorsKnownAbout[i + topOfTheListIndexNumber].RumorName;
        }
    }

    public void ScrollUp()
    {
        if (topOfTheListIndexNumber > 0)
        {
            topOfTheListIndexNumber--;
            bottomOfTheListIndexNumber--;
            labelButtons();
        }
    }
    public void ScrollDown()
    {
        if (bottomOfTheListIndexNumber < endOfDayManager.RumorsKnownAbout.Count)
        {
            topOfTheListIndexNumber++;
            bottomOfTheListIndexNumber++;
            labelButtons();
        }
    }

    public void ShowStatsOnPage(byte whichRumorToIndex)
    {
        indexedRumorNumber = whichRumorToIndex + topOfTheListIndexNumber;
        rumorNameText.text = endOfDayManager.RumorsKnownAbout[indexedRumorNumber].RumorName; 
        rumorDiscriptionText.text = endOfDayManager.RumorsKnownAbout[indexedRumorNumber].RumorDescription;
        activateAppropriateNumberOfQuestButtons(whichRumorToIndex);

    }


    public void activateAppropriateNumberOfQuestButtons(byte whichRumorToIndex)
    {
        int numberOfQuestButtonsDisplayed;

        hideAllQuestButtons();

            for (int i = 0; i < endOfDayManager.RumorsKnownAbout[whichRumorToIndex + topOfTheListIndexNumber].QuestForThisRumor.Count; i++)
            {
                questOptionsButtons[i].gameObject.SetActive(true);
            }
       

        numberOfQuestButtonsDisplayed = (byte)endOfDayManager.RumorsKnownAbout[whichRumorToIndex + topOfTheListIndexNumber].QuestForThisRumor.Count;

        for (int i = 0; i < numberOfQuestButtonsDisplayed; i++)
        { 
            questOptionsButtons[i].GetComponentInChildren<Text>().text = endOfDayManager.RumorsKnownAbout[whichRumorToIndex + topOfTheListIndexNumber].QuestForThisRumor[i].QuestName; 
        }

       
    }

    public void hideAllQuestButtons()
    {
        foreach (Button b in questOptionsButtons)
        {
            b.gameObject.SetActive(false);
        }
    }

    public void ShowQuestOnPage(byte index)
    {
        Quest questToAskAbout = endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[index]; // attempts to cash
        numberOfRewards = 0;
        indexedQuestNumber = index;
        questPannel.SetActive(true);
        questName.text = questToAskAbout.QuestName;
        questDescription.text = questToAskAbout.QuestDescription;


        foreach (StoreableItem s in questToAskAbout.RewardsFromQuest)// endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[index].RewardsFromQuest) 
        {
            rewardSlots[numberOfRewards].gameObject.SetActive(true);
            rewardSlots[numberOfRewards].sprite = s.displayArt(); // I don't know If I made things better or worse, yes this is way more oop, but I fear performance drops, need to ask my team if it's going to slow. 
            howMuchLootText[numberOfRewards].text = s.NumberLeft.ToString();
            numberOfRewards++;
        }

    }

    public void AddQuestToAdventureBook()
    {
        BackOutOfQuestRumor();
        endOfDayManager.QuestsToSendToTheBook.Add(endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[indexedQuestNumber]);
        mapManager.SetQuestToLocation(endOfDayManager.RumorsKnownAbout[indexedRumorNumber].QuestForThisRumor[indexedQuestNumber]);
        endOfDayManager.RumorsKnownAbout.RemoveAt(indexedRumorNumber);
        ShowPresetAssets();
    }

    public void BackOutOfQuestRumor()
    {
        questPannel.SetActive(false);
        closeAllrewardIcons();
    }

    private void closeAllrewardIcons()
    {
        foreach (Image i in rewardSlots)
        {
            i.gameObject.SetActive(false);
        }
    }

}
