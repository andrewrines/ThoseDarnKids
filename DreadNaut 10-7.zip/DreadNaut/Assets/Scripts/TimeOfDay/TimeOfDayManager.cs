﻿using UnityEngine;
using System.Collections;

public class TimeOfDayManager : MonoBehaviour {
    private SpriteRenderer backgroundSpriteRenderer; 
    private Color[] dayColors;
    public Color MorningColor;
    public Color NoonColor;
    public Color NightColor;
    public Color CloseColor;
    public GameObject backDrop;
    public enum TimeOfDay { MORNING, NOON, NIGHT, CLOSED }; // CLOSED Is for the management protion of the game, a time to order drinks and post quests to the board;
    TimeOfDay currentTimeOfDay;
    public TimeOfDay CurrentTimeOfDay{ get { return currentTimeOfDay; } }
    private int dayNumber;

    public float minTimePatronMorning;
    public float maxTimePatronMorning;
    public float minTimePatronNoon;
    public float maxTimePatronNoon;
    public float minTimePatronNight;
    public float maxTimePatronNight;
    public float minStartOfDayDelay;
    public float maxStartOfDayDelay;

    private float[] timesOfDay;
    public float howLongIsMorning;
    public float howLongIsNoon;
    public float howLongIsNight;

    private float currentStretchOfTimeCountdown;

    private bool isTimePaused;
    public bool IsTimePaused { get { return isTimePaused; } set { isTimePaused = value; } }

    private void Start()
    {
        backgroundSpriteRenderer = backDrop.GetComponent<SpriteRenderer>();
        initTimesOfDay();
        initTimesOfDayColor();
        startNewDay(); 
    }

    private void Update()
    {
      if (!isTimePaused && currentTimeOfDay != TimeOfDay.CLOSED)
        {
            countdown();
            backgroundColorChange();
        }
    }

    public void setCountDownClock()
    {
        Debug.Log(currentTimeOfDay);
        currentStretchOfTimeCountdown = timesOfDay[(int)currentTimeOfDay];
    }

    public void advanceDay()
    {
        currentTimeOfDay++;

    }

   

   public void initTimesOfDay()
    {
        timesOfDay = new float[3];
        timesOfDay[0] = howLongIsMorning;
        timesOfDay[1] = howLongIsNoon;
        timesOfDay[2] = howLongIsNight;
    }

    public void initTimesOfDayColor()
    {
        dayColors = new Color[4];
        dayColors[0] = new Color(MorningColor.r, MorningColor.g, MorningColor.b); // Dont know why I have to split it up like this, but I do! 
        dayColors[1] = new Color(NoonColor.r, NoonColor.g, NoonColor.b);
        dayColors[2] = new Color(NightColor.r, NightColor.g, NightColor.b);
        dayColors[3] = new Color(CloseColor.r, CloseColor.g,CloseColor.b);
    }

    //public void startFirstDay()
    //{
    //    dayNumber++;
    //    currentTimeOfDay = TimeOfDay.CLOSED;
    //    Debug.Log("Day:" + dayNumber);
    //    //changeBackdrop();
    //    //rollForAdventures();
    //}

    public void startNewDay()
    {
        dayNumber++;
        currentTimeOfDay = TimeOfDay.MORNING;  
        Debug.Log("Day:" + dayNumber);
        setCountDownClock();
        unPauseTime();
        //changeBackdrop();
        //Roll for holiday or other town event; 
    }

    public float patronOutOfSeatTimeBasedOnTimeOfDay()
    {
        switch (currentTimeOfDay)
        {
            case TimeOfDay.MORNING:
                return Random.Range(minTimePatronMorning, maxTimePatronMorning);

            case TimeOfDay.NOON:
                return Random.Range(minTimePatronNoon, maxTimePatronNoon);

            case TimeOfDay.NIGHT:
                return Random.Range(minTimePatronNight, maxTimePatronNight);

            case TimeOfDay.CLOSED:
                return Random.Range(minStartOfDayDelay, maxStartOfDayDelay);


            default:
                Debug.Log("Time of day fall through, fix now!");
                return 0;

        }
    }

    private void countdown()
    {
        currentStretchOfTimeCountdown -= Time.deltaTime;
        if (currentStretchOfTimeCountdown <= 0)
        {
            advanceDay();
            if (currentTimeOfDay != TimeOfDay.CLOSED)
            {
                setCountDownClock();
            }
        }
    }

    private void backgroundColorChange()
    {
        if (!isTimePaused && currentTimeOfDay != TimeOfDay.CLOSED)
        {
            backgroundSpriteRenderer.color = Color.Lerp(dayColors[(int)currentTimeOfDay + 1], dayColors[(int)currentTimeOfDay], currentStretchOfTimeCountdown / timesOfDay[(int)currentTimeOfDay]);
        }      
    }
    public void pauseTime()
    {
        isTimePaused = true;
        Debug.Log("Time Paused");
    }

    public void unPauseTime()
    {
        isTimePaused = false;
        Debug.Log("Time un Paused");
    }
}
