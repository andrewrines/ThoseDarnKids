﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Quest 
{

    // private string questGiver;
    // private bool isQuestSucessful = false;
    // public bool IsQuestSucessful { get { return isQuestSucessful; } set { isQuestSucessful = value; } }

    public enum questStatus { PENDING, FAIL ,PASS, REDEEMED};
    questStatus currentQuestStatus = questStatus.PENDING;

    private bool isMaxOccupancy = false; 
    public bool IsMaxOccupancy { get { return isMaxOccupancy; } }

    private byte numberOfPatronsOnQuest = 0 ;
    public byte NumberOfPatronsOnQuest { get { return numberOfPatronsOnQuest; } }


    private byte maxNumberOfPatronsOnQuest;
    public byte MaxNumberOfPatronsOnQuest { get { return maxNumberOfPatronsOnQuest; } set { maxNumberOfPatronsOnQuest = value; } }

    private byte attemptsOnQuest;
    public byte AttemptsOnQuest { get { return attemptsOnQuest; } set { attemptsOnQuest = value; } }



    private string questName;
    public string QuestName { get { return questName; } set { questName = value; } }

    private string questDescription;
    public string QuestDescription { get { return questDescription; } set { questDescription = value; } }

    private byte levelOfQuest;
    public byte LevelOfQuest { get { return levelOfQuest; } set { levelOfQuest = value; } } // for our accordian sort thing in rumorLoader;

    private string rumorID;
    public string RumorID { get { return rumorID; } set { rumorID = value; } }  // in order to return the rumor to a list of selectable rumors in our rumorLoader; 

    private bool storeRumorAgain = false;
    public bool StoreRumorAgain { get { return storeRumorAgain; } set { storeRumorAgain = value; } } // Do we desolve this back into a rumor? I don't know if this is ok, or is a bad shortcut.

    private List<QuestLoader.Trial> trialsOfTheQuest = new List<QuestLoader.Trial>();
    public List<QuestLoader.Trial> TrialsOfTheQuest { get { return trialsOfTheQuest; } set { trialsOfTheQuest = value; } }

    private List<StoreableItem> rewardsFromQuest = new List<StoreableItem>();
    public List<StoreableItem> RewardsFromQuest { get { return rewardsFromQuest; } set { rewardsFromQuest = value; } }

    private List<Patron> patronsOnQuest = new List<Patron>();
    public List<Patron> PatronsOnQuest { get { return patronsOnQuest; } set { patronsOnQuest = value; } } // Todo remove this and anything that depends on it. 

    private List<Unlocker> thingsToUnlock = new List<Unlocker>();
    public List<Unlocker> ThingsToUnlock { get { return thingsToUnlock; } set { thingsToUnlock = value; } }

    private Patron.Aligence whoDoesThisQuestSupport;
    public Patron.Aligence WhoDoesThisQuestSupport;

    private int expToAward;
    public int ExpToAward { get { return expToAward; } set { expToAward = value; } }

    private RumorLoader.RepeatableTypes rumorRepeatType;
    public RumorLoader.RepeatableTypes RumorRepeatType {get {return rumorRepeatType;} set { rumorRepeatType = value; } }

    private string questLocation;
    public string QuestLocation { get { return questLocation; } set { questLocation = value; } }

    public void incrementNumberOfPatronsOnQuest()
    {
        numberOfPatronsOnQuest++;

        if (numberOfPatronsOnQuest == MaxNumberOfPatronsOnQuest)
        {
            isMaxOccupancy = true;
        }
    }

    public void incrementAttemptsOnQuest()
    {
        attemptsOnQuest++;
    }

    public questStatus getQuestStatus()
    {
        return currentQuestStatus;
    }

    public void setToFail()
    {
        currentQuestStatus = questStatus.FAIL;
    }

    public void setToPass()
    {
        currentQuestStatus = questStatus.PASS;
    }

    public void setToRedeemed()
    {
        currentQuestStatus = questStatus.REDEEMED;
    }

   

}
