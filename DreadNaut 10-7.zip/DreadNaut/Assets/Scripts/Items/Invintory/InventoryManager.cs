﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class InventoryManager : MonoBehaviour { // decided to let objects handle their own ui elements. 

    public InvintorySlot[] invintorySlots;
    public Text goldOnScreen;
    private List<StoreableItem> thePlayersInvintory = new List<StoreableItem>();
    private int gold;
    public int Gold { get { return gold; } set { gold = value; } }
    private ItemParser itemParser;  // when we add other items into the game; 



    public void Start()
    {
       loadStarterPack();
       initInvintory();
        displayGold();
    }
        
    
    public void loadStarterPack()
    {
        gold = 500;
        for (Ingredent.ingredentColor i = 0;  i < Ingredent.ingredentColor.LENGTH; i++) // gives the player 50 of each ingredent to start;
        {
            addIngredentToInvintory(i, 20);
        }
    }

   

    public void initInvintory()
    {
        int j = 0;
       foreach (Ingredent i in thePlayersInvintory)
        {
            invintorySlots[j].gameObject.SetActive(true);
            invintorySlots[j].setItemToDisplay(i);
            invintorySlots[j].ShowNumberRemaining();
            invintorySlots[j].ShowWhatThisIngredentLooksLike();
            j++;
        }

        for (int k = j; k < invintorySlots.Length; k++)  // Is this bad? 
        {
            invintorySlots[k].gameObject.SetActive(false);
        }

    }

    public void refundIngredents(Drink drinkToRefund)
    {
        for (int i = 0; i < drinkToRefund.DrinkIngredents.Length; i++)
        {
            addIngredentToInvintory((Ingredent.ingredentColor)i, drinkToRefund.DrinkIngredents[i]);
        }
        initInvintory();
    }

    public void addIngredentToInvintory(Ingredent.ingredentColor colorOfIngredentToAdd, int numberOfIngredentToAdd)
    {
         
        bool isItemFound = false;
        foreach (Ingredent i in thePlayersInvintory)
        {
            if (i.ThisIngredentsColor == colorOfIngredentToAdd)
            {
                i.NumberLeft += numberOfIngredentToAdd;
                isItemFound = true;
            }
        }
        if (!isItemFound)
        {
            Ingredent ingredentToAdd = new Ingredent(colorOfIngredentToAdd);
            ingredentToAdd.NumberLeft += numberOfIngredentToAdd;
            thePlayersInvintory.Add(ingredentToAdd);
           
        }
    }

    public Ingredent useIngredentFromInvintory(byte slotToUse)
    {
        Ingredent ingredentToReturn = new Ingredent(invintorySlots[slotToUse].getItemToDisplay().ThisIngredentsColor); 
            invintorySlots[slotToUse].getItemToDisplay().NumberLeft--;
            invintorySlots[slotToUse].ShowNumberRemaining();
      
       if  (invintorySlots[slotToUse].getItemToDisplay().NumberLeft < 0)
            {
            Debug.Log("None left of ingredent");
            invintorySlots[slotToUse].getItemToDisplay().NumberLeft = 0;
            invintorySlots[slotToUse].ShowNumberRemaining();   // code repeats, refactor soon
            return null;
            //thePlayersInvintory.Remove(invintorySlots[slotToUse].getItemToDisplay());
            //initInvintory();
        }
        return ingredentToReturn;//invintorySlots[slotToUse].getItemToDisplay();
    }


    public void addGold(int itemIsSoldFor)
    {
        gold += itemIsSoldFor;
        displayGold();
    }

    public void payGold(int goldYouPay)
    {
        gold -= goldYouPay;
        displayGold();
    }

    public void displayGold()
    {
        goldOnScreen.text = "Gold:" + gold;
    }

    public void addItemToInvintory(StoreableItem lootToAdd) // trying to refactor this to something else too!
    {
       if (lootToAdd is Ingredent)
        {
            Ingredent ingredentToAdd = (Ingredent)lootToAdd;
            addIngredentToInvintory(ingredentToAdd.ThisIngredentsColor, ingredentToAdd.NumberLeft); 
        }

       else if (lootToAdd is Currency)
        {
            Currency EquipmentToAdd = (Currency)lootToAdd;
            if (EquipmentToAdd.HowDoesThisItemLook == Currency.whosCurrencyIsThis.GOLD)
            {
                addGold(EquipmentToAdd.NumberLeft);
            }
        }

        initInvintory(); // updates what our invintory looks like; 
    }

   
}

   


