﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Text;

public class FadingText : MonoBehaviour {

    protected Text textToFade;
    public float howLongIsThisFade;
    protected float fadeCountdown;

	// Update is called once per frame
	void Update () {
        tickTimeDown();
	}

    public virtual void sendWhatToSay(string dioOut)
    {
        this.gameObject.SetActive(true);
        textToFade = this.gameObject.GetComponent<Text>();
        textToFade.text = formatText(dioOut);
        fadeCountdown = howLongIsThisFade; 
    }

    public void cutOff()
    {
        this.gameObject.SetActive(false);
    }

    private void tickTimeDown()
    {
        fadeCountdown -= Time.deltaTime; 
        if (fadeCountdown <= 0 )
        {

            this.gameObject.SetActive(false);  
        }
    }

    private string formatText(string textToFormat)  // TODO give public accessTo designer to change how many characters before cut off. // make this a util tool too!
    {
        StringBuilder strBuilder = new StringBuilder(textToFormat);
        int i = 0;
        for (int j = 0; j < textToFormat.Length; j++)
        {
            if (i >= 50 && strBuilder[j] == ' ')
            {
                strBuilder[j] = '\n';
                i = 0;
            }
            i++;
        }
        textToFormat = strBuilder.ToString();
        return textToFormat;
    }
}
